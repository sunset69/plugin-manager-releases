module.exports = function({ React, RN, api }) {
  const { View, Text, Button, ScrollView, StyleSheet, Image } = RN;
  const styles = StyleSheet.create({
    container: { flex: 1, padding: 12, backgroundColor: '#fff' },
    title: { fontSize: 18, fontWeight: 'bold', marginBottom: 4 },
    hint: { fontSize: 13, color: '#666', lineHeight: 19, marginBottom: 12 },
    row: { marginBottom: 8 },
    status: { marginTop: 8, padding: 12, backgroundColor: '#f5f5f5', borderRadius: 6 },
    msg: { fontSize: 13, color: '#333', lineHeight: 19 },
    photo: { width: '100%', height: 200, marginTop: 10, borderRadius: 6, backgroundColor: '#eee' },
  });

  return function QuickCaptureDemo() {
    const [enabled, setEnabled] = React.useState(false);
    const [count, setCount] = React.useState(0);
    const [photo, setPhoto] = React.useState(null);
    const [msg, setMsg] = React.useState('开启后，下拉通知栏点「拍照」或把磁贴放进快捷设置，不用打开 App 就能拍');

    const fail = function (e) {
      setMsg('操作失败：' + (e && e.message ? e.message : String(e)));
    };

    const applyStatus = function (s) {
      setEnabled(!!s.enabled);
      setCount(s.photoCount || 0);
      if (s.lastPhotoPath) setPhoto('file://' + s.lastPhotoPath);
      return s;
    };

    const refresh = function () {
      return api.quickCapture.status().then(applyStatus).catch(fail);
    };

    React.useEffect(function () {
      refresh();
      const offCapture = api.quickCapture.onCapture(function (data) {
        setPhoto(data.uri);
        setMsg('已保存一张照片：' + data.path);
        refresh();
      });
      const offError = api.quickCapture.onError(function (data) {
        setMsg('快捷拍照未完成（' + data.code + '）：' + data.message);
      });
      const offState = api.quickCapture.onStateChange(function (data) {
        setEnabled(!!data.enabled);
        setMsg(data.enabled ? '入口已开启' : '入口已关闭');
      });
      return function () {
        offCapture();
        offError();
        offState();
      };
    }, []);

    const onEnable = function () {
      setMsg('正在请求相机与通知权限…');
      api.quickCapture.enable({ title: '快捷拍照', subtitle: '点按即可拍照，无需打开 App' })
        .then(function (s) {
          applyStatus(s);
          setMsg('入口已开启：通知栏常驻一条可关闭的入口通知，快捷设置里也有同名磁贴');
        })
        .catch(fail);
    };

    const onDisable = function () {
      api.quickCapture.disable()
        .then(function (s) {
          applyStatus(s);
          setMsg('入口已关闭，通知与磁贴都已移除');
        })
        .catch(fail);
    };

    return React.createElement(View, { style: styles.container },
      React.createElement(Text, { style: styles.title }, '通知栏快捷拍照'),
      React.createElement(Text, { style: styles.hint }, '开启后在通知栏或快捷设置磁贴一键拍照，照片保存到应用私有目录，并可从结果通知里查看或再拍一张'),
      React.createElement(ScrollView, { style: { flex: 1 } },
        React.createElement(View, { style: styles.row }, React.createElement(Button, {
          title: enabled ? '关闭通知栏入口' : '开启通知栏入口',
          onPress: enabled ? onDisable : onEnable,
        })),
        React.createElement(View, { style: styles.row }, React.createElement(Button, {
          title: '刷新状态',
          onPress: function () { refresh().then(function (s) { setMsg('入口' + (s.enabled ? '已开启' : '未开启') + '，已保存 ' + (s.photoCount || 0) + ' 张'); }); },
        })),
        photo ? React.createElement(Image, { style: styles.photo, source: { uri: photo } }) : null
      ),
      React.createElement(View, { style: styles.status },
        React.createElement(Text, { style: styles.msg }, '入口状态：' + (enabled ? '已开启' : '已关闭') + '　已保存 ' + count + ' 张'),
        React.createElement(Text, { style: styles.msg }, msg))
    );
  };
};
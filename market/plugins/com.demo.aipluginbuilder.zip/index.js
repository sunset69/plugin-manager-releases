// AI 造插件
// 配置 OpenAI 兼容接口 → 描述需求 → AI 生成 manifest.json + index.js → 宿主校验 →
// 预览 / 导出 zip / 确认权限后走安装管线安装并直接打开。
// 注意：插件沙箱不支持异步/等待类语法与 JSX，本文件全部使用 Promise 链与 React.createElement。
module.exports = function ({ React, RN, api }) {
  var e = React.createElement;
  var View = RN.View;
  var Text = RN.Text;
  var TextInput = RN.TextInput;
  var ScrollView = RN.ScrollView;
  var TouchableOpacity = RN.TouchableOpacity;
  var ActivityIndicator = RN.ActivityIndicator;
  var Image = RN.Image;
  var StyleSheet = RN.StyleSheet;

  var HISTORY_LIMIT = 10;
  var DEFAULT_BASE = 'https://api.openai.com/v1';
  var DEFAULT_MODEL = 'gpt-4o-mini';
  var KEYS = {
    baseUrl: 'ai.baseUrl',
    apiKey: 'ai.apiKey',
    model: 'ai.model',
    history: 'ai.history',
  };

  var SYSTEM_PROMPT = [
    '你是「插件管理器」Android 应用的插件代码生成器。',
    '只输出一个 JSON 对象，不要 markdown 代码块，不要解释文字。',
    'JSON 结构：{"manifest":{...},"indexJs":"...","iconBase64":null}',
    'manifest 必填字段：id（小写反向域名，例如 com.example.demo）、name（1-30 字）、version（SemVer，例如 1.0.0）、entry（固定 index.js）、permissions（数组，可为空）。可选字段：description、author、icon。',
    'permissions 只能从这些值里选：storage, network, clipboard, vibrate, device, camera, location, sensors, notification, files, biometric, quickCapture。用 api.storage 要 storage，用 api.fetch 要 network，不要申请用不到的权限。',
    'indexJs 必须是完整可运行的 JavaScript：module.exports = function ({ React, RN, api }) { return function App() { ... }; };',
    '界面只能用 React.createElement 构建，不要写 JSX。',
    '只能用 Promise 的 .then/.catch 链式写法；不要使用任何异步或等待类语法，也不要使用生成器语法。',
    '不要使用 require，不能依赖任何第三方包。',
    '可用组件：View, Text, Button, TextInput, ScrollView, StyleSheet, Image, TouchableOpacity, FlatList, ActivityIndicator, RefreshControl。',
    '数据持久化用 api.storage.get(key) / set(key, value) / remove(key)，都返回 Promise。',
    '代码要简洁可运行，中文界面，捕获错误并在界面上提示。',
    '没有图标数据时不要在 manifest 里写 icon，iconBase64 固定返回 null。',
  ].join('\n');

  function nowText(ts) {
    var d = new Date(ts);
    var pad = function (n) { return n < 10 ? '0' + n : '' + n; };
    return pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  function maskKey(key) {
    var value = String(key || '');
    if (!value) return '';
    if (value.length <= 10) return '••••••';
    return value.slice(0, 4) + '••••' + value.slice(-4);
  }

  // 去掉 AI 偶尔带出的 ``` 包裹，截取第一个 { 到最后一个 }
  function extractJson(text) {
    var s = String(text || '').trim();
    var start = s.indexOf('{');
    var end = s.lastIndexOf('}');
    if (start >= 0 && end > start) s = s.slice(start, end + 1);
    return s;
  }

  function parsePayload(text) {
    var json;
    try {
      json = JSON.parse(extractJson(text));
    } catch (err) {
      throw new Error('AI 返回的不是合法 JSON：' + String(text || '').slice(0, 200));
    }
    if (!json || !json.manifest || typeof json.manifest !== 'object') {
      throw new Error('AI 返回缺少 manifest 对象');
    }
    if (typeof json.indexJs !== 'string' || !json.indexJs.trim()) {
      throw new Error('AI 返回缺少 indexJs 代码');
    }
    return json;
  }

  function buildFiles(payload) {
    var files = {};
    files['manifest.json'] = JSON.stringify(payload.manifest, null, 2);
    files['index.js'] = payload.indexJs;
    if (payload.iconBase64 && payload.manifest.icon) {
      files[payload.manifest.icon] = { base64: String(payload.iconBase64) };
    }
    return files;
  }

  function requestAI(config, messages) {
    var base = String(config.baseUrl || '').replace(/\/+$/, '');
    if (!base) throw new Error('请先配置 API 地址');
    if (!config.apiKey) throw new Error('请先配置 API Key');
    if (!config.model) throw new Error('请先配置模型名');

    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, 60000);

    return api.fetch(base + '/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + config.apiKey,
      },
      body: JSON.stringify({
        model: config.model,
        temperature: 0.2,
        messages: messages,
      }),
      signal: controller.signal,
    }).then(function (res) {
      return res.text().then(function (text) {
        clearTimeout(timer);
        if (!res.ok) {
          throw new Error('接口返回 HTTP ' + res.status + '：' + String(text || '').slice(0, 300));
        }
        var json;
        try {
          json = JSON.parse(text);
        } catch (err) {
          throw new Error('接口返回不是 JSON：' + String(text || '').slice(0, 200));
        }
        var choice = json && json.choices && json.choices[0];
        var content = choice && choice.message && choice.message.content;
        if (!content) throw new Error('接口返回缺少 choices[0].message.content');
        return content;
      });
    }).catch(function (err) {
      clearTimeout(timer);
      if (err && err.name === 'AbortError') throw new Error('请求超时（60 秒），请检查网络或接口地址');
      throw err;
    });
  }

  function ActionButton(props) {
    return e(
      TouchableOpacity,
      {
        style: [
          styles.btn,
          props.primary ? styles.btnPrimary : null,
          props.danger ? styles.btnDanger : null,
          props.disabled || props.loading ? styles.btnDisabled : null,
          props.style || null,
        ],
        disabled: props.disabled || props.loading,
        onPress: props.onPress,
      },
      props.loading
        ? e(ActivityIndicator, { size: 'small', color: '#fff' })
        : e(Text, { style: [styles.btnText, props.primary || props.danger ? styles.btnTextLight : null] }, props.title)
    );
  }

  function Section(props) {
    return e(View, { style: styles.card },
      props.title ? e(Text, { style: styles.cardTitle }, props.title) : null,
      props.children
    );
  }

  return function AiPluginBuilder() {
    var [tab, setTab] = React.useState('generate');
    var [baseUrl, setBaseUrl] = React.useState(DEFAULT_BASE);
    var [model, setModel] = React.useState(DEFAULT_MODEL);
    var [apiKey, setApiKey] = React.useState('');
    var [keyDraft, setKeyDraft] = React.useState('');
    var [editingKey, setEditingKey] = React.useState(false);
    var [prompt, setPrompt] = React.useState('');
    var [busy, setBusy] = React.useState(false);
    var [status, setStatus] = React.useState('');
    var [error, setError] = React.useState('');
    var [current, setCurrent] = React.useState(null);
    var [viewFile, setViewFile] = React.useState('index.js');
    var [history, setHistory] = React.useState([]);
    var [catalog, setCatalog] = React.useState([]);
    var [confirming, setConfirming] = React.useState(false);
    var [working, setWorking] = React.useState('');

    React.useEffect(function () {
      Promise.all([
        api.storage.get(KEYS.baseUrl),
        api.storage.get(KEYS.apiKey),
        api.storage.get(KEYS.model),
        api.storage.get(KEYS.history),
      ]).then(function (values) {
        if (values[0]) setBaseUrl(values[0]);
        if (values[1]) setApiKey(values[1]);
        if (values[2]) setModel(values[2]);
        if (values[3]) {
          try {
            var list = JSON.parse(values[3]);
            if (Array.isArray(list)) setHistory(list);
          } catch (err) {}
        }
      }).catch(function () {});
      api.pluginBuilder.catalog().then(function (list) {
        setCatalog(list || []);
      }).catch(function () {});
    }, []);

    var fail = function (err) {
      setBusy(false);
      setWorking('');
      setError((err && err.message) || String(err));
    };

    var saveConfig = function () {
      Promise.all([
        api.storage.set(KEYS.baseUrl, String(baseUrl || '').trim()),
        api.storage.set(KEYS.model, String(model || '').trim()),
      ]).then(function () {
        setStatus('配置已保存');
        setError('');
      }).catch(fail);
    };

    var saveKey = function () {
      var next = String(keyDraft || '').trim();
      api.storage.set(KEYS.apiKey, next).then(function () {
        setApiKey(next);
        setKeyDraft('');
        setEditingKey(false);
        setStatus(next ? 'API Key 已保存在本机（仅脱敏显示）' : '已清除 API Key');
        setError('');
      }).catch(fail);
    };

    var testConnection = function () {
      setBusy(true);
      setWorking('正在测试连接');
      setError('');
      setStatus('');
      requestAI({ baseUrl: baseUrl, apiKey: apiKey, model: model }, [
        { role: 'user', content: '请只回复 OK' },
      ]).then(function (content) {
        setBusy(false);
        setWorking('');
        setStatus('连接正常，模型回复：' + String(content).slice(0, 60));
      }).catch(fail);
    };

    var saveHistory = function (entry) {
      setHistory(function (prev) {
        var next = [entry].concat(prev).slice(0, HISTORY_LIMIT);
        api.storage.set(KEYS.history, JSON.stringify(next)).catch(function () {});
        return next;
      });
    };

    var applyResult = function (payload, userPrompt) {
      var files = buildFiles(payload);
      setCurrent(null);
      setStatus('正在校验生成结果');
      return api.pluginBuilder.validate(files).then(function (check) {
        var entry = {
          createdAt: Date.now(),
          prompt: userPrompt,
          raw: JSON.stringify(payload),
          files: files,
          manifest: check.manifest || payload.manifest,
          ok: check.ok,
          errors: check.errors || [],
          warnings: check.warnings || [],
        };
        setCurrent(entry);
        setViewFile('index.js');
        setConfirming(false);
        setBusy(false);
        setWorking('');
        if (check.ok) {
          var warn = check.warnings && check.warnings.length
            ? '；提示：' + check.warnings.join('；')
            : '';
          setStatus('校验通过，可预览、导出或安装' + warn);
        } else {
          setStatus('校验未通过，请让 AI 修正后重试');
        }
        saveHistory(entry);
        return entry;
      });
    };

    var generate = function () {
      var need = String(prompt || '').trim();
      if (!need) {
        setError('请先描述你想要的插件');
        return;
      }
      if (!apiKey) {
        setError('请先在「配置」里填写 API Key');
        setTab('config');
        return;
      }
      setBusy(true);
      setWorking('AI 正在生成插件');
      setError('');
      setStatus('');
      setConfirming(false);
      requestAI({ baseUrl: baseUrl, apiKey: apiKey, model: model }, [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: '请按以下需求生成插件：\n' + need + '\n\n只返回 JSON。' },
      ]).then(function (content) {
        var payload = parsePayload(content);
        return applyResult(payload, need);
      }).catch(fail);
    };

    var repair = function () {
      if (!current) return;
      setBusy(true);
      setWorking('AI 正在按校验问题修正');
      setError('');
      var problems = (current.errors || [])
        .map(function (item) { return '- ' + item.field + '：' + item.message; })
        .join('\n');
      var messages = [
        { role: 'system', content: SYSTEM_PROMPT },
        {
          role: 'user',
          content:
            '下面这版插件未通过宿主校验，请修正后重新输出完整 JSON。\n\n' +
            '原始需求：' + current.prompt + '\n\n' +
            '上一版 JSON：\n' + current.raw + '\n\n' +
            '校验问题：\n' + problems + '\n\n' +
            '请只返回修正后的完整 JSON。',
        },
      ];
      requestAI({ baseUrl: baseUrl, apiKey: apiKey, model: model }, messages)
        .then(function (content) {
          var payload = parsePayload(content);
          return applyResult(payload, current.prompt);
        })
        .catch(fail);
    };

    var doExport = function () {
      if (!current) return;
      var mf = current.manifest || {};
      var name = (mf.id || 'plugin') + '-' + (mf.version || '0.0.0') + '.zip';
      setBusy(true);
      setWorking('正在打包导出');
      setError('');
      api.exportFile.zip(current.files, name).then(function (result) {
        setBusy(false);
        setWorking('');
        setStatus('已导出到 ' + result.path + '（' + result.size + ' 字节）');
      }).catch(fail);
    };

    var confirmInstall = function () {
      if (!current || !current.ok) return;
      setBusy(true);
      setWorking('正在安装插件');
      setError('');
      api.pluginBuilder.install(current.files).then(function (record) {
        setBusy(false);
        setWorking('');
        setConfirming(false);
        setStatus('已安装「' + record.name + '」v' + record.version + '，正在打开…');
        api.pluginBuilder.open(record.id, record.name).catch(function (err) {
          setError('安装成功，但打开失败：' + ((err && err.message) || String(err)));
        });
      }).catch(fail);
    };

    var loadHistory = function (item) {
      setCurrent(item);
      setPrompt(item.prompt || '');
      setViewFile('index.js');
      setConfirming(false);
      setError('');
      setTab('generate');
      setStatus(item.ok ? '已载入历史版本（校验通过）' : '已载入历史版本（当时未通过校验）');
    };

    var removeHistory = function (ts) {
      setHistory(function (prev) {
        var next = prev.filter(function (item) { return item.createdAt !== ts; });
        api.storage.set(KEYS.history, JSON.stringify(next)).catch(function () {});
        return next;
      });
      if (current && current.createdAt === ts) setCurrent(null);
    };

    var permissionLabel = function (key) {
      for (var i = 0; i < catalog.length; i += 1) {
        if (catalog[i].key === key) return catalog[i].label + '（' + key + '）';
      }
      return key;
    };
    var permissionDesc = function (key) {
      for (var i = 0; i < catalog.length; i += 1) {
        if (catalog[i].key === key) return catalog[i].desc;
      }
      return '';
    };

    var renderConfig = function () {
      return e(View, null,
        e(Section, { title: 'AI 接口配置' },
          e(Text, { style: styles.hint }, '兼容 OpenAI 的 /chat/completions。国内服务把地址填到 /v1 即可，例如 https://api.deepseek.com/v1。'),
          e(Text, { style: styles.label }, 'API 地址'),
          e(TextInput, {
            style: styles.input,
            value: baseUrl,
            onChangeText: function (v) { setBaseUrl(v); setStatus(''); },
            placeholder: 'https://api.openai.com/v1',
            autoCapitalize: 'none',
            autoCorrect: false,
          }),
          e(Text, { style: styles.label }, '模型名'),
          e(TextInput, {
            style: styles.input,
            value: model,
            onChangeText: function (v) { setModel(v); setStatus(''); },
            placeholder: 'gpt-4o-mini',
            autoCapitalize: 'none',
            autoCorrect: false,
          }),
          e(Text, { style: styles.label }, 'API Key'),
          editingKey
            ? e(View, null,
                e(TextInput, {
                  style: styles.input,
                  value: keyDraft,
                  onChangeText: setKeyDraft,
                  placeholder: 'sk-...',
                  autoCapitalize: 'none',
                  autoCorrect: false,
                  secureTextEntry: true,
                }),
                e(View, { style: styles.row },
                  e(ActionButton, { title: '保存 Key', primary: true, onPress: saveKey, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  e(ActionButton, { title: '取消', onPress: function () { setEditingKey(false); setKeyDraft(''); }, style: styles.flex1 })
                )
              )
            : e(View, null,
                e(Text, { style: styles.keyText }, apiKey ? '已保存：' + maskKey(apiKey) : '尚未配置'),
                e(View, { style: styles.row },
                  e(ActionButton, { title: apiKey ? '更换 Key' : '填写 Key', primary: true, onPress: function () { setEditingKey(true); }, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  apiKey ? e(ActionButton, { title: '清除', danger: true, onPress: function () { api.storage.remove(KEYS.apiKey).then(function () { setApiKey(''); setStatus('已清除 API Key'); }); }, style: styles.flex1 }) : null
                )
              ),
          e(Text, { style: styles.note }, 'Key 只保存在本机插件私有存储里，界面始终脱敏显示，不会回传或写入日志。'),
          e(View, { style: styles.row },
            e(ActionButton, { title: '保存配置', primary: true, onPress: saveConfig, style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '测试连接', onPress: testConnection, loading: busy && working === '正在测试连接', style: styles.flex1 })
          )
        ),
        status ? e(Text, { style: styles.statusText }, status) : null,
        error ? e(View, { style: styles.errorBox }, e(Text, { style: styles.errorTitle }, '出错了'), e(Text, { style: styles.errorLine }, error)) : null,
        e(Section, { title: '说明' },
          e(Text, { style: styles.hint }, '· 生成结果会先做宿主校验：manifest 必填字段、id 格式、SemVer、入口路径、权限白名单、入口语法扫描。'),
          e(Text, { style: styles.hint }, '· 安装复用现有安装管线，不能绕过校验；装完可在已安装列表里看到，也可直接打开。'),
          e(Text, { style: styles.hint }, '· AI 生成的代码属于不可信内容，安装前请确认权限清单；首次运行宿主仍会再次确认。')
        )
      );
    };

    var renderResult = function () {
      if (!current) return null;
      var mf = current.manifest || {};
      var perms = Array.isArray(mf.permissions) ? mf.permissions : [];
      var fileContent = current.files[viewFile];
      var text = typeof fileContent === 'string' ? fileContent : '[二进制文件]';
      return e(View, null,
        e(Section, { title: '生成结果' },
          e(View, { style: styles.rowBetween },
            e(Text, { style: styles.resultName }, mf.name || mf.id || '未命名插件'),
            e(Text, { style: current.ok ? styles.badgeOk : styles.badgeBad }, current.ok ? '校验通过' : '校验未通过')
          ),
          e(Text, { style: styles.hint }, 'id：' + (mf.id || '-') + '\n版本：' + (mf.version || '-') + '\n入口：' + (mf.entry || '-') + '\n描述：' + (mf.description || '无')),
          e(Text, { style: styles.label }, '将要申请的权限（' + perms.length + '）'),
          perms.length === 0
            ? e(Text, { style: styles.hint }, '无受限权限')
            : perms.map(function (key) {
                return e(View, { key: key, style: styles.permRow },
                  e(Text, { style: styles.permLabel }, permissionLabel(key)),
                  e(Text, { style: styles.permDesc }, permissionDesc(key))
                );
              }),
          current.warnings && current.warnings.length
            ? e(Text, { style: styles.warnText }, '提示：' + current.warnings.join('；'))
            : null,
          !current.ok
            ? e(View, { style: styles.errorBox },
                e(Text, { style: styles.errorTitle }, '未通过校验的问题'),
                (current.errors || []).map(function (item, idx) {
                  return e(Text, { key: idx, style: styles.errorLine }, '· ' + item.field + '：' + item.message);
                }),
                e(View, { style: styles.row },
                  e(ActionButton, { title: '让 AI 修正', primary: true, onPress: repair, loading: busy && working === 'AI 正在按校验问题修正', style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  e(ActionButton, { title: '重新生成', onPress: generate, style: styles.flex1 })
                )
              )
            : null,
          e(View, { style: styles.fileTabs },
            ['manifest.json', 'index.js'].filter(function (name) { return current.files[name]; }).map(function (name) {
              return e(TouchableOpacity, {
                key: name,
                style: [styles.fileTab, viewFile === name ? styles.fileTabActive : null],
                onPress: function () { setViewFile(name); },
              }, e(Text, { style: viewFile === name ? styles.fileTabTextActive : styles.fileTabText }, name));
            })
          ),
          e(ScrollView, { horizontal: true, style: styles.codeBox },
            e(Text, { style: styles.code }, text)
          )
        ),
        e(Section, { title: '操作' },
          e(View, { style: styles.row },
            e(ActionButton, { title: '导出 zip', onPress: doExport, loading: busy && working === '正在打包导出', style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '安装并打开', primary: true, disabled: !current.ok, onPress: function () { setConfirming(true); setError(''); }, style: styles.flex1 })
          ),
          confirming
            ? e(View, { style: styles.confirmBox },
                e(Text, { style: styles.confirmTitle }, '确认安装「' + (mf.name || mf.id) + '」？'),
                e(Text, { style: styles.hint }, '这个插件将申请以下权限：'),
                perms.length === 0
                  ? e(Text, { style: styles.hint }, '无受限权限')
                  : perms.map(function (key) {
                      return e(Text, { key: key, style: styles.confirmPerm }, '· ' + permissionLabel(key) + '：' + permissionDesc(key));
                    }),
                e(Text, { style: styles.warnText }, 'AI 生成的代码属于不可信内容。安装会复用宿主校验与权限管线，首次运行仍会要求你再次确认权限。'),
                e(View, { style: styles.row },
                  e(ActionButton, { title: '取消', onPress: function () { setConfirming(false); }, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  e(ActionButton, { title: '确认安装并打开', primary: true, onPress: confirmInstall, loading: busy && working === '正在安装插件', style: styles.flex1 })
                )
              )
            : null
        )
      );
    };

    var renderGenerate = function () {
      return e(View, null,
        e(Section, { title: '描述你想要的插件' },
          e(Text, { style: styles.hint }, '例如：一个番茄钟，可设置 25 分钟专注与 5 分钟休息，开始后显示倒计时，结束时震动提醒。'),
          e(TextInput, {
            style: [styles.input, styles.promptInput],
            value: prompt,
            onChangeText: function (v) { setPrompt(v); setStatus(''); },
            placeholder: '用一句话说清功能、交互与需要保存的数据…',
            multiline: true,
            textAlignVertical: 'top',
          }),
          e(View, { style: styles.row },
            e(ActionButton, { title: '生成插件', primary: true, onPress: generate, loading: busy && working === 'AI 正在生成插件', style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '清空', onPress: function () { setPrompt(''); setCurrent(null); setStatus(''); setError(''); setConfirming(false); }, style: styles.flex1 })
          ),
          e(Text, { style: styles.note }, '生成会调用你在「配置」里填写的 AI 接口，可能产生费用。生成结果会先本地校验，不会自动安装。')
        ),
        busy && !current
          ? e(View, { style: styles.loadingBox },
              e(ActivityIndicator, { size: 'small' }),
              e(Text, { style: styles.loadingText }, working || '处理中…')
            )
          : null,
        status ? e(Text, { style: styles.statusText }, status) : null,
        error ? e(View, { style: styles.errorBox }, e(Text, { style: styles.errorTitle }, '出错了'), e(Text, { style: styles.errorLine }, error)) : null,
        renderResult()
      );
    };

    var renderHistory = function () {
      return e(View, null,
        e(Section, { title: '生成历史（最近 ' + HISTORY_LIMIT + ' 次）' },
          e(Text, { style: styles.hint }, '历史保存在本机插件私有存储里，可随时载入回看或删除。'),
          history.length === 0
            ? e(Text, { style: styles.emptyText }, '还没有生成记录')
            : history.map(function (item) {
                var mf = item.manifest || {};
                return e(View, { key: item.createdAt, style: styles.historyItem },
                  e(View, { style: styles.rowBetween },
                    e(Text, { style: styles.historyName }, (mf.name || mf.id || '未命名') + ' v' + (mf.version || '-')),
                    e(Text, { style: item.ok ? styles.badgeOk : styles.badgeBad }, item.ok ? '通过' : '未通过')
                  ),
                  e(Text, { style: styles.historyPrompt }, item.prompt),
                  e(Text, { style: styles.historyTime }, nowText(item.createdAt) + ' · ' + ((item.files && item.files['index.js'] && item.files['index.js'].length) || 0) + ' 字符'),
                  e(View, { style: styles.row },
                    e(ActionButton, { title: '载入', primary: true, onPress: function () { loadHistory(item); }, style: styles.flex1 }),
                    e(View, { style: styles.gap }),
                    e(ActionButton, { title: '删除', danger: true, onPress: function () { removeHistory(item.createdAt); }, style: styles.flex1 })
                  )
                );
              })
        )
      );
    };

    return e(View, { style: styles.root },
      e(View, { style: styles.tabBar },
        [
          { key: 'generate', label: '生成' },
          { key: 'config', label: '配置' },
          { key: 'history', label: '历史' },
        ].map(function (item) {
          return e(TouchableOpacity, {
            key: item.key,
            style: [styles.tab, tab === item.key ? styles.tabActive : null],
            onPress: function () { setTab(item.key); },
          }, e(Text, { style: tab === item.key ? styles.tabTextActive : styles.tabText }, item.label));
        })
      ),
      e(ScrollView, {
        style: styles.body,
        contentContainerStyle: styles.bodyContent,
        keyboardShouldPersistTaps: 'handled',
      },
        tab === 'generate' ? renderGenerate() : null,
        tab === 'config' ? renderConfig() : null,
        tab === 'history' ? renderHistory() : null
      )
    );
  };
};

var styles = RN.StyleSheet.create({
  root: { flex: 1, backgroundColor: '#f4f6f9' },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderBottomWidth: RN.StyleSheet.hairlineWidth,
    borderBottomColor: '#e2e6eb',
  },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center' },
  tabActive: { borderBottomWidth: 2, borderBottomColor: '#4a90d9' },
  tabText: { fontSize: 14, color: '#777' },
  tabTextActive: { fontSize: 14, color: '#2f6fb3', fontWeight: '600' },
  body: { flex: 1 },
  bodyContent: { padding: 12, paddingBottom: 32 },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 14,
    marginBottom: 12,
  },
  cardTitle: { fontSize: 16, fontWeight: '600', color: '#222', marginBottom: 10 },
  label: { fontSize: 13, color: '#555', marginTop: 10, marginBottom: 6 },
  hint: { fontSize: 12, color: '#888', lineHeight: 19, marginBottom: 6 },
  note: { fontSize: 11, color: '#999', lineHeight: 17, marginTop: 10 },
  input: {
    borderWidth: 1,
    borderColor: '#dfe3e8',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 14,
    color: '#222',
    backgroundColor: '#fbfcfd',
  },
  promptInput: { minHeight: 96, textAlignVertical: 'top' },
  keyText: {
    fontSize: 14,
    color: '#333',
    backgroundColor: '#f7f9fb',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 10,
    marginBottom: 8,
  },
  row: { flexDirection: 'row', alignItems: 'center', marginTop: 10, flexWrap: 'wrap' },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  gap: { width: 10 },
  flex1: { flex: 1, minWidth: 120 },
  btn: {
    minHeight: 42,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#d9dee5',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
    marginTop: 8,
  },
  btnPrimary: { backgroundColor: '#4a90d9', borderColor: '#4a90d9' },
  btnDanger: { backgroundColor: '#e05b59', borderColor: '#e05b59' },
  btnDisabled: { opacity: 0.55 },
  btnText: { fontSize: 14, color: '#3b6fa8', fontWeight: '600' },
  btnTextLight: { color: '#fff' },
  statusText: {
    fontSize: 13,
    color: '#2f6fb3',
    backgroundColor: '#eef5fd',
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
    lineHeight: 19,
  },
  errorBox: {
    backgroundColor: '#fff1f0',
    borderWidth: 1,
    borderColor: '#ffccc7',
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
  },
  errorTitle: { fontSize: 13, fontWeight: '600', color: '#cf1322', marginBottom: 4 },
  errorLine: { fontSize: 12, color: '#a8071a', lineHeight: 18 },
  warnText: { fontSize: 12, color: '#ad6800', lineHeight: 18, marginTop: 8 },
  resultName: { fontSize: 15, fontWeight: '600', color: '#222', flexShrink: 1 },
  badgeOk: {
    fontSize: 11,
    color: '#237804',
    backgroundColor: '#f6ffed',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginLeft: 8,
    overflow: 'hidden',
  },
  badgeBad: {
    fontSize: 11,
    color: '#cf1322',
    backgroundColor: '#fff1f0',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginLeft: 8,
    overflow: 'hidden',
  },
  permRow: { marginTop: 8, borderLeftWidth: 3, borderLeftColor: '#b7d6f5', paddingLeft: 8 },
  permLabel: { fontSize: 13, color: '#333', fontWeight: '600' },
  permDesc: { fontSize: 11, color: '#888', lineHeight: 17, marginTop: 2 },
  confirmBox: {
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#ffe58f',
    backgroundColor: '#fffbe6',
    borderRadius: 8,
    padding: 12,
  },
  confirmTitle: { fontSize: 14, fontWeight: '600', color: '#874d00', marginBottom: 8 },
  confirmPerm: { fontSize: 12, color: '#874d00', lineHeight: 18 },
  fileTabs: { flexDirection: 'row', marginTop: 12 },
  fileTab: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 6,
    backgroundColor: '#f0f2f5',
    marginRight: 8,
  },
  fileTabActive: { backgroundColor: '#4a90d9' },
  fileTabText: { fontSize: 12, color: '#555' },
  fileTabTextActive: { fontSize: 12, color: '#fff' },
  codeBox: {
    marginTop: 10,
    maxHeight: 260,
    backgroundColor: '#1f2430',
    borderRadius: 8,
  },
  code: {
    padding: 12,
    color: '#d7e3f4',
    fontSize: 11,
    lineHeight: 16,
    fontFamily: 'monospace',
  },
  loadingBox: { flexDirection: 'row', alignItems: 'center', padding: 12 },
  loadingText: { fontSize: 13, color: '#666', marginLeft: 8 },
  emptyText: { fontSize: 13, color: '#999', paddingVertical: 20, textAlign: 'center' },
  historyItem: {
    borderWidth: 1,
    borderColor: '#eceff3',
    borderRadius: 8,
    padding: 10,
    marginTop: 10,
  },
  historyName: { fontSize: 14, fontWeight: '600', color: '#222', flex: 1 },
  historyPrompt: { fontSize: 12, color: '#666', lineHeight: 18, marginTop: 6 },
  historyTime: { fontSize: 11, color: '#aaa', marginTop: 4 },
});

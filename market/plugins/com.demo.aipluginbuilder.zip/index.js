// AI 造插件
// 配置 OpenAI 兼容接口 → 描述需求 → AI 生成 manifest.json + index.js → 宿主校验 →
// 预览 / 导出 zip / 确认权限后走安装管线安装并直接打开。
// 注意：插件沙箱不支持异步/等待类语法与 JSX，本文件全部使用 Promise 链与 React.createElement。
module.exports = function ({ React, RN, api }) {
  var e = React.createElement;
  var View = RN.View;
  var Text = RN.Text;
  var TextInput = RN.TextInput;
  var ScrollView = RN.ScrollView;
  var TouchableOpacity = RN.TouchableOpacity;
  var ActivityIndicator = RN.ActivityIndicator;
  var Image = RN.Image;
  var StyleSheet = RN.StyleSheet;

  var HISTORY_LIMIT = 10;
  var DEFAULT_BASE = 'https://api.deepseek.com';
  var DEFAULT_MODEL = 'deepseek-chat';
  var DEFAULT_TIMEOUT_SEC = 120;
  var DEFAULT_MAX_TOKENS = 8192;
  var MIN_TIMEOUT_SEC = 20;
  var MAX_TIMEOUT_SEC = 600;
  var KEYS = {
    baseUrl: 'ai.baseUrl',
    apiKey: 'ai.apiKey',
    model: 'ai.model',
    timeout: 'ai.timeoutSec',
    maxTokens: 'ai.maxTokens',
    stream: 'ai.stream',
    skill: 'ai.skill',
    history: 'ai.history',
  };

  // 常用 OpenAI 兼容服务商预设。模型名只是默认值，可点「拉取模型」用 /models 校正。
  var PRESETS = [
    {
      key: 'deepseek',
      label: 'DeepSeek',
      baseUrl: 'https://api.deepseek.com',
      model: 'deepseek-chat',
    },
    {
      key: 'openai',
      label: 'OpenAI',
      baseUrl: 'https://api.openai.com/v1',
      model: 'gpt-4o-mini',
    },
    {
      key: 'dashscope',
      label: '通义千问',
      baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
      model: 'qwen-plus',
    },
    {
      key: 'moonshot',
      label: '月之暗面',
      baseUrl: 'https://api.moonshot.cn/v1',
      model: 'moonshot-v1-8k',
    },
  ];

  var EXAMPLES = [
    { label: '天气查看', text: '帮我生成一个天气查看插件：显示当前城市、天气状况和温度，可以手动刷新，界面简洁，中文显示。' },
    { label: '番茄钟', text: '帮我生成一个番茄钟插件：25 分钟专注、5 分钟休息，开始后显示倒计时，结束时震动提醒，并记录完成的番茄数。' },
    { label: '待办清单', text: '帮我生成一个待办清单插件：可以添加、勾选完成和删除待办，数据保存在本机，重启后仍在。' },
  ];

  var DEFAULT_SKILL = [
    '你是「插件管理器」Android 应用的插件生成器，必须严格遵守下面的插件规范。',
    '',
    '【输出格式】',
    '只输出一个 JSON 对象，不要 markdown 代码块，不要解释文字。结构必须是：',
    '{"manifest":{...},"indexJs":"完整 JS 源码字符串","iconBase64":null}',
    'indexJs 必须是可直接运行的完整源码字符串，换行用 JSON 转义。',
    '',
    '【manifest 必填字段】',
    'id：小写反向域名，至少两段，字母开头，仅含小写字母、数字、点和中划线，例如 com.example.weather；不要包含中文、空格或大写字母。',
    'name：1-30 个字符的中文或英文名称。',
    'version：SemVer，格式 MAJOR.MINOR.PATCH，例如 1.0.0。',
    'entry：固定为 index.js，放在插件根目录。',
    'permissions：数组，可为空；只能使用白名单里的值，并确实用到对应 api。',
    '可选字段：description（一句话说明）、author、icon（仅在 iconBase64 有值时填写，指向 assets/icon.png）。',
    '',
    '【权限白名单与用途】',
    'storage：api.storage.get/set/remove，插件私有键值存储。',
    'network：api.fetch / api.fetchStream，访问网络，必须处理失败并提示。',
    'clipboard：api.clipboard 读写剪贴板。',
    'vibrate：api.vibrate 触发震动。',
    'device：api.device 读取设备信息。',
    'camera：api.camera 拍照。',
    'location：api.location 获取定位。',
    'sensors：api.sensors 读取传感器。',
    'notification：api.notification 发送通知。',
    'files：api.files 读写应用私有文件。',
    'biometric：api.biometric 生物识别。',
    'quickCapture：api.quickCapture 通知栏快捷拍照。',
    'pluginBuild、exportFile 只给生成插件的元插件使用，普通插件不要声明。',
    '',
    '【代码约束】',
    '入口写法固定：module.exports = function ({ React, RN, api }) { return function App() { ... }; };',
    '界面只能用 React.createElement 构建，不要写 JSX。',
    '只能用 Promise 的 .then/.catch 链式写法；不要使用 async 关键字、等待语法或生成器语法。',
    '不要使用 require，不能依赖任何第三方包。',
    '可用组件仅限：View, Text, Button, TextInput, ScrollView, StyleSheet, Image, TouchableOpacity, FlatList, ActivityIndicator, RefreshControl。',
    '可用能力仅限 api.storage、api.fetch、api.fetchStream、api.clipboard、api.vibrate、api.device、api.camera、api.location、api.sensors、api.notification、api.files、api.biometric、api.quickCapture。',
    '不要访问 window、document、localStorage 等浏览器对象。',
    '',
    '【体积与稳健性】',
    'index.js 不得超过 2MB，建议控制在 50KB 以内；图标不超过 512KB。',
    '代码要简洁可运行，中文界面，捕获错误并在界面上提示，不要静默失败。',
    '没有图标数据时不要在 manifest 里写 icon，iconBase64 固定返回 null。',
  ].join('\n');


  function nowText(ts) {
    var d = new Date(ts);
    var pad = function (n) { return n < 10 ? '0' + n : '' + n; };
    return pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  function maskKey(key) {
    var value = String(key || '');
    if (!value) return '';
    if (value.length <= 10) return '••••••';
    return value.slice(0, 4) + '••••' + value.slice(-4);
  }

  // 去掉 AI 偶尔带出的 ``` 包裹，截取第一个 { 到最后一个 }
  function extractJson(text) {
    var s = String(text || '').trim();
    var start = s.indexOf('{');
    var end = s.lastIndexOf('}');
    if (start >= 0 && end > start) s = s.slice(start, end + 1);
    return s;
  }

  function parsePayload(text) {
    var json;
    try {
      json = JSON.parse(extractJson(text));
    } catch (err) {
      throw new Error('AI 返回的不是合法 JSON：' + String(text || '').slice(0, 200));
    }
    if (!json || !json.manifest || typeof json.manifest !== 'object') {
      throw new Error('AI 返回缺少 manifest 对象');
    }
    if (typeof json.indexJs !== 'string' || !json.indexJs.trim()) {
      throw new Error('AI 返回缺少 indexJs 代码');
    }
    return json;
  }

  function buildFiles(payload) {
    var files = {};
    files['manifest.json'] = JSON.stringify(payload.manifest, null, 2);
    files['index.js'] = payload.indexJs;
    if (payload.iconBase64 && payload.manifest.icon) {
      files[payload.manifest.icon] = { base64: String(payload.iconBase64) };
    }
    return files;
  }

  function normalizeBase(url) {
    return String(url || '').trim().replace(/\/+$/, '');
  }

  function chatUrlOf(base) {
    var b = normalizeBase(base);
    if (/\/chat\/completions$/i.test(b)) return b;
    return b + '/chat/completions';
  }

  function modelsUrlOf(base) {
    var b = normalizeBase(base).replace(/\/chat\/completions$/i, '');
    return b + '/models';
  }

  function baseUrlHint(base) {
    var b = normalizeBase(base);
    if (!b) return '请填写 API 地址';
    if (/\/chat\/completions$/i.test(b)) {
      return '地址里包含了 /chat/completions。一般只需填服务根地址或 /v1，实际请求：' + b;
    }
    if (/\/v1$/i.test(b)) {
      return '实际请求：' + b + '/chat/completions';
    }
    return '实际请求：' + b + '/chat/completions\n（多数服务地址需以 /v1 结尾；DeepSeek 可只填 https://api.deepseek.com）';
  }

  function fmtDuration(ms) {
    var value = Number(ms) || 0;
    if (value < 1000) return Math.round(value) + ' ms';
    return (value / 1000).toFixed(1) + ' 秒';
  }

  function truncate(text, max) {
    var s = String(text || '');
    if (s.length <= max) return s;
    return s.slice(0, max) + '…（共 ' + s.length + ' 字符）';
  }

  function phaseLabel(phase) {
    if (phase === 'connecting') return '连接阶段（DNS/TCP/TLS）';
    if (phase === 'waiting') return '等待响应阶段（已建立连接，模型尚未返回）';
    if (phase === 'reading') return '接收响应阶段（已开始返回数据）';
    return '请求阶段';
  }

  function makeRequestError(message, meta) {
    var err = new Error(message);
    err.name = 'RequestError';
    Object.keys(meta || {}).forEach(function (key) { err[key] = meta[key]; });
    return err;
  }

  function timeoutMsOf(config) {
    var sec = Number(config.timeoutSec);
    if (!sec || isNaN(sec)) sec = DEFAULT_TIMEOUT_SEC;
    sec = Math.max(MIN_TIMEOUT_SEC, Math.min(MAX_TIMEOUT_SEC, sec));
    return Math.round(sec * 1000);
  }

  function maxTokensOf(config) {
    var value = Number(config.maxTokens);
    if (isNaN(value)) return DEFAULT_MAX_TOKENS;
    value = Math.floor(value);
    if (value <= 0) return 0;
    return Math.min(200000, value);
  }

  // 读取 SSE：按行拆 data:，只把 delta.content 当成最终答案，
  // delta.reasoning_content 单独累计仅用于实时预览，避免把推理过程误当 JSON。
  function createSseReader(onText) {
    var buffer = '';
    var text = '';
    var reasoning = '';
    var finishReason = '';
    var sawSse = false;

    var handleLine = function (line) {
      line = String(line || '').replace(/\r$/, '');
      if (line.indexOf('data:') !== 0) return;
      var data = line.slice(5).trim();
      if (!data) return;
      sawSse = true;
      if (data === '[DONE]') return;
      var json;
      try {
        json = JSON.parse(data);
      } catch (e) {
        return;
      }
      var choice = json && json.choices && json.choices[0];
      if (choice && choice.finish_reason) finishReason = choice.finish_reason;
      var delta = choice && (choice.delta || choice.message);
      if (!delta) return;
      var piece = typeof delta.content === 'string' ? delta.content : '';
      var think = typeof delta.reasoning_content === 'string' ? delta.reasoning_content : '';
      if (think) reasoning += think;
      if (piece) text += piece;
      if ((piece || think) && onText) onText(text || reasoning, text.length > 0);
    };

    return {
      feed: function (chunk) {
        buffer += chunk;
        var index;
        while ((index = buffer.indexOf('\n')) >= 0) {
          handleLine(buffer.slice(0, index));
          buffer = buffer.slice(index + 1);
        }
      },
      flush: function () {
        if (buffer) {
          handleLine(buffer);
          buffer = '';
        }
      },
      getText: function () { return text; },
      getReasoning: function () { return reasoning; },
      getFinishReason: function () { return finishReason; },
      sawSse: function () { return sawSse; },
    };
  }

  function parseChatJson(text, url, meta) {
    var json;
    try {
      json = JSON.parse(text);
    } catch (e) {
      throw makeRequestError('接口返回的不是完整 JSON（可能被截断）', {
        url: url,
        status: meta.status,
        body: text,
        elapsedMs: meta.elapsedMs,
        phase: meta.phase || 'reading',
      });
    }
    var choice = json && json.choices && json.choices[0];
    var content = choice && choice.message && choice.message.content;
    if (typeof content !== 'string' || !content.trim()) {
      throw makeRequestError('接口返回缺少 choices[0].message.content', {
        url: url,
        status: meta.status,
        body: text,
        elapsedMs: meta.elapsedMs,
        phase: meta.phase || 'reading',
      });
    }
    return { content: content, finishReason: choice.finish_reason || '' };
  }

  function finishResult(content, meta, finishReason, streamed) {
    return {
      content: content,
      url: meta.url,
      status: meta.status,
      statusText: meta.statusText || '',
      elapsedMs: meta.elapsedMs || 0,
      bytes: meta.bytes || 0,
      streamed: !!streamed,
      finishReason: finishReason || '',
      truncated: finishReason === 'length',
    };
  }

  function decorateError(err, url, timeoutMs) {
    if (!err) return new Error('请求失败');
    if (!err.url) err.url = url;
    if (!err.phase) err.phase = 'waiting';
    if (!err.phaseLabel) err.phaseLabel = phaseLabel(err.phase);
    if (!err.timeoutMs) err.timeoutMs = timeoutMs;
    return err;
  }

  function describeRequestError(err, config) {
    var lines = [];
    var phase = err.phaseLabel || phaseLabel(err.phase);
    var isTimeout = err.name === 'TimeoutError' || err.kind === 'timeout';

    if (isTimeout) {
      lines.push('请求超时：' + phase);
    } else if (err.status && err.status !== 200) {
      lines.push('接口返回 HTTP ' + err.status + (err.statusText ? ' ' + err.statusText : ''));
    } else if (err.status === 200 && err.message) {
      lines.push(err.message);
    } else {
      lines.push((err.message || '请求失败') + '（' + phase + '）');
    }

    lines.push('阶段：' + phase);
    lines.push('实际请求：' + (err.url || chatUrlOf(config.baseUrl)));
    if (err.elapsedMs || isTimeout) {
      lines.push('耗时：' + fmtDuration(err.elapsedMs) + (err.timeoutMs ? '，超时上限 ' + fmtDuration(err.timeoutMs) : ''));
    }
    if (err.body) {
      lines.push('服务端返回：' + truncate(err.body, 300));
    }

    if (isTimeout) {
      if (err.phase === 'connecting') {
        lines.push('建议：连接阶段超时，重点检查域名解析、VPN/代理是否放行、端口是否被拦截。');
      } else if (err.phase === 'waiting') {
        lines.push('建议：已连上服务但模型未返回。可提高超时时间、换更快的模型，或检查服务商是否在排队。');
      } else {
        lines.push('建议：已开始接收但长时间没有新数据，可能是代理断开或服务端卡住；可重试。');
      }
    } else if (err.status === 401 || err.status === 403) {
      lines.push('建议：鉴权失败，检查 API Key 是否正确、是否多了空格，以及账户是否有该模型权限。');
    } else if (err.status === 404) {
      lines.push('建议：地址或路径不对。OpenAI 兼容服务通常需要 /v1；DeepSeek 可只填 https://api.deepseek.com。');
    } else if (err.status === 429) {
      lines.push('建议：触发限流或额度不足，请稍后再试或检查账户余额。');
    } else if (err.status >= 500) {
      lines.push('建议：服务端异常，稍后重试或切换服务商。');
    } else if (err.name === 'NetworkError') {
      lines.push('建议：连接失败，检查 VPN、代理、DNS 与网络是否可用。');
    }
    return lines.join('\n');
  }

  function simpleGet(url, headers, timeoutMs) {
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, timeoutMs);
    var started = Date.now();
    return api.fetch(url, {
      method: 'GET',
      headers: headers,
      signal: controller.signal,
    }).then(function (res) {
      return res.text().then(function (text) {
        clearTimeout(timer);
        if (!res.ok) {
          throw makeRequestError('HTTP ' + res.status, {
            url: url,
            status: res.status,
            body: text,
            elapsedMs: Date.now() - started,
            phase: 'reading',
          });
        }
        return { text: text, status: res.status, elapsedMs: Date.now() - started, url: url };
      });
    }).catch(function (err) {
      clearTimeout(timer);
      if (err && err.name === 'AbortError') {
        throw makeRequestError('等待模型列表超时', {
          url: url,
          phase: 'waiting',
          elapsedMs: Date.now() - started,
          timeoutMs: timeoutMs,
          status: 0,
        });
      }
      throw decorateError(err, url, timeoutMs);
    });
  }

  function fetchModels(config) {
    var url = modelsUrlOf(config.baseUrl);
    var headers = {
      Authorization: 'Bearer ' + config.apiKey,
      Accept: 'application/json',
    };
    var request = typeof api.fetchStream === 'function'
      ? api.fetchStream(url, { method: 'GET', headers: headers, timeoutMs: 15000 }, {}).then(function (res) {
          return { text: res.text, status: res.status, elapsedMs: res.elapsedMs, url: url };
        })
      : simpleGet(url, headers, 15000);
    return request.then(function (res) {
      var json;
      try {
        json = JSON.parse(res.text);
      } catch (e) {
        throw makeRequestError('/models 返回的不是 JSON', {
          url: url,
          status: res.status,
          body: res.text,
          elapsedMs: res.elapsedMs,
        });
      }
      var list = json.data || json.models || [];
      var ids = list.map(function (item) {
        return item && (item.id || item.name);
      }).filter(function (id) { return typeof id === 'string' && id; });
      return { url: url, status: res.status, elapsedMs: res.elapsedMs, ids: ids };
    });
  }

  function requestAIFetch(config, url, bodyText, headers, timeoutMs, handlers, started) {
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, timeoutMs);
    return api.fetch(url, {
      method: 'POST',
      headers: headers,
      body: bodyText,
      signal: controller.signal,
    }).then(function (res) {
      return res.text().then(function (text) {
        clearTimeout(timer);
        if (!res.ok) {
          throw makeRequestError('HTTP ' + res.status, {
            url: url,
            status: res.status,
            body: text,
            elapsedMs: Date.now() - started,
            phase: 'reading',
          });
        }
        var parsed = parseChatJson(text, url, { status: res.status, elapsedMs: Date.now() - started });
        if (handlers.onProgress) {
          handlers.onProgress({ phase: 'reading', elapsedMs: Date.now() - started, status: res.status, preview: parsed.content });
        }
        return finishResult(parsed.content, { url: url, status: res.status, elapsedMs: Date.now() - started }, parsed.finishReason, false);
      });
    }).catch(function (err) {
      clearTimeout(timer);
      if (err && err.name === 'AbortError') {
        throw makeRequestError('请求超时', {
          url: url,
          phase: 'waiting',
          phaseLabel: phaseLabel('waiting'),
          status: 0,
          body: '',
          elapsedMs: Date.now() - started,
          timeoutMs: timeoutMs,
        });
      }
      throw decorateError(err, url, timeoutMs);
    });
  }

  /**
   * 调用 OpenAI 兼容接口。优先走流式（边收边回调），不支持时回退普通请求。
   * 返回 { content, url, status, elapsedMs, bytes, streamed, finishReason, truncated }
   */
  function requestAI(config, messages, handlers) {
    var base = normalizeBase(config.baseUrl);
    if (!base) return Promise.reject(new Error('请先配置 API 地址'));
    if (!config.apiKey) return Promise.reject(new Error('请先配置 API Key'));
    if (!config.model) return Promise.reject(new Error('请先配置模型名'));

    var url = chatUrlOf(base);
    var timeoutMs = timeoutMsOf(config);
    var stream = config.stream !== false;
    var body = {
      model: config.model,
      temperature: 0.2,
      messages: messages,
      stream: stream,
    };
    var maxTokens = maxTokensOf(config);
    if (maxTokens > 0) body.max_tokens = maxTokens;

    var bodyText = JSON.stringify(body);
    var headers = {
      'Content-Type': 'application/json; charset=utf-8',
      Authorization: 'Bearer ' + config.apiKey,
      Accept: stream ? 'text/event-stream, application/json' : 'application/json',
    };
    var events = handlers || {};
    var started = Date.now();

    if (stream && typeof api.fetchStream === 'function') {
      var reader = createSseReader(function (live) {
        if (events.onProgress) {
          events.onProgress({
            phase: 'reading',
            elapsedMs: Date.now() - started,
            preview: live,
            status: 0,
          });
        }
      });
      var raw = '';
      return api.fetchStream(url, {
        method: 'POST',
        headers: headers,
        body: bodyText,
        timeoutMs: timeoutMs,
      }, {
        onPhase: function (info) {
          if (events.onProgress) {
            events.onProgress({
              phase: info.phase,
              phaseLabel: info.phaseLabel,
              status: info.status,
              elapsedMs: info.elapsedMs,
              preview: reader.getText(),
            });
          }
        },
        onChunk: function (chunk, info) {
          raw += chunk;
          reader.feed(chunk);
          if (events.onProgress) {
            events.onProgress({
              phase: 'reading',
              status: info.status,
              elapsedMs: info.elapsedMs,
              bytes: info.bytes,
              preview: reader.getText() || reader.getReasoning(),
              thinking: !reader.getText() && !!reader.getReasoning(),
            });
          }
        },
      }).then(function (res) {
        reader.flush();
        var text = reader.getText();
        if (!text) {
          if (reader.sawSse()) {
            var think = reader.getReasoning();
            var reason = think
              ? '模型只返回了推理内容（reasoning_content），没有最终答案；通常是 max_tokens 被推理过程耗尽（finish_reason=' +
                (reader.getFinishReason() || '未知') + '），请把「最大输出 tokens」调大到 16384 或 32768 后重试。'
              : 'SSE 响应里没有可用的 delta.content';
            throw makeRequestError(reason, {
              url: url,
              status: res.status,
              body: think ? think.slice(-600) : raw || res.text,
              elapsedMs: res.elapsedMs,
              phase: res.phase,
              finishReason: reader.getFinishReason(),
            });
          }
          var parsed = parseChatJson(raw || res.text, url, res);
          return finishResult(
            parsed.content,
            { url: url, status: res.status, statusText: res.statusText, elapsedMs: res.elapsedMs, bytes: res.bytes },
            parsed.finishReason,
            false
          );
        }
        return finishResult(
          text,
          { url: url, status: res.status, statusText: res.statusText, elapsedMs: res.elapsedMs, bytes: res.bytes },
          reader.getFinishReason(),
          true
        );
      }).catch(function (err) {
        throw decorateError(err, url, timeoutMs);
      });
    }

    return requestAIFetch(config, url, bodyText, headers, timeoutMs, events, started);
  }


  function ActionButton(props) {
    return e(
      TouchableOpacity,
      {
        style: [
          styles.btn,
          props.primary ? styles.btnPrimary : null,
          props.danger ? styles.btnDanger : null,
          props.disabled || props.loading ? styles.btnDisabled : null,
          props.style || null,
        ],
        disabled: props.disabled || props.loading,
        onPress: props.onPress,
      },
      props.loading
        ? e(ActivityIndicator, { size: 'small', color: '#fff' })
        : e(Text, { style: [styles.btnText, props.primary || props.danger ? styles.btnTextLight : null] }, props.title)
    );
  }

  function Section(props) {
    return e(View, { style: styles.card },
      props.title ? e(Text, { style: styles.cardTitle }, props.title) : null,
      props.children
    );
  }

  return function AiPluginBuilder() {
    var [tab, setTab] = React.useState('generate');
    var [baseUrl, setBaseUrl] = React.useState(DEFAULT_BASE);
    var [model, setModel] = React.useState(DEFAULT_MODEL);
    var [apiKey, setApiKey] = React.useState('');
    var [keyDraft, setKeyDraft] = React.useState('');
    var [editingKey, setEditingKey] = React.useState(false);
    var [timeoutSec, setTimeoutSec] = React.useState(String(DEFAULT_TIMEOUT_SEC));
    var [maxTokens, setMaxTokens] = React.useState(String(DEFAULT_MAX_TOKENS));
    var [streamOn, setStreamOn] = React.useState(true);
    var [skill, setSkill] = React.useState(DEFAULT_SKILL);
    var [models, setModels] = React.useState([]);
    var [modelsInfo, setModelsInfo] = React.useState('');
    var [fetchingModels, setFetchingModels] = React.useState(false);
    var [testInfo, setTestInfo] = React.useState('');
    var [progress, setProgress] = React.useState(null);
    var [formatRetry, setFormatRetry] = React.useState(null);
    var [prompt, setPrompt] = React.useState('');
    var [busy, setBusy] = React.useState(false);
    var [status, setStatus] = React.useState('');
    var [error, setError] = React.useState('');
    var [current, setCurrent] = React.useState(null);
    var [viewFile, setViewFile] = React.useState('index.js');
    var [history, setHistory] = React.useState([]);
    var [catalog, setCatalog] = React.useState([]);
    var [confirming, setConfirming] = React.useState(false);
    var [working, setWorking] = React.useState('');

    React.useEffect(function () {
      Promise.all([
        api.storage.get(KEYS.baseUrl),
        api.storage.get(KEYS.apiKey),
        api.storage.get(KEYS.model),
        api.storage.get(KEYS.timeout),
        api.storage.get(KEYS.maxTokens),
        api.storage.get(KEYS.stream),
        api.storage.get(KEYS.skill),
        api.storage.get(KEYS.history),
      ]).then(function (values) {
        if (values[0]) setBaseUrl(values[0]);
        if (values[1]) setApiKey(values[1]);
        if (values[2]) setModel(values[2]);
        if (values[3]) setTimeoutSec(values[3]);
        if (values[4]) setMaxTokens(values[4]);
        if (values[5] !== null && values[5] !== undefined) setStreamOn(values[5] !== 'false');
        if (values[6]) setSkill(values[6]);
        if (values[7]) {
          try {
            var list = JSON.parse(values[7]);
            if (Array.isArray(list)) setHistory(list);
          } catch (err) {}
        }
      }).catch(function () {});
      api.pluginBuilder.catalog().then(function (list) {
        setCatalog(list || []);
      }).catch(function () {});
    }, []);

    var configNow = function () {
      return {
        baseUrl: baseUrl,
        apiKey: apiKey,
        model: String(model || '').trim(),
        timeoutSec: Number(timeoutSec) || DEFAULT_TIMEOUT_SEC,
        maxTokens: Number(maxTokens),
        stream: streamOn,
      };
    };

    var fail = function (err) {
      setBusy(false);
      setWorking('');
      setProgress(null);
      if (err && (err.url || err.status || err.phase || err.kind)) {
        setError(describeRequestError(err, configNow()));
      } else {
        setError((err && err.message) || String(err));
      }
    };

    var saveConfig = function () {
      var sec = Math.max(MIN_TIMEOUT_SEC, Math.min(MAX_TIMEOUT_SEC, Number(timeoutSec) || DEFAULT_TIMEOUT_SEC));
      var tokens = Math.floor(Number(maxTokens));
      if (isNaN(tokens) || tokens < 0) tokens = DEFAULT_MAX_TOKENS;
      setTimeoutSec(String(sec));
      setMaxTokens(String(tokens));
      Promise.all([
        api.storage.set(KEYS.baseUrl, normalizeBase(baseUrl)),
        api.storage.set(KEYS.model, String(model || '').trim()),
        api.storage.set(KEYS.timeout, String(sec)),
        api.storage.set(KEYS.maxTokens, String(tokens)),
        api.storage.set(KEYS.stream, streamOn ? 'true' : 'false'),
      ]).then(function () {
        setStatus('配置已保存（超时 ' + sec + ' 秒，最大输出 ' + (tokens || '不限制') + ' tokens）');
        setError('');
      }).catch(fail);
    };

    var saveKey = function () {
      var next = String(keyDraft || '').trim();
      api.storage.set(KEYS.apiKey, next).then(function () {
        setApiKey(next);
        setKeyDraft('');
        setEditingKey(false);
        setStatus(next ? 'API Key 已保存在本机（仅脱敏显示）' : '已清除 API Key');
        setError('');
      }).catch(fail);
    };

    var saveSkill = function () {
      var next = String(skill || '').trim() ? String(skill) : DEFAULT_SKILL;
      api.storage.set(KEYS.skill, next).then(function () {
        setSkill(next);
        setStatus('Skill 已保存，之后生成会自动带上');
        setError('');
      }).catch(fail);
    };

    var restoreSkill = function () {
      setSkill(DEFAULT_SKILL);
      api.storage.set(KEYS.skill, DEFAULT_SKILL).catch(function () {});
      setStatus('已恢复默认 Skill');
      setError('');
    };

    var applyPreset = function (preset) {
      setBaseUrl(preset.baseUrl);
      setModel(preset.model);
      setModels([]);
      setModelsInfo('已填入「' + preset.label + '」预设，可点「拉取模型」按 /models 校正');
      setTestInfo('');
      setStatus('已填入 ' + preset.label + ' 预设，仍可手动修改');
      setError('');
    };

    var fetchModelsNow = function (showState) {
      var cfg = configNow();
      if (!cfg.apiKey) {
        setModelsInfo('请先填写 API Key');
        return Promise.reject(new Error('请先填写 API Key'));
      }
      if (showState) setFetchingModels(true);
      return fetchModels(cfg).then(function (result) {
        setModels(result.ids);
        var extra = '';
        if (result.ids.length && result.ids.indexOf(cfg.model) < 0) {
          extra = '；当前模型「' + cfg.model + '」不在列表里，可点选下方模型';
        }
        setModelsInfo('已从 ' + result.url + ' 获取 ' + result.ids.length + ' 个模型（' + fmtDuration(result.elapsedMs) + '）' + extra);
        setFetchingModels(false);
        return result;
      }).catch(function (err) {
        var detail = err && err.body ? truncate(err.body, 160) : ((err && err.message) || String(err));
        setModelsInfo('获取模型列表失败：' + (err && err.status ? 'HTTP ' + err.status + ' ' : '') + detail);
        setFetchingModels(false);
        throw err;
      });
    };

    var shortError = function (err) {
      if (!err) return '未知错误';
      var head = err.status ? 'HTTP ' + err.status : (err.message || '请求失败');
      return err.body ? head + '：' + truncate(err.body, 120) : head;
    };

    var testConnection = function () {
      var cfg = configNow();
      if (!apiKey) {
        setError('请先在「配置」里填写 API Key');
        setTab('config');
        return;
      }
      cfg.stream = false;
      cfg.maxTokens = 16;
      setBusy(true);
      setWorking('正在测试连接');
      setError('');
      setStatus('');
      setTestInfo('');

      var modelsResult = null;
      var modelsError = null;

      fetchModels(cfg).then(function (result) {
        modelsResult = result;
        setModels(result.ids);
        return null;
      }).catch(function (err) {
        modelsError = err;
        return null;
      }).then(function () {
        return requestAI(cfg, [{ role: 'user', content: '只回复 OK' }], {});
      }).then(function (res) {
        var lines = ['连接成功'];
        lines.push('实际请求：' + res.url);
        lines.push('HTTP ' + res.status + ' · 耗时 ' + fmtDuration(res.elapsedMs));
        if (modelsResult) {
          var names = modelsResult.ids.slice(0, 10).join(', ');
          lines.push('模型列表：' + modelsResult.ids.length + ' 个' + (names ? '（' + names + (modelsResult.ids.length > 10 ? '…' : '') + '）' : ''));
        } else {
          lines.push('模型列表不可用：' + shortError(modelsError) + '（不影响生成）');
        }
        var hint = baseUrlHint(cfg.baseUrl);
        if (hint) lines.push(hint);
        setTestInfo(lines.join('\n'));
        setBusy(false);
        setWorking('');
        setStatus('连接成功');
      }).catch(function (err) {
        // 推理型模型可能把 max_tokens 全用在 reasoning 上，content 为空但连接是通的
        if (err && err.status === 200) {
          var lines2 = ['连接成功（HTTP 200，但正文为空）'];
          lines2.push('实际请求：' + err.url);
          lines2.push('耗时：' + fmtDuration(err.elapsedMs));
          lines2.push('服务端返回：' + truncate(err.body, 200));
          lines2.push('说明：该模型可能把输出额度用在了推理内容上，生成时会把最大输出 tokens 调大。');
          if (modelsResult) {
            lines2.push('模型列表：' + modelsResult.ids.join(', '));
          }
          setTestInfo(lines2.join('\n'));
          setBusy(false);
          setWorking('');
          setStatus('连接成功');
          return;
        }
        var base = normalizeBase(cfg.baseUrl);
        if (err && err.status === 404 && !/\/v1$/i.test(base) && !/\/chat\/completions$/i.test(base)) {
          var altBase = base + '/v1';
          var altCfg = Object.assign({}, cfg, { baseUrl: altBase });
          requestAI(altCfg, [{ role: 'user', content: '只回复 OK' }], {}).then(function (res) {
            setTestInfo([
              '当前地址返回 404，但补上 /v1 后连接成功',
              '建议把 API 地址改为：' + altBase,
              '实际请求：' + res.url,
              'HTTP ' + res.status + ' · 耗时 ' + fmtDuration(res.elapsedMs),
            ].join('\n'));
            setBusy(false);
            setWorking('');
            setStatus('连接成功（建议补 /v1）');
          }).catch(function () {
            setBusy(false);
            setWorking('');
            setError(describeRequestError(err, cfg));
          });
          return;
        }
        setBusy(false);
        setWorking('');
        setError(describeRequestError(err, cfg));
      });
    };

    var saveHistory = function (entry) {
      setHistory(function (prev) {
        var next = [entry].concat(prev).slice(0, HISTORY_LIMIT);
        api.storage.set(KEYS.history, JSON.stringify(next)).catch(function () {});
        return next;
      });
    };

    var applyResult = function (payload, userPrompt, meta) {
      var files = buildFiles(payload);
      setCurrent(null);
      setStatus('正在校验生成结果');
      return api.pluginBuilder.validate(files).then(function (check) {
        var warnings = (check.warnings || []).slice();
        if (meta && meta.truncated) {
          warnings.push('模型输出达到 max_tokens 上限（finish_reason=length），代码可能被截断；可在「配置」里调大最大输出 tokens');
        }
        var entry = {
          createdAt: Date.now(),
          prompt: userPrompt,
          raw: JSON.stringify(payload),
          files: files,
          manifest: check.manifest || payload.manifest,
          ok: check.ok,
          errors: check.errors || [],
          warnings: warnings,
          elapsedMs: meta ? meta.elapsedMs : 0,
          streamed: meta ? meta.streamed : false,
          truncated: meta ? meta.truncated : false,
        };
        setCurrent(entry);
        setViewFile('index.js');
        setConfirming(false);
        setBusy(false);
        setWorking('');
        setProgress(null);
        var timing = meta
          ? '（' + (meta.streamed ? '流式接收 ' : '总耗时 ') + fmtDuration(meta.elapsedMs) + '，HTTP ' + meta.status + '）'
          : '';
        if (check.ok) {
          setStatus('校验通过' + timing + (warnings.length ? '；提示：' + warnings.join('；') : ''));
        } else {
          setStatus('校验未通过' + timing + '，请让 AI 修正后重试');
        }
        saveHistory(entry);
        return entry;
      });
    };

    var runGeneration = function (userPrompt, messages, workingText) {
      setBusy(true);
      setWorking(workingText);
      setError('');
      setStatus('');
      setProgress(null);
      setFormatRetry(null);
      setConfirming(false);

      var lastUpdate = 0;
      var lastPhase = '';
      var onProgress = function (info) {
        var now = Date.now();
        // 阶段切换必须立即展示；只有接收中的高频预览做节流
        if (info.phase !== lastPhase) {
          lastPhase = info.phase;
          lastUpdate = now;
          setProgress(info);
          return;
        }
        if (now - lastUpdate < 250) return;
        lastUpdate = now;
        setProgress(info);
      };

      requestAI(configNow(), messages, { onProgress: onProgress }).then(function (res) {
        setBusy(false);
        setWorking('');
        setProgress(null);
        var payload;
        try {
          payload = parsePayload(res.content);
        } catch (err) {
          var detail = err.message;
          if (res.truncated) {
            detail += '\n模型输出达到 max_tokens 上限（finish_reason=length），响应被截断；请调大最大输出 tokens 或简化需求。';
          }
          detail += '\n已接收 ' + res.content.length + ' 字符，耗时 ' + fmtDuration(res.elapsedMs) + '，HTTP ' + res.status + '。';
          detail += '\n可点「按 Skill 纠偏重试」，把格式要求和上次原始输出一起发回模型。';
          setError(detail);
          setFormatRetry({
            prompt: userPrompt,
            raw: res.content,
            elapsedMs: res.elapsedMs,
            status: res.status,
          });
          return null;
        }
        return applyResult(payload, userPrompt, res);
      }).catch(function (err) {
        fail(err);
      });
    };

    var generate = function () {
      var need = String(prompt || '').trim();
      if (!need) {
        setError('请先描述你想要的插件');
        return;
      }
      if (!apiKey) {
        setError('请先在「配置」里填写 API Key');
        setTab('config');
        return;
      }
      var currentSkill = String(skill || '').trim() || DEFAULT_SKILL;
      runGeneration(need, [
        { role: 'system', content: currentSkill },
        { role: 'user', content: '用户需求：\n' + need + '\n\n请严格按 Skill 输出单个 JSON 对象，包含 manifest 与 indexJs。' },
      ], 'AI 正在生成插件');
    };

    var repair = function () {
      if (!current) return;
      var problems = (current.errors || [])
        .map(function (item) { return '- ' + item.field + '：' + item.message; })
        .join('\n');
      var currentSkill = String(skill || '').trim() || DEFAULT_SKILL;
      runGeneration(current.prompt, [
        { role: 'system', content: currentSkill },
        {
          role: 'user',
          content:
            '下面这版插件未通过宿主校验，请逐条修正后重新输出完整 JSON。\n\n' +
            '原始需求：' + current.prompt + '\n\n' +
            '上一版 JSON：\n' + current.raw + '\n\n' +
            '具体校验错误：\n' + problems + '\n\n' +
            '请只返回修正后的完整 JSON，不要只给补丁或解释。',
        },
      ], 'AI 正在按校验问题修正');
    };

    var retryFormat = function () {
      if (!formatRetry) return;
      var currentSkill = String(skill || '').trim() || DEFAULT_SKILL;
      runGeneration(formatRetry.prompt, [
        { role: 'system', content: currentSkill },
        {
          role: 'user',
          content:
            '你上一次的输出没有满足 Skill 要求的 JSON 格式，无法解析。\n\n' +
            '用户需求：' + formatRetry.prompt + '\n\n' +
            '上一次原始输出（可能被截断）：\n' + truncate(formatRetry.raw, 6000) + '\n\n' +
            '请严格只输出 Skill 规定的单个 JSON 对象，必须包含 manifest 和 indexJs，不要代码块、不要解释。',
        },
      ], 'AI 正在按 Skill 纠偏');
    };

    var doExport = function () {
      if (!current) return;
      var mf = current.manifest || {};
      var name = (mf.id || 'plugin') + '-' + (mf.version || '0.0.0') + '.zip';
      setBusy(true);
      setWorking('正在打包导出');
      setError('');
      api.exportFile.zip(current.files, name).then(function (result) {
        setBusy(false);
        setWorking('');
        setStatus('已导出到 ' + result.path + '（' + result.size + ' 字节）');
      }).catch(fail);
    };

    var confirmInstall = function () {
      if (!current || !current.ok) return;
      setBusy(true);
      setWorking('正在安装插件');
      setError('');
      api.pluginBuilder.install(current.files).then(function (record) {
        setBusy(false);
        setWorking('');
        setConfirming(false);
        setStatus('已安装「' + record.name + '」v' + record.version + '，正在打开…');
        api.pluginBuilder.open(record.id, record.name).catch(function (err) {
          setError('安装成功，但打开失败：' + ((err && err.message) || String(err)));
        });
      }).catch(fail);
    };

    var loadHistory = function (item) {
      setCurrent(item);
      setPrompt(item.prompt || '');
      setViewFile('index.js');
      setConfirming(false);
      setError('');
      setTab('generate');
      setStatus(item.ok ? '已载入历史版本（校验通过）' : '已载入历史版本（当时未通过校验）');
    };

    var removeHistory = function (ts) {
      setHistory(function (prev) {
        var next = prev.filter(function (item) { return item.createdAt !== ts; });
        api.storage.set(KEYS.history, JSON.stringify(next)).catch(function () {});
        return next;
      });
      if (current && current.createdAt === ts) setCurrent(null);
    };

    var permissionLabel = function (key) {
      for (var i = 0; i < catalog.length; i += 1) {
        if (catalog[i].key === key) return catalog[i].label + '（' + key + '）';
      }
      return key;
    };
    var permissionDesc = function (key) {
      for (var i = 0; i < catalog.length; i += 1) {
        if (catalog[i].key === key) return catalog[i].desc;
      }
      return '';
    };

    var progressLabel = function () {
      if (!progress) return working || '处理中…';
      var elapsed = fmtDuration(progress.elapsedMs);
      if (progress.phase === 'connecting') {
        return '正在连接：' + (progress.url || chatUrlOf(baseUrl)) + '（已等待 ' + elapsed + '）';
      }
      if (progress.phase === 'waiting') {
        return '已建立连接（HTTP ' + (progress.status || '?') + '），等待模型返回…（' + elapsed + '）';
      }
      var size = progress.bytes ? progress.bytes + ' 字节 / ' : '';
      var chars = progress.preview ? progress.preview.length + ' 字符' : '';
      if (progress.thinking) {
        return '模型正在推理（reasoning_content）：' + size + chars + '（' + elapsed + '）';
      }
      return '正在接收响应：' + size + chars + '（' + elapsed + '）';
    };

    var renderConfig = function () {
      return e(View, null,
        e(Section, { title: 'AI 接口配置' },
          e(Text, { style: styles.hint }, '兼容 OpenAI 的 /chat/completions。先选服务商预设，也可以手动改地址和模型。'),
          e(Text, { style: styles.label }, '服务商预设'),
          e(View, { style: styles.chipRow },
            PRESETS.map(function (preset) {
              var active = normalizeBase(baseUrl) === preset.baseUrl;
              return e(TouchableOpacity, {
                key: preset.key,
                style: [styles.chip, active ? styles.chipActive : null],
                onPress: function () { applyPreset(preset); },
              }, e(Text, { style: active ? styles.chipTextActive : styles.chipText }, preset.label));
            })
          ),
          e(Text, { style: styles.label }, 'API 地址'),
          e(TextInput, {
            style: styles.input,
            value: baseUrl,
            onChangeText: function (v) { setBaseUrl(v); setStatus(''); },
            placeholder: 'https://api.deepseek.com',
            autoCapitalize: 'none',
            autoCorrect: false,
          }),
          e(Text, { style: styles.urlHint }, baseUrlHint(baseUrl)),
          e(Text, { style: styles.label }, '模型名'),
          e(TextInput, {
            style: styles.input,
            value: model,
            onChangeText: function (v) { setModel(v); setStatus(''); },
            placeholder: 'deepseek-chat',
            autoCapitalize: 'none',
            autoCorrect: false,
          }),
          e(View, { style: styles.row },
            e(ActionButton, {
              title: fetchingModels ? '拉取中…' : '拉取模型列表',
              onPress: function () { fetchModelsNow(true).catch(function () {}); },
              loading: fetchingModels,
              style: styles.flex1,
            }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '清空模型', onPress: function () { setModels([]); setModelsInfo(''); }, style: styles.flex1 })
          ),
          modelsInfo ? e(Text, { style: styles.modelsInfo }, modelsInfo) : null,
          models.length
            ? e(View, { style: styles.chipRow },
                models.slice(0, 60).map(function (id) {
                  var active = id === model;
                  return e(TouchableOpacity, {
                    key: id,
                    style: [styles.chip, active ? styles.chipActive : null],
                    onPress: function () { setModel(id); setStatus('已选择模型 ' + id); },
                  }, e(Text, { style: active ? styles.chipTextActive : styles.chipText }, id));
                })
              )
            : null,
          e(Text, { style: styles.label }, 'API Key'),
          editingKey
            ? e(View, null,
                e(TextInput, {
                  style: styles.input,
                  value: keyDraft,
                  onChangeText: setKeyDraft,
                  placeholder: 'sk-...',
                  autoCapitalize: 'none',
                  autoCorrect: false,
                  secureTextEntry: true,
                }),
                e(View, { style: styles.row },
                  e(ActionButton, { title: '保存 Key', primary: true, onPress: saveKey, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  e(ActionButton, { title: '取消', onPress: function () { setEditingKey(false); setKeyDraft(''); }, style: styles.flex1 })
                )
              )
            : e(View, null,
                e(Text, { style: styles.keyText }, apiKey ? '已保存：' + maskKey(apiKey) : '尚未配置'),
                e(View, { style: styles.row },
                  e(ActionButton, { title: apiKey ? '更换 Key' : '填写 Key', primary: true, onPress: function () { setEditingKey(true); }, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  apiKey ? e(ActionButton, { title: '清除', danger: true, onPress: function () { api.storage.remove(KEYS.apiKey).then(function () { setApiKey(''); setStatus('已清除 API Key'); }); }, style: styles.flex1 }) : null
                )
              ),
          e(Text, { style: styles.note }, 'Key 只保存在本机插件私有存储里，界面始终脱敏显示，不会回传或写入日志。'),
          e(Text, { style: styles.label }, '超时（秒）'),
          e(TextInput, {
            style: styles.input,
            value: String(timeoutSec),
            onChangeText: setTimeoutSec,
            placeholder: String(DEFAULT_TIMEOUT_SEC),
            keyboardType: 'numeric',
          }),
          e(Text, { style: styles.note }, '按空闲超时计算：连接或等待响应超过该时间算超时；收到流式数据后会重新计时，默认 ' + DEFAULT_TIMEOUT_SEC + ' 秒。'),
          e(Text, { style: styles.label }, '最大输出 tokens'),
          e(TextInput, {
            style: styles.input,
            value: String(maxTokens),
            onChangeText: setMaxTokens,
            placeholder: String(DEFAULT_MAX_TOKENS),
            keyboardType: 'numeric',
          }),
          e(Text, { style: styles.note }, '填 0 表示不主动限制；长代码被截断时可调大，例如 8192 或 16384。'),
          e(TouchableOpacity, {
            style: styles.toggleRow,
            onPress: function () { setStreamOn(!streamOn); },
          },
            e(Text, { style: styles.toggleLabel }, '流式接收'),
            e(Text, { style: streamOn ? styles.toggleOn : styles.toggleOff }, streamOn ? '已开启（边收边显示）' : '已关闭（等完整响应）')
          ),
          e(View, { style: styles.row },
            e(ActionButton, { title: '保存配置', primary: true, onPress: saveConfig, style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '测试连接', onPress: testConnection, loading: busy && working === '正在测试连接', style: styles.flex1 })
          )
        ),
        status ? e(Text, { style: styles.statusText }, status) : null,
        error ? e(View, { style: styles.errorBox }, e(Text, { style: styles.errorTitle }, '出错了'), e(Text, { style: styles.errorLine }, error)) : null,
        testInfo ? e(Section, { title: '连接测试结果' }, e(Text, { style: styles.testInfo }, testInfo)) : null,
        e(Section, { title: '说明' },
          e(Text, { style: styles.hint }, '· 生成结果会先做宿主校验：manifest 必填字段、id 格式、SemVer、入口路径、权限白名单、入口语法扫描。'),
          e(Text, { style: styles.hint }, '· 安装复用现有安装管线，不能绕过校验；装完可在已安装列表里看到，也可直接打开。'),
          e(Text, { style: styles.hint }, '· AI 生成的代码属于不可信内容，安装前请确认权限清单；首次运行宿主仍会再次确认。')
        )
      );
    };

    var renderResult = function () {
      if (!current) return null;
      var mf = current.manifest || {};
      var perms = Array.isArray(mf.permissions) ? mf.permissions : [];
      var fileContent = current.files[viewFile];
      var text = typeof fileContent === 'string' ? fileContent : '[二进制文件]';
      return e(View, null,
        e(Section, { title: '生成结果' },
          e(View, { style: styles.rowBetween },
            e(Text, { style: styles.resultName }, mf.name || mf.id || '未命名插件'),
            e(Text, { style: current.ok ? styles.badgeOk : styles.badgeBad }, current.ok ? '校验通过' : '校验未通过')
          ),
          e(Text, { style: styles.hint }, 'id：' + (mf.id || '-') + '\n版本：' + (mf.version || '-') + '\n入口：' + (mf.entry || '-') + '\n描述：' + (mf.description || '无')),
          e(Text, { style: styles.label }, '将要申请的权限（' + perms.length + '）'),
          perms.length === 0
            ? e(Text, { style: styles.hint }, '无受限权限')
            : perms.map(function (key) {
                return e(View, { key: key, style: styles.permRow },
                  e(Text, { style: styles.permLabel }, permissionLabel(key)),
                  e(Text, { style: styles.permDesc }, permissionDesc(key))
                );
              }),
          current.warnings && current.warnings.length
            ? e(Text, { style: styles.warnText }, '提示：' + current.warnings.join('；'))
            : null,
          !current.ok
            ? e(View, { style: styles.errorBox },
                e(Text, { style: styles.errorTitle }, '未通过校验的问题'),
                (current.errors || []).map(function (item, idx) {
                  return e(Text, { key: idx, style: styles.errorLine }, '· ' + item.field + '：' + item.message);
                }),
                e(View, { style: styles.row },
                  e(ActionButton, { title: '让 AI 修正', primary: true, onPress: repair, loading: busy && working === 'AI 正在按校验问题修正', style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  e(ActionButton, { title: '重新生成', onPress: generate, style: styles.flex1 })
                )
              )
            : null,
          e(View, { style: styles.fileTabs },
            ['manifest.json', 'index.js'].filter(function (name) { return current.files[name]; }).map(function (name) {
              return e(TouchableOpacity, {
                key: name,
                style: [styles.fileTab, viewFile === name ? styles.fileTabActive : null],
                onPress: function () { setViewFile(name); },
              }, e(Text, { style: viewFile === name ? styles.fileTabTextActive : styles.fileTabText }, name));
            })
          ),
          e(ScrollView, { horizontal: true, style: styles.codeBox },
            e(Text, { style: styles.code }, text)
          )
        ),
        e(Section, { title: '操作' },
          e(View, { style: styles.row },
            e(ActionButton, { title: '导出 zip', onPress: doExport, loading: busy && working === '正在打包导出', style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '安装并打开', primary: true, disabled: !current.ok, onPress: function () { setConfirming(true); setError(''); }, style: styles.flex1 })
          ),
          confirming
            ? e(View, { style: styles.confirmBox },
                e(Text, { style: styles.confirmTitle }, '确认安装「' + (mf.name || mf.id) + '」？'),
                e(Text, { style: styles.hint }, '这个插件将申请以下权限：'),
                perms.length === 0
                  ? e(Text, { style: styles.hint }, '无受限权限')
                  : perms.map(function (key) {
                      return e(Text, { key: key, style: styles.confirmPerm }, '· ' + permissionLabel(key) + '：' + permissionDesc(key));
                    }),
                e(Text, { style: styles.warnText }, 'AI 生成的代码属于不可信内容。安装会复用宿主校验与权限管线，首次运行仍会要求你再次确认权限。'),
                e(View, { style: styles.row },
                  e(ActionButton, { title: '取消', onPress: function () { setConfirming(false); }, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  e(ActionButton, { title: '确认安装并打开', primary: true, onPress: confirmInstall, loading: busy && working === '正在安装插件', style: styles.flex1 })
                )
              )
            : null
        )
      );
    };

    var renderGenerate = function () {
      return e(View, null,
        e(Section, { title: '描述你想要的插件' },
          e(Text, { style: styles.hint }, '例如：一个番茄钟，可设置 25 分钟专注与 5 分钟休息，开始后显示倒计时，结束时震动提醒。'),
          e(Text, { style: styles.label }, '快速示例'),
          e(View, { style: styles.chipRow },
            EXAMPLES.map(function (item) {
              return e(TouchableOpacity, {
                key: item.label,
                style: styles.chip,
                onPress: function () { setPrompt(item.text); setStatus('已填入示例需求，可直接生成'); setError(''); },
              }, e(Text, { style: styles.chipText }, item.label));
            })
          ),
          e(TextInput, {
            style: [styles.input, styles.promptInput],
            value: prompt,
            onChangeText: function (v) { setPrompt(v); setStatus(''); },
            placeholder: '用一句话说清功能、交互与需要保存的数据…',
            multiline: true,
            textAlignVertical: 'top',
          }),
          e(View, { style: styles.row },
            e(ActionButton, { title: '生成插件', primary: true, onPress: generate, loading: busy && working === 'AI 正在生成插件', style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '清空', onPress: function () { setPrompt(''); setCurrent(null); setStatus(''); setError(''); setConfirming(false); }, style: styles.flex1 })
          ),
          e(Text, { style: styles.note }, '生成会调用你在「配置」里填写的 AI 接口，可能产生费用。生成结果会先本地校验，不会自动安装。')
        ),
        busy
          ? e(View, { style: styles.progressBox },
              e(View, { style: styles.progressHead },
                e(ActivityIndicator, { size: 'small' }),
                e(Text, { style: styles.progressLabel }, progressLabel())
              ),
              progress && progress.preview
                ? e(ScrollView, { style: styles.progressPreview },
                    e(Text, { style: styles.progressText }, progress.preview.slice(-500))
                  )
                : null
            )
          : null,
        status ? e(Text, { style: styles.statusText }, status) : null,
        error
          ? e(View, { style: styles.errorBox },
              e(Text, { style: styles.errorTitle }, '出错了'),
              e(Text, { style: styles.errorLine }, error),
              formatRetry
                ? e(View, { style: styles.row },
                    e(ActionButton, {
                      title: '按 Skill 纠偏重试',
                      primary: true,
                      onPress: retryFormat,
                      loading: busy && working === 'AI 正在按 Skill 纠偏',
                      style: styles.flex1,
                    })
                  )
                : null
            )
          : null,
        renderResult()
      );
    };

    var renderHistory = function () {
      return e(View, null,
        e(Section, { title: '生成历史（最近 ' + HISTORY_LIMIT + ' 次）' },
          e(Text, { style: styles.hint }, '历史保存在本机插件私有存储里，可随时载入回看或删除。'),
          history.length === 0
            ? e(Text, { style: styles.emptyText }, '还没有生成记录')
            : history.map(function (item) {
                var mf = item.manifest || {};
                return e(View, { key: item.createdAt, style: styles.historyItem },
                  e(View, { style: styles.rowBetween },
                    e(Text, { style: styles.historyName }, (mf.name || mf.id || '未命名') + ' v' + (mf.version || '-')),
                    e(Text, { style: item.ok ? styles.badgeOk : styles.badgeBad }, item.ok ? '通过' : '未通过')
                  ),
                  e(Text, { style: styles.historyPrompt }, item.prompt),
                  e(Text, { style: styles.historyTime }, nowText(item.createdAt) + ' · ' + ((item.files && item.files['index.js'] && item.files['index.js'].length) || 0) + ' 字符'),
                  e(View, { style: styles.row },
                    e(ActionButton, { title: '载入', primary: true, onPress: function () { loadHistory(item); }, style: styles.flex1 }),
                    e(View, { style: styles.gap }),
                    e(ActionButton, { title: '删除', danger: true, onPress: function () { removeHistory(item.createdAt); }, style: styles.flex1 })
                  )
                );
              })
        )
      );
    };

    var renderSkill = function () {
      return e(View, null,
        e(Section, { title: '生成 Skill（系统提示）' },
          e(Text, { style: styles.hint }, '生成时自动作为 system 提示发送。这里固化插件规范：manifest 字段、id 与 SemVer、entry、权限白名单、组件与 api 能力、语法限制、体积上限和输出格式。'),
          e(TextInput, {
            style: [styles.input, styles.skillInput],
            value: skill,
            onChangeText: setSkill,
            multiline: true,
            textAlignVertical: 'top',
            autoCapitalize: 'none',
            autoCorrect: false,
          }),
          e(View, { style: styles.row },
            e(ActionButton, { title: '保存 Skill', primary: true, onPress: saveSkill, style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '恢复默认', onPress: restoreSkill, style: styles.flex1 })
          ),
          e(Text, { style: styles.note }, '当前 ' + skill.length + ' 字符。Skill 会随生成请求发给你配置的 AI 服务商，不要在 Skill 里写 API Key。')
        )
      );
    };

    return e(View, { style: styles.root },
      e(View, { style: styles.tabBar },
        [
          { key: 'generate', label: '生成' },
          { key: 'config', label: '配置' },
          { key: 'skill', label: '技能' },
          { key: 'history', label: '历史' },
        ].map(function (item) {
          return e(TouchableOpacity, {
            key: item.key,
            style: [styles.tab, tab === item.key ? styles.tabActive : null],
            onPress: function () { setTab(item.key); },
          }, e(Text, { style: tab === item.key ? styles.tabTextActive : styles.tabText }, item.label));
        })
      ),
      e(ScrollView, {
        style: styles.body,
        contentContainerStyle: styles.bodyContent,
        keyboardShouldPersistTaps: 'handled',
      },
        tab === 'generate' ? renderGenerate() : null,
        tab === 'config' ? renderConfig() : null,
        tab === 'skill' ? renderSkill() : null,
        tab === 'history' ? renderHistory() : null
      )
    );
  };
};

var styles = RN.StyleSheet.create({
  root: { flex: 1, backgroundColor: '#f4f6f9' },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderBottomWidth: RN.StyleSheet.hairlineWidth,
    borderBottomColor: '#e2e6eb',
  },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center' },
  tabActive: { borderBottomWidth: 2, borderBottomColor: '#4a90d9' },
  tabText: { fontSize: 14, color: '#777' },
  tabTextActive: { fontSize: 14, color: '#2f6fb3', fontWeight: '600' },
  body: { flex: 1 },
  bodyContent: { padding: 12, paddingBottom: 32 },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 14,
    marginBottom: 12,
  },
  cardTitle: { fontSize: 16, fontWeight: '600', color: '#222', marginBottom: 10 },
  label: { fontSize: 13, color: '#555', marginTop: 10, marginBottom: 6 },
  hint: { fontSize: 12, color: '#888', lineHeight: 19, marginBottom: 6 },
  urlHint: { fontSize: 12, color: '#2f6fb3', lineHeight: 18, marginTop: 6, marginBottom: 4 },
  note: { fontSize: 11, color: '#999', lineHeight: 17, marginTop: 10 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 4 },
  chip: {
    borderWidth: 1,
    borderColor: '#d9e2ec',
    backgroundColor: '#f7fafd',
    borderRadius: 14,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginRight: 8,
    marginBottom: 8,
  },
  chipActive: { backgroundColor: '#4a90d9', borderColor: '#4a90d9' },
  chipText: { fontSize: 12, color: '#3b6fa8' },
  chipTextActive: { fontSize: 12, color: '#fff' },
  modelsInfo: {
    fontSize: 12,
    color: '#2f6fb3',
    backgroundColor: '#eef5fd',
    borderRadius: 6,
    padding: 8,
    lineHeight: 18,
    marginTop: 8,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 12,
    paddingVertical: 10,
    borderTopWidth: RN.StyleSheet.hairlineWidth,
    borderTopColor: '#eceff3',
  },
  toggleLabel: { fontSize: 13, color: '#333' },
  toggleOn: { fontSize: 12, color: '#237804' },
  toggleOff: { fontSize: 12, color: '#888' },
  testInfo: { fontSize: 12, color: '#333', lineHeight: 20 },
  skillInput: { minHeight: 360, fontSize: 12, lineHeight: 18 },
  input: {
    borderWidth: 1,
    borderColor: '#dfe3e8',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 14,
    color: '#222',
    backgroundColor: '#fbfcfd',
  },
  promptInput: { minHeight: 96, textAlignVertical: 'top' },
  keyText: {
    fontSize: 14,
    color: '#333',
    backgroundColor: '#f7f9fb',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 10,
    marginBottom: 8,
  },
  row: { flexDirection: 'row', alignItems: 'center', marginTop: 10, flexWrap: 'wrap' },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  gap: { width: 10 },
  flex1: { flex: 1, minWidth: 120 },
  btn: {
    minHeight: 42,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#d9dee5',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
    marginTop: 8,
  },
  btnPrimary: { backgroundColor: '#4a90d9', borderColor: '#4a90d9' },
  btnDanger: { backgroundColor: '#e05b59', borderColor: '#e05b59' },
  btnDisabled: { opacity: 0.55 },
  btnText: { fontSize: 14, color: '#3b6fa8', fontWeight: '600' },
  btnTextLight: { color: '#fff' },
  statusText: {
    fontSize: 13,
    color: '#2f6fb3',
    backgroundColor: '#eef5fd',
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
    lineHeight: 19,
  },
  errorBox: {
    backgroundColor: '#fff1f0',
    borderWidth: 1,
    borderColor: '#ffccc7',
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
  },
  errorTitle: { fontSize: 13, fontWeight: '600', color: '#cf1322', marginBottom: 4 },
  errorLine: { fontSize: 12, color: '#a8071a', lineHeight: 18 },
  warnText: { fontSize: 12, color: '#ad6800', lineHeight: 18, marginTop: 8 },
  resultName: { fontSize: 15, fontWeight: '600', color: '#222', flexShrink: 1 },
  badgeOk: {
    fontSize: 11,
    color: '#237804',
    backgroundColor: '#f6ffed',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginLeft: 8,
    overflow: 'hidden',
  },
  badgeBad: {
    fontSize: 11,
    color: '#cf1322',
    backgroundColor: '#fff1f0',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginLeft: 8,
    overflow: 'hidden',
  },
  permRow: { marginTop: 8, borderLeftWidth: 3, borderLeftColor: '#b7d6f5', paddingLeft: 8 },
  permLabel: { fontSize: 13, color: '#333', fontWeight: '600' },
  permDesc: { fontSize: 11, color: '#888', lineHeight: 17, marginTop: 2 },
  confirmBox: {
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#ffe58f',
    backgroundColor: '#fffbe6',
    borderRadius: 8,
    padding: 12,
  },
  confirmTitle: { fontSize: 14, fontWeight: '600', color: '#874d00', marginBottom: 8 },
  confirmPerm: { fontSize: 12, color: '#874d00', lineHeight: 18 },
  fileTabs: { flexDirection: 'row', marginTop: 12 },
  fileTab: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 6,
    backgroundColor: '#f0f2f5',
    marginRight: 8,
  },
  fileTabActive: { backgroundColor: '#4a90d9' },
  fileTabText: { fontSize: 12, color: '#555' },
  fileTabTextActive: { fontSize: 12, color: '#fff' },
  codeBox: {
    marginTop: 10,
    maxHeight: 260,
    backgroundColor: '#1f2430',
    borderRadius: 8,
  },
  code: {
    padding: 12,
    color: '#d7e3f4',
    fontSize: 11,
    lineHeight: 16,
    fontFamily: 'monospace',
  },
  loadingBox: { flexDirection: 'row', alignItems: 'center', padding: 12 },
  loadingText: { fontSize: 13, color: '#666', marginLeft: 8 },
  progressBox: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
  },
  progressHead: { flexDirection: 'row', alignItems: 'center' },
  progressLabel: { flex: 1, fontSize: 12, color: '#3b6fa8', lineHeight: 18, marginLeft: 8 },
  progressPreview: {
    maxHeight: 120,
    backgroundColor: '#1f2430',
    borderRadius: 6,
    marginTop: 8,
  },
  progressText: { padding: 8, fontSize: 10, color: '#d7e3f4', lineHeight: 14, fontFamily: 'monospace' },
  emptyText: { fontSize: 13, color: '#999', paddingVertical: 20, textAlign: 'center' },
  historyItem: {
    borderWidth: 1,
    borderColor: '#eceff3',
    borderRadius: 8,
    padding: 10,
    marginTop: 10,
  },
  historyName: { fontSize: 14, fontWeight: '600', color: '#222', flex: 1 },
  historyPrompt: { fontSize: 12, color: '#666', lineHeight: 18, marginTop: 6 },
  historyTime: { fontSize: 11, color: '#aaa', marginTop: 4 },
});

// AI 造插件
// 配置 OpenAI 兼容接口 → 描述需求 → AI 生成 manifest.json + index.js → 宿主校验 →
// 预览 / 导出 zip / 确认权限后走安装管线安装并直接打开。
// 注意：插件沙箱不支持异步/等待类语法与 JSX，本文件全部使用 Promise 链与 React.createElement。
module.exports = function ({ React, RN, api }) {
  var e = React.createElement;
  var View = RN.View;
  var Text = RN.Text;
  var TextInput = RN.TextInput;
  var ScrollView = RN.ScrollView;
  var TouchableOpacity = RN.TouchableOpacity;
  var ActivityIndicator = RN.ActivityIndicator;
  var Image = RN.Image;
  var StyleSheet = RN.StyleSheet;

  var HISTORY_LIMIT = 10;
  var DEFAULT_BASE = 'https://api.deepseek.com';
  var DEFAULT_MODEL = 'deepseek-chat';
  var DEFAULT_TIMEOUT_SEC = 120;
  var DEFAULT_MAX_TOKENS = 8192;
  var MIN_TIMEOUT_SEC = 20;
  var MAX_TIMEOUT_SEC = 600;
  var KEYS = {
    baseUrl: 'ai.baseUrl',
    apiKey: 'ai.apiKey',
    model: 'ai.model',
    timeout: 'ai.timeoutSec',
    maxTokens: 'ai.maxTokens',
    stream: 'ai.stream',
    skill: 'ai.skill',
    uiSpec: 'ai.uiSpec',
    history: 'ai.history',
    customSkills: 'ai.customSkills',
    session: 'ai.session',
    sessions: 'ai.sessions',
    installed: 'ai.installedPlugins',
  };

  var PERMISSION_KEYS = [
    'storage', 'network', 'clipboard', 'vibrate', 'device', 'camera',
    'location', 'sensors', 'notification', 'files', 'biometric', 'quickCapture',
  ];

  var BLOCK_TYPES = ['title', 'text', 'input', 'button', 'list', 'image', 'card', 'row'];

  // 内置界面设计规范：方案阶段与生成阶段共用同一份，默认追加到 system 提示，
  // 也可在「技能」页单独查看、编辑、恢复默认。
  var UI_SPEC = [
    '【界面设计规范】以下规范对方案与代码同时生效，属于硬性要求，用户自定义技能不得破坏。',
    '',
    '一、视觉规范',
    '1. 配色：先定义 designTokens，再统一引用；禁止在组件里散落硬编码颜色。',
    '   浅色：bg #F5F7FA、surface #FFFFFF、text #111827、muted #6B7280、border #E5E7EB。',
    '   深色：bg #0F172A、surface #1E293B、text #F1F5F9、muted #94A3B8、border #334155。',
    '   primary 建议 #2563EB（深色 #60A5FA），onPrimary 用 #FFFFFF 或 #0F172A，保证文字与背景对比度不低于 4.5:1。',
    '   success #16A34A、warning #D97706、danger #DC2626；语义色必须同时配文字或符号，不能只靠颜色区分。',
    '2. 字号与行高：页面标题 20/28、区块标题 16/24、正文 14/22、辅助 12/18、极小标注 11/16；同一页面最多 3 种字号，数字重点可用 28-32；行高约为字号 1.5 倍。',
    '3. 间距刻度：只用 4 的倍数，推荐 4/8/12/16/20/24/32；页面左右内边距 16，卡片内边距 12-16，区块间距 16-24。',
    '4. 圆角与阴影：卡片 12-16、按钮 10-12、输入框 10、标签用胶囊圆角；阴影只加一层，颜色 rgba(15,23,42,0.08)、半径 8-12、向下偏移 2-4；深色模式用边框代替阴影。',
    '5. 组件形态与状态：',
    '   按钮：高度不小于 44；主按钮填充 primary + onPrimary，次按钮 surface + border，危险操作用 danger；按下态透明度 0.85 或颜色加深；禁用态透明度 0.4 且不可点；加载态显示 ActivityIndicator，保持原宽度并把文案改为“处理中…”。',
    '   输入框：高度不小于 44，surface 底 + border 边；聚焦时边框变 primary，占位文字用 muted；错误时边框变 danger 并在下方给 12 号错误说明。',
    '   卡片：surface 底 + 12-16 圆角 + 内边距 12-16；标题 16/24 加粗、正文 14/22、辅助行 12/18 muted；卡片之间间距 12。',
    '',
    '二、布局规范',
    '1. 安全区：根容器 flex:1；顶部预留状态栏空间（内边距 24-32），底部预留 16-24；页面主体放 ScrollView，避免被状态栏或手势区遮挡。',
    '2. 页面留白与分组：按“标题区 → 主内容 → 操作区”三段式；同组元素间距 8-12，不同组间距 20-24；每屏只保留一个主操作按钮。',
    '3. 列表与卡片层级：列表项高度不小于 56，左侧主标题 14-16 号、右侧辅助信息 12 号 muted；用分隔线或 8 号间距区分；重要信息在上、次要信息在下，禁止把原始字段直接堆成表格。',
    '4. 空状态与加载态：数据为空时显示大号符号或图标 + 一句说明 + 一个引导按钮；加载时用 ActivityIndicator + “加载中…”，不要白屏；下拉刷新用 RefreshControl。',
    '5. 键盘处理：输入区放在 ScrollView 内，键盘弹出后内容可滚动；提交按钮跟随内容排布，不要硬贴在键盘上；输入框设置 returnKeyType 与 onSubmitEditing。',
    '',
    '三、交互规范',
    '1. 点击反馈：所有可点元素用 TouchableOpacity，activeOpacity 0.7-0.85；列表项整行可点；危险操作要二次确认。',
    '2. 动效：时长 150-250ms，曲线 ease-out；只做透明度、位移、缩放；加载统一用系统 ActivityIndicator。',
    '3. 提示：成功用 success 色 + 2 秒内可读的短文案；失败用 danger 色说明“发生了什么 + 可以怎么办”，禁止只提示“失败”或静默；网络错误必须给重试入口。',
    '',
    '四、硬性约束',
    '1. 只用宿主支持的组件：View、Text、Button、TextInput、ScrollView、StyleSheet、Image、TouchableOpacity、FlatList、ActivityIndicator、RefreshControl。',
    '2. 不引入任何第三方 UI 库或图标库；不写 JSX；全部用 React.createElement；不使用 async/await 与生成器语法；不动态 require。',
    '3. 不引用无法下载的字体或图片资源；图标用内置 Unicode 符号（如 ＋ ✓ ✕ ⟳ ⚙ ★ →）、View 矢量组合或纯文字实现。',
    '4. 颜色、圆角、间距必须来自 designTokens 或统一常量，不得在多个位置重复硬编码。',
    '',
    '五、反面清单（出现任一项即视为不合格）',
    '1. 系统默认 Button、TextInput 原样堆在页面上，不做任何样式。',
    '2. 纯灰底 + 表格或键值对罗列数据，没有卡片、层级和主次。',
    '3. 裸 Text 无字号、行高、颜色，正文与标题同样大小。',
    '4. 间距随手写 3/7/13/17 等非刻度值，元素贴边或挤在一起。',
    '5. 颜色硬编码散落各处，同一语义出现多种颜色；深色模式下文字看不清。',
    '6. 按钮没有按下、禁用、加载态；点击无任何反馈。',
    '7. 空列表白屏或只显示“暂无数据”，没有引导操作。',
    '8. 引入外部 UI 库、字体、远程图片或 JSX。',
  ].join('\n');

  var LIGHT_TOKENS = {
    mode: 'light',
    primary: '#2563EB',
    onPrimary: '#FFFFFF',
    bg: '#F5F7FA',
    surface: '#FFFFFF',
    text: '#111827',
    muted: '#6B7280',
    border: '#E5E7EB',
    success: '#16A34A',
    warning: '#D97706',
    danger: '#DC2626',
    radius: 14,
    spacing: 8,
  };

  var DARK_TOKENS = Object.assign({}, LIGHT_TOKENS, {
    mode: 'dark',
    primary: '#60A5FA',
    onPrimary: '#0F172A',
    bg: '#0F172A',
    surface: '#1E293B',
    text: '#F1F5F9',
    muted: '#94A3B8',
    border: '#334155',
  });

  // 方案阶段专用提示：只产出结构化方案，不产出代码。
  var PLAN_SKILL = [
    '你是插件方案设计师，负责把用户需求整理成可评审的结构化方案。此阶段不要输出任何代码。',
    '',
    '【输出格式】',
    '只输出一个 JSON 对象，不要 markdown 代码块，不要解释文字：',
    '{"plan":{"manifest":{"id":"com.example.demo","name":"示例","version":"1.0.0","description":"一句话说明","permissions":["storage"]},',
    '"permissionReasons":{"storage":"保存用户数据"},',
    '"designTokens":{"mode":"light","primary":"#2563EB","onPrimary":"#FFFFFF","bg":"#F5F7FA","surface":"#FFFFFF","text":"#111827","muted":"#6B7280","border":"#E5E7EB","success":"#16A34A","warning":"#D97706","danger":"#DC2626","radius":14,"spacing":8},',
    '"screens":[{"title":"主界面","blocks":[{"type":"title","text":"标题"},{"type":"input","text":"输入框占位"},{"type":"button","text":"开始"},{"type":"card","text":"卡片标题","desc":"辅助说明"},{"type":"list","text":"列表项"}]}],',
    '"interactions":["点击开始后..."],"storage":["数据保存在 api.storage..."],"steps":["1. 创建 manifest","2. 实现界面"]}}',
    '',
    '【manifest 草案】',
    'id 小写反向域名、至少两段；name 1-30 字；version 用 SemVer，默认 1.0.0；permissions 只选确实需要的白名单项。',
    '',
    '【权限白名单】',
    'storage、network、clipboard、vibrate、device、camera、location、sensors、notification、files、biometric、quickCapture。',
    'permissionReasons 必须为每个权限写一句中文理由，理由要具体到功能，不要写“需要权限”。',
    '',
    '【界面草图 screens】',
    '至少 1 个屏幕，最多 3 个；每个屏幕 3-8 个块。block.type 只能是：title、text、input、button、list、image、card、row。',
    'block.text 是该块显示的中文文字或占位提示（12 字以内）；card 和 list 可额外带 block.desc 作为辅助说明。',
    '草图要能一眼看懂界面长什么样：按【界面设计规范】安排层级，主操作只有一个 button，数据用 card/list 而非表格堆叠。',
    '',
    '【designTokens】',
    '必须按【界面设计规范】给出配色与刻度，供线框图预览和后续代码共同使用：mode 只能是 light 或 dark；',
    '颜色用 6 位十六进制 #RRGGBB，文字与背景对比度不低于 4.5:1；radius 取 8-20，spacing 取 4-12。',
    '浅色/深色任选其一，但整份方案只能有一个 mode；没有把握时用浅色默认值。',
    '',
    '【其他字段】',
    'interactions：3-6 条主要交互；storage：1-3 条数据存储说明；steps：按插件规范的标准开发流程给出 4-8 步。',
    'steps 的最后一步必须包含“按界面设计规范自检：配色/字号/间距/圆角、空状态与加载态、按下与禁用态”。',
  ].join('\n');

  // 常用 OpenAI 兼容服务商预设。模型名只是默认值，可点「拉取模型」用 /models 校正。
  var PRESETS = [
    {
      key: 'deepseek',
      label: 'DeepSeek',
      baseUrl: 'https://api.deepseek.com',
      model: 'deepseek-chat',
    },
    {
      key: 'openai',
      label: 'OpenAI',
      baseUrl: 'https://api.openai.com/v1',
      model: 'gpt-4o-mini',
    },
    {
      key: 'dashscope',
      label: '通义千问',
      baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
      model: 'qwen-plus',
    },
    {
      key: 'moonshot',
      label: '月之暗面',
      baseUrl: 'https://api.moonshot.cn/v1',
      model: 'moonshot-v1-8k',
    },
  ];

  var EXAMPLES = [
    { label: '天气查看', text: '帮我生成一个天气查看插件：显示当前城市、天气状况和温度，可以手动刷新，界面简洁，中文显示。' },
    { label: '番茄钟', text: '帮我生成一个番茄钟插件：25 分钟专注、5 分钟休息，开始后显示倒计时，结束时震动提醒，并记录完成的番茄数。' },
    { label: '待办清单', text: '帮我生成一个待办清单插件：可以添加、勾选完成和删除待办，数据保存在本机，重启后仍在。' },
  ];

  var DEFAULT_SKILL = [
    '你是「插件管理器」Android 应用的插件生成器，必须严格遵守下面的插件规范。',
    '',
    '【输出格式】',
    '只输出一个 JSON 对象，不要 markdown 代码块，不要解释文字。结构必须是：',
    '{"manifest":{...},"indexJs":"完整 JS 源码字符串","iconBase64":null}',
    'indexJs 必须是可直接运行的完整源码字符串，换行用 JSON 转义。',
    '',
    '【manifest 必填字段】',
    'id：小写反向域名，至少两段，字母开头，仅含小写字母、数字、点和中划线，例如 com.example.weather；不要包含中文、空格或大写字母。',
    'name：1-30 个字符的中文或英文名称。',
    'version：SemVer，格式 MAJOR.MINOR.PATCH，例如 1.0.0。',
    'entry：固定为 index.js，放在插件根目录。',
    'permissions：数组，可为空；只能使用白名单里的值，并确实用到对应 api。',
    '可选字段：description（一句话说明）、author、icon（仅在 iconBase64 有值时填写，指向 assets/icon.png）。',
    '',
    '【权限白名单与用途】',
    'storage：api.storage.get/set/remove，插件私有键值存储。',
    'network：api.fetch / api.fetchStream，访问网络，必须处理失败并提示。',
    'clipboard：api.clipboard 读写剪贴板。',
    'vibrate：api.vibrate 触发震动。',
    'device：api.device 读取设备信息。',
    'camera：api.camera 拍照。',
    'location：api.location 获取定位。',
    'sensors：api.sensors 读取传感器。',
    'notification：api.notification 发送通知。',
    'files：api.files 读写应用私有文件。',
    'biometric：api.biometric 生物识别。',
    'quickCapture：api.quickCapture 通知栏快捷拍照。',
    'pluginBuild、exportFile 只给生成插件的元插件使用，普通插件不要声明。',
    '',
    '【代码约束】',
    '入口写法固定：module.exports = function ({ React, RN, api }) { return function App() { ... }; };',
    '界面只能用 React.createElement 构建，不要写 JSX。',
    '只能用 Promise 的 .then/.catch 链式写法；不要使用 async 关键字、等待语法或生成器语法。',
    '不要使用 require，不能依赖任何第三方包。',
    '可用组件仅限：View, Text, Button, TextInput, ScrollView, StyleSheet, Image, TouchableOpacity, FlatList, ActivityIndicator, RefreshControl。',
    '可用能力仅限 api.storage、api.fetch、api.fetchStream、api.clipboard、api.vibrate、api.device、api.camera、api.location、api.sensors、api.notification、api.files、api.biometric、api.quickCapture。',
    '不要访问 window、document、localStorage 等浏览器对象。',
    '',
    '【界面要求】',
    '必须完整执行系统提示中的【界面设计规范】：先在代码顶部定义 designTokens，再统一引用配色、圆角、间距。',
    '按规范的视觉、布局、交互要求实现；空状态、加载态、错误提示、按钮按下/禁用/加载态都要真实可见。',
    '禁止：默认系统控件直出、纯灰底堆表格、裸 Text 无排版、间距随意、颜色硬编码散落各处。',
    '图标只能用内置 Unicode 符号、View 组合或纯文字，不能引用外部字体或图片。',
    '',
    '【标准开发流程】',
    '1. 需求梳理：明确功能点、界面数量、需要保存的数据和是否需要联网。',
    '2. 方案设计：先确定页面结构与主要交互，再决定数据字段与存储键名。',
    '3. 最小权限：只为真正用到的 api 声明权限，不声明用不到的能力。',
    '4. 编写入口：先写 module.exports 与组件骨架，再逐个实现界面块与事件。',
    '5. 数据与异常：所有 api 调用都要有失败提示，界面不要静默失败。',
    '6. 界面实现：先写 designTokens 与 StyleSheet，再搭标题区/内容区/操作区，最后补空状态与加载态。',
    '7. 自检：检查 id/SemVer/entry、语法约束（无 async、无生成器、无 JSX）、体积上限。',
    '8. 界面自检：对照【界面设计规范】检查配色对比度、字号行高、4 的倍数间距、圆角层级与按钮状态。',
    '',
    '【体积与稳健性】',
    'index.js 不得超过 2MB，建议控制在 50KB 以内；图标不超过 512KB。',
    '代码要简洁可运行，中文界面，捕获错误并在界面上提示，不要静默失败。',
    '没有图标数据时不要在 manifest 里写 icon，iconBase64 固定返回 null。',
  ].join('\n');


  function nowText(ts) {
    var d = new Date(ts);
    var pad = function (n) { return n < 10 ? '0' + n : '' + n; };
    return pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  function maskKey(key) {
    var value = String(key || '');
    if (!value) return '';
    if (value.length <= 10) return '••••••';
    return value.slice(0, 4) + '••••' + value.slice(-4);
  }

  // 去掉 AI 偶尔带出的 ``` 包裹，截取第一个 { 到最后一个 }
  function extractJson(text) {
    var s = String(text || '').trim();
    var start = s.indexOf('{');
    var end = s.lastIndexOf('}');
    if (start >= 0 && end > start) s = s.slice(start, end + 1);
    return s;
  }

  function parsePayload(text) {
    var json;
    try {
      json = JSON.parse(extractJson(text));
    } catch (err) {
      throw new Error('AI 返回的不是合法 JSON：' + String(text || '').slice(0, 200));
    }
    if (!json || !json.manifest || typeof json.manifest !== 'object') {
      throw new Error('AI 返回缺少 manifest 对象');
    }
    if (typeof json.indexJs !== 'string' || !json.indexJs.trim()) {
      throw new Error('AI 返回缺少 indexJs 代码');
    }
    return json;
  }

  function buildFiles(payload) {
    var files = {};
    files['manifest.json'] = JSON.stringify(payload.manifest, null, 2);
    files['index.js'] = payload.indexJs;
    if (payload.iconBase64 && payload.manifest.icon) {
      files[payload.manifest.icon] = { base64: String(payload.iconBase64) };
    }
    return files;
  }

  function normalizeBase(url) {
    return String(url || '').trim().replace(/\/+$/, '');
  }

  function chatUrlOf(base) {
    var b = normalizeBase(base);
    if (/\/chat\/completions$/i.test(b)) return b;
    return b + '/chat/completions';
  }

  function modelsUrlOf(base) {
    var b = normalizeBase(base).replace(/\/chat\/completions$/i, '');
    return b + '/models';
  }

  function baseUrlHint(base) {
    var b = normalizeBase(base);
    if (!b) return '请填写 API 地址';
    if (/\/chat\/completions$/i.test(b)) {
      return '地址里包含了 /chat/completions。一般只需填服务根地址或 /v1，实际请求：' + b;
    }
    if (/\/v1$/i.test(b)) {
      return '实际请求：' + b + '/chat/completions';
    }
    return '实际请求：' + b + '/chat/completions\n（多数服务地址需以 /v1 结尾；DeepSeek 可只填 https://api.deepseek.com）';
  }

  function fmtDuration(ms) {
    var value = Number(ms) || 0;
    if (value < 1000) return Math.round(value) + ' ms';
    return (value / 1000).toFixed(1) + ' 秒';
  }

  function truncate(text, max) {
    var s = String(text || '');
    if (s.length <= max) return s;
    return s.slice(0, max) + '…（共 ' + s.length + ' 字符）';
  }

  function semverOf(value) {
    var m = /^\d+\.\d+\.\d+$/.exec(String(value || '').trim());
    return m ? m[0] : '1.0.0';
  }

  function bumpPatch(value) {
    var parts = semverOf(value).split('.');
    return parts[0] + '.' + parts[1] + '.' + (Number(parts[2]) + 1);
  }

  // 所有页面统一用这个函数展示版本，缺省/非法一律回到 1.0.0，避免出现 unknown。
  function versionOf(manifest) {
    return semverOf(manifest && manifest.version);
  }

  function hexOf(value, fallback) {
    var s = String(value || '').trim();
    if (/^#[0-9a-fA-F]{6}$/.test(s)) return s.toUpperCase();
    if (/^#[0-9a-fA-F]{3}$/.test(s)) {
      return ('#' + s[1] + s[1] + s[2] + s[2] + s[3] + s[3]).toUpperCase();
    }
    return fallback;
  }

  // 只接受合法的 Hex 与刻度值；缺失时按明暗模式回落到默认令牌，保证旧方案也能渲染。
  function normalizeTokens(src) {
    var raw = src && typeof src === 'object' ? src : {};
    var base = String(raw.mode || '').toLowerCase() === 'dark' ? DARK_TOKENS : LIGHT_TOKENS;
    var radius = Number(raw.radius);
    var spacing = Number(raw.spacing);
    return {
      mode: base.mode,
      primary: hexOf(raw.primary, base.primary),
      onPrimary: hexOf(raw.onPrimary, base.onPrimary),
      bg: hexOf(raw.bg, base.bg),
      surface: hexOf(raw.surface, base.surface),
      text: hexOf(raw.text, base.text),
      muted: hexOf(raw.muted, base.muted),
      border: hexOf(raw.border, base.border),
      success: hexOf(raw.success, base.success),
      warning: hexOf(raw.warning, base.warning),
      danger: hexOf(raw.danger, base.danger),
      radius: radius >= 8 && radius <= 20 ? Math.round(radius) : base.radius,
      spacing: spacing >= 4 && spacing <= 12 ? Math.round(spacing) : base.spacing,
    };
  }

  function parseVersion(value) {
    return semverOf(value).split('.').map(function (item) { return Number(item); });
  }

  function versionGt(a, b) {
    var left = parseVersion(a);
    var right = parseVersion(b);
    for (var i = 0; i < 3; i += 1) {
      if (left[i] > right[i]) return true;
      if (left[i] < right[i]) return false;
    }
    return false;
  }

  function sessionNameOf(plan, prompt) {
    var name = plan && plan.manifest && plan.manifest.name;
    if (name) return String(name).slice(0, 24);
    var text = String(prompt || '').trim();
    return text ? text.slice(0, 20) : '未命名会话';
  }

  // 兼容旧数据：补齐 id/name/时间，并把每轮 manifest.version 统一成合法 SemVer。
  function normalizeSessionItem(item) {
    if (!item || !Array.isArray(item.rounds) || !item.rounds.length) return null;
    var rounds = item.rounds.map(function (round, index) {
      var manifest = round && round.manifest ? Object.assign({}, round.manifest) : null;
      if (manifest) manifest.version = versionOf(manifest);
      return Object.assign({}, round, {
        round: round.round || (index + 1),
        manifest: manifest,
      });
    });
    var createdAt = item.createdAt || (rounds[0] && rounds[0].createdAt) || Date.now();
    var updatedAt = item.updatedAt || (rounds[rounds.length - 1] && rounds[rounds.length - 1].createdAt) || createdAt;
    return Object.assign({}, item, {
      id: item.id || ('s' + createdAt),
      name: item.name || sessionNameOf(item.plan, item.prompt),
      createdAt: createdAt,
      updatedAt: updatedAt,
      rounds: rounds,
      activeIndex: Math.min(item.activeIndex || (rounds.length - 1), rounds.length - 1),
    });
  }

  function toArray(value) {
    return Array.isArray(value) ? value : [];
  }

  function toStrings(value) {
    return toArray(value).map(function (item) {
      if (typeof item === 'string') return item.trim();
      if (item && typeof item === 'object') return String(item.text || item.title || item.name || '').trim();
      return '';
    }).filter(function (item) { return !!item; });
  }

  var TYPE_LABEL = {
    title: '标题', text: '文字', input: '输入框', button: '按钮',
    list: '列表', image: '图片', card: '卡片', row: '行',
  };
  var LABEL_TYPE = {
    '标题': 'title', '文字': 'text', '输入框': 'input', '按钮': 'button',
    '列表': 'list', '图片': 'image', '卡片': 'card', '行': 'row',
  };

  function normalizeScreen(raw, index) {
    var src = raw && typeof raw === 'object' ? raw : {};
    var blocks = toArray(src.blocks).map(function (block) {
      if (typeof block === 'string') return { type: 'text', text: block.trim() };
      var item = block && typeof block === 'object' ? block : {};
      var type = LABEL_TYPE[item.type] || String(item.type || 'text').toLowerCase();
      if (BLOCK_TYPES.indexOf(type) < 0) type = 'text';
      return {
        type: type,
        text: String(item.text || item.title || '').trim(),
        desc: String(item.desc || item.subtitle || item.hint || '').trim(),
      };
    }).filter(function (block) { return !!block.text; }).slice(0, 10);
    if (!blocks.length) {
      blocks = [
        { type: 'title', text: String(src.title || '主界面').trim() || '主界面' },
        { type: 'text', text: '（方案未提供界面草图）' },
      ];
    }
    return {
      title: String(src.title || ('界面 ' + (index + 1))).trim() || ('界面 ' + (index + 1)),
      blocks: blocks,
    };
  }

  function normalizePlan(json, userPrompt) {
    var src = json && json.plan && typeof json.plan === 'object' ? json.plan : (json || {});
    var manifestSrc = src.manifest && typeof src.manifest === 'object' ? src.manifest : {};
    var permissions = toArray(manifestSrc.permissions).filter(function (key) {
      return PERMISSION_KEYS.indexOf(key) >= 0;
    });
    var reasonsSrc = src.permissionReasons && typeof src.permissionReasons === 'object' ? src.permissionReasons : {};
    var reasons = {};
    permissions.forEach(function (key) {
      var text = String(reasonsSrc[key] || '').trim();
      reasons[key] = text || '用于实现方案中的相关功能';
    });
    var screens = toArray(src.screens).slice(0, 3).map(normalizeScreen);
    if (!screens.length) screens = [normalizeScreen({ title: '主界面' }, 0)];
    return {
      manifest: {
        id: String(manifestSrc.id || 'com.ai.generated').trim(),
        name: String(manifestSrc.name || 'AI 插件').trim(),
        version: semverOf(manifestSrc.version),
        description: String(manifestSrc.description || userPrompt || '').trim(),
        permissions: permissions,
      },
      permissionReasons: reasons,
      designTokens: normalizeTokens(src.designTokens),
      screens: screens,
      interactions: toStrings(src.interactions),
      storage: toStrings(src.storage),
      steps: toStrings(src.steps),
      prompt: userPrompt || '',
    };
  }

  function parsePlan(text, userPrompt) {
    var json;
    try {
      json = JSON.parse(extractJson(text));
    } catch (e) {
      throw new Error('方案不是合法 JSON：' + String(text || '').slice(0, 200));
    }
    var src = json && json.plan && typeof json.plan === 'object' ? json.plan : json;
    if (!src || typeof src !== 'object' || !src.manifest || typeof src.manifest !== 'object') {
      throw new Error('方案缺少 manifest 草案（需要 {"plan":{"manifest":{...}}} 结构）');
    }
    return normalizePlan(json, userPrompt);
  }

  function screensToLines(screens) {
    var lines = [];
    toArray(screens).forEach(function (screen) {
      lines.push('## ' + screen.title);
      toArray(screen.blocks).forEach(function (block) {
        lines.push((TYPE_LABEL[block.type] || '文字') + '|' + block.text);
      });
    });
    return lines.join('\n');
  }

  function linesToScreens(text) {
    var screens = [];
    var current = null;
    String(text || '').split('\n').forEach(function (raw) {
      var line = raw.trim();
      if (!line) return;
      if (line.indexOf('##') === 0) {
        current = { title: line.replace(/^#+\s*/, '').trim() || ('界面 ' + (screens.length + 1)), blocks: [] };
        screens.push(current);
        return;
      }
      if (!current) {
        current = { title: '主界面', blocks: [] };
        screens.push(current);
      }
      var parts = line.split('|');
      var label = parts.length > 1 ? parts[0].trim() : '';
      var body = parts.length > 1 ? parts.slice(1).join('|').trim() : line;
      var type = LABEL_TYPE[label] || (BLOCK_TYPES.indexOf(label) >= 0 ? label : 'text');
      if (body) current.blocks.push({ type: type, text: body });
    });
    var cleaned = screens.map(function (screen, index) {
      return normalizeScreen(screen, index);
    }).slice(0, 3);
    return cleaned.length ? cleaned : [normalizeScreen({ title: '主界面' }, 0)];
  }

  // 简单逐行 diff：统计增删行数并给出前几条变化，用于修改前后对比。
  function diffStat(prevText, nextText) {
    var a = String(prevText || '').split('\n');
    var b = String(nextText || '').split('\n');
    var result = { added: 0, removed: 0, sample: [] };
    if (!a.length || !b.length || a.length * b.length > 400000) {
      result.added = b.length;
      result.removed = a.length;
      return result;
    }
    var table = [];
    var i;
    var j;
    for (i = 0; i <= a.length; i += 1) table.push(new Array(b.length + 1).fill(0));
    for (i = a.length - 1; i >= 0; i -= 1) {
      for (j = b.length - 1; j >= 0; j -= 1) {
        table[i][j] = a[i] === b[j]
          ? table[i + 1][j + 1] + 1
          : Math.max(table[i + 1][j], table[i][j + 1]);
      }
    }
    i = 0;
    j = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) {
        i += 1;
        j += 1;
      } else if (table[i + 1][j] >= table[i][j + 1]) {
        result.removed += 1;
        if (result.sample.length < 8) result.sample.push('- ' + a[i].trim().slice(0, 80));
        i += 1;
      } else {
        result.added += 1;
        if (result.sample.length < 8) result.sample.push('+ ' + b[j].trim().slice(0, 80));
        j += 1;
      }
    }
    while (i < a.length) {
      result.removed += 1;
      if (result.sample.length < 8) result.sample.push('- ' + a[i].trim().slice(0, 80));
      i += 1;
    }
    while (j < b.length) {
      result.added += 1;
      if (result.sample.length < 8) result.sample.push('+ ' + b[j].trim().slice(0, 80));
      j += 1;
    }
    return result;
  }


  function phaseLabel(phase) {
    if (phase === 'connecting') return '连接或等待响应阶段（尚未收到响应数据）';
    if (phase === 'waiting') return '等待响应阶段（已建立连接，模型尚未返回）';
    if (phase === 'reading') return '接收响应阶段（已开始返回数据）';
    return '请求阶段';
  }

  function makeRequestError(message, meta) {
    var err = new Error(message);
    err.name = 'RequestError';
    Object.keys(meta || {}).forEach(function (key) { err[key] = meta[key]; });
    return err;
  }

  function timeoutMsOf(config) {
    var sec = Number(config.timeoutSec);
    if (!sec || isNaN(sec)) sec = DEFAULT_TIMEOUT_SEC;
    sec = Math.max(MIN_TIMEOUT_SEC, Math.min(MAX_TIMEOUT_SEC, sec));
    return Math.round(sec * 1000);
  }

  function maxTokensOf(config) {
    var value = Number(config.maxTokens);
    if (isNaN(value)) return DEFAULT_MAX_TOKENS;
    value = Math.floor(value);
    if (value <= 0) return 0;
    return Math.min(200000, value);
  }

  // 读取 SSE：按行拆 data:，只把 delta.content 当成最终答案，
  // delta.reasoning_content 单独累计仅用于实时预览，避免把推理过程误当 JSON。
  function createSseReader(onText) {
    var buffer = '';
    var text = '';
    var reasoning = '';
    var finishReason = '';
    var sawSse = false;

    var handleLine = function (line) {
      line = String(line || '').replace(/\r$/, '');
      if (line.indexOf('data:') !== 0) return;
      var data = line.slice(5).trim();
      if (!data) return;
      sawSse = true;
      if (data === '[DONE]') return;
      var json;
      try {
        json = JSON.parse(data);
      } catch (e) {
        return;
      }
      var choice = json && json.choices && json.choices[0];
      if (choice && choice.finish_reason) finishReason = choice.finish_reason;
      var delta = choice && (choice.delta || choice.message);
      if (!delta) return;
      var piece = typeof delta.content === 'string' ? delta.content : '';
      var think = typeof delta.reasoning_content === 'string' ? delta.reasoning_content : '';
      if (think) reasoning += think;
      if (piece) text += piece;
      if ((piece || think) && onText) onText(text || reasoning, text.length > 0);
    };

    return {
      feed: function (chunk) {
        buffer += chunk;
        var index;
        while ((index = buffer.indexOf('\n')) >= 0) {
          handleLine(buffer.slice(0, index));
          buffer = buffer.slice(index + 1);
        }
      },
      flush: function () {
        if (buffer) {
          handleLine(buffer);
          buffer = '';
        }
      },
      getText: function () { return text; },
      getReasoning: function () { return reasoning; },
      getFinishReason: function () { return finishReason; },
      sawSse: function () { return sawSse; },
    };
  }

  function parseChatJson(text, url, meta) {
    var json;
    try {
      json = JSON.parse(text);
    } catch (e) {
      throw makeRequestError('接口返回的不是完整 JSON（可能被截断）', {
        url: url,
        status: meta.status,
        body: text,
        elapsedMs: meta.elapsedMs,
        phase: meta.phase || 'reading',
      });
    }
    var choice = json && json.choices && json.choices[0];
    var content = choice && choice.message && choice.message.content;
    if (typeof content !== 'string' || !content.trim()) {
      throw makeRequestError('接口返回缺少 choices[0].message.content', {
        url: url,
        status: meta.status,
        body: text,
        elapsedMs: meta.elapsedMs,
        phase: meta.phase || 'reading',
      });
    }
    return { content: content, finishReason: choice.finish_reason || '' };
  }

  function finishResult(content, meta, finishReason, streamed) {
    return {
      content: content,
      url: meta.url,
      status: meta.status,
      statusText: meta.statusText || '',
      elapsedMs: meta.elapsedMs || 0,
      bytes: meta.bytes || 0,
      streamed: !!streamed,
      finishReason: finishReason || '',
      truncated: finishReason === 'length',
    };
  }

  function decorateError(err, url, timeoutMs) {
    if (!err) return new Error('请求失败');
    if (!err.url) err.url = url;
    if (!err.phase) err.phase = 'waiting';
    if (!err.phaseLabel) err.phaseLabel = phaseLabel(err.phase);
    if (!err.timeoutMs) err.timeoutMs = timeoutMs;
    return err;
  }

  function describeRequestError(err, config) {
    var lines = [];
    var phase = err.phaseLabel || phaseLabel(err.phase);
    var isTimeout = err.name === 'TimeoutError' || err.kind === 'timeout';

    if (isTimeout) {
      lines.push('请求超时：' + phase);
    } else if (err.status && err.status !== 200) {
      lines.push('接口返回 HTTP ' + err.status + (err.statusText ? ' ' + err.statusText : ''));
    } else if (err.status === 200 && err.message) {
      lines.push(err.message);
    } else {
      lines.push((err.message || '请求失败') + '（' + phase + '）');
    }

    lines.push('阶段：' + phase);
    lines.push('实际请求：' + (err.url || chatUrlOf(config.baseUrl)));
    if (err.elapsedMs || isTimeout) {
      lines.push('耗时：' + fmtDuration(err.elapsedMs) + (err.timeoutMs ? '，超时上限 ' + fmtDuration(err.timeoutMs) : ''));
    }
    if (err.body) {
      lines.push('服务端返回：' + truncate(err.body, 300));
    }

    if (isTimeout) {
      if (err.phase === 'connecting') {
        lines.push('建议：连接或等待响应阶段超时。若地址可达，说明服务端迟迟没开始返回（模型排队或推理耗时），可调大超时；若完全连不上，重点检查 DNS、VPN/代理是否放行、端口是否被拦截。');
      } else if (err.phase === 'waiting') {
        lines.push('建议：已连上服务但模型未返回。可提高超时时间、换更快的模型，或检查服务商是否在排队。');
      } else {
        lines.push('建议：已开始接收但长时间没有新数据，可能是代理断开或服务端卡住；可重试。');
      }
    } else if (err.status === 401 || err.status === 403) {
      lines.push('建议：鉴权失败，检查 API Key 是否正确、是否多了空格，以及账户是否有该模型权限。');
    } else if (err.status === 404) {
      lines.push('建议：地址或路径不对。OpenAI 兼容服务通常需要 /v1；DeepSeek 可只填 https://api.deepseek.com。');
    } else if (err.status === 429) {
      lines.push('建议：触发限流或额度不足，请稍后再试或检查账户余额。');
    } else if (err.status >= 500) {
      lines.push('建议：服务端异常，稍后重试或切换服务商。');
    } else if (err.name === 'NetworkError') {
      lines.push('建议：连接失败，检查 VPN、代理、DNS 与网络是否可用。');
    }
    return lines.join('\n');
  }

  function simpleGet(url, headers, timeoutMs) {
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, timeoutMs);
    var started = Date.now();
    return api.fetch(url, {
      method: 'GET',
      headers: headers,
      signal: controller.signal,
    }).then(function (res) {
      return res.text().then(function (text) {
        clearTimeout(timer);
        if (!res.ok) {
          throw makeRequestError('HTTP ' + res.status, {
            url: url,
            status: res.status,
            body: text,
            elapsedMs: Date.now() - started,
            phase: 'reading',
          });
        }
        return { text: text, status: res.status, elapsedMs: Date.now() - started, url: url };
      });
    }).catch(function (err) {
      clearTimeout(timer);
      if (err && err.name === 'AbortError') {
        throw makeRequestError('等待模型列表超时', {
          url: url,
          phase: 'waiting',
          elapsedMs: Date.now() - started,
          timeoutMs: timeoutMs,
          status: 0,
        });
      }
      throw decorateError(err, url, timeoutMs);
    });
  }

  function fetchModels(config) {
    var url = modelsUrlOf(config.baseUrl);
    var headers = {
      Authorization: 'Bearer ' + config.apiKey,
      Accept: 'application/json',
    };
    var request = typeof api.fetchStream === 'function'
      ? api.fetchStream(url, { method: 'GET', headers: headers, timeoutMs: 15000 }, {}).then(function (res) {
          return { text: res.text, status: res.status, elapsedMs: res.elapsedMs, url: url };
        })
      : simpleGet(url, headers, 15000);
    return request.then(function (res) {
      var json;
      try {
        json = JSON.parse(res.text);
      } catch (e) {
        throw makeRequestError('/models 返回的不是 JSON', {
          url: url,
          status: res.status,
          body: res.text,
          elapsedMs: res.elapsedMs,
        });
      }
      var list = json.data || json.models || [];
      var ids = list.map(function (item) {
        return item && (item.id || item.name);
      }).filter(function (id) { return typeof id === 'string' && id; });
      return { url: url, status: res.status, elapsedMs: res.elapsedMs, ids: ids };
    });
  }

  function requestAIFetch(config, url, bodyText, headers, timeoutMs, handlers, started) {
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, timeoutMs);
    return api.fetch(url, {
      method: 'POST',
      headers: headers,
      body: bodyText,
      signal: controller.signal,
    }).then(function (res) {
      return res.text().then(function (text) {
        clearTimeout(timer);
        if (!res.ok) {
          throw makeRequestError('HTTP ' + res.status, {
            url: url,
            status: res.status,
            body: text,
            elapsedMs: Date.now() - started,
            phase: 'reading',
          });
        }
        var parsed = parseChatJson(text, url, { status: res.status, elapsedMs: Date.now() - started });
        if (handlers.onProgress) {
          handlers.onProgress({ phase: 'reading', elapsedMs: Date.now() - started, status: res.status, preview: parsed.content });
        }
        return finishResult(parsed.content, { url: url, status: res.status, elapsedMs: Date.now() - started }, parsed.finishReason, false);
      });
    }).catch(function (err) {
      clearTimeout(timer);
      if (err && err.name === 'AbortError') {
        throw makeRequestError('请求超时', {
          url: url,
          phase: 'waiting',
          phaseLabel: phaseLabel('waiting'),
          status: 0,
          body: '',
          elapsedMs: Date.now() - started,
          timeoutMs: timeoutMs,
        });
      }
      throw decorateError(err, url, timeoutMs);
    });
  }

  /**
   * 调用 OpenAI 兼容接口。优先走流式（边收边回调），不支持时回退普通请求。
   * 返回 { content, url, status, elapsedMs, bytes, streamed, finishReason, truncated }
   */
  function requestAI(config, messages, handlers) {
    var base = normalizeBase(config.baseUrl);
    if (!base) return Promise.reject(new Error('请先配置 API 地址'));
    if (!config.apiKey) return Promise.reject(new Error('请先配置 API Key'));
    if (!config.model) return Promise.reject(new Error('请先配置模型名'));

    var url = chatUrlOf(base);
    var timeoutMs = timeoutMsOf(config);
    var stream = config.stream !== false;
    var body = {
      model: config.model,
      temperature: 0.2,
      messages: messages,
      stream: stream,
    };
    var maxTokens = maxTokensOf(config);
    if (maxTokens > 0) body.max_tokens = maxTokens;

    var bodyText = JSON.stringify(body);
    var headers = {
      'Content-Type': 'application/json; charset=utf-8',
      Authorization: 'Bearer ' + config.apiKey,
      Accept: stream ? 'text/event-stream, application/json' : 'application/json',
    };
    var events = handlers || {};
    var started = Date.now();

    if (stream && typeof api.fetchStream === 'function') {
      var reader = createSseReader(function (live) {
        if (events.onProgress) {
          events.onProgress({
            phase: 'reading',
            elapsedMs: Date.now() - started,
            preview: live,
            status: 0,
          });
        }
      });
      var raw = '';
      return api.fetchStream(url, {
        method: 'POST',
        headers: headers,
        body: bodyText,
        timeoutMs: timeoutMs,
      }, {
        onPhase: function (info) {
          if (events.onProgress) {
            events.onProgress({
              phase: info.phase,
              phaseLabel: info.phaseLabel,
              status: info.status,
              elapsedMs: info.elapsedMs,
              preview: reader.getText(),
            });
          }
        },
        onChunk: function (chunk, info) {
          raw += chunk;
          reader.feed(chunk);
          if (events.onProgress) {
            events.onProgress({
              phase: 'reading',
              status: info.status,
              elapsedMs: info.elapsedMs,
              bytes: info.bytes,
              preview: reader.getText() || reader.getReasoning(),
              thinking: !reader.getText() && !!reader.getReasoning(),
            });
          }
        },
      }).then(function (res) {
        reader.flush();
        var text = reader.getText();
        if (!text) {
          if (reader.sawSse()) {
            var think = reader.getReasoning();
            var reason = think
              ? '模型只返回了推理内容（reasoning_content），没有最终答案；通常是 max_tokens 被推理过程耗尽（finish_reason=' +
                (reader.getFinishReason() || '未知') + '），请把「最大输出 tokens」调大到 16384 或 32768 后重试。'
              : 'SSE 响应里没有可用的 delta.content';
            throw makeRequestError(reason, {
              url: url,
              status: res.status,
              body: think ? think.slice(-600) : raw || res.text,
              elapsedMs: res.elapsedMs,
              phase: res.phase,
              finishReason: reader.getFinishReason(),
            });
          }
          var parsed = parseChatJson(raw || res.text, url, res);
          return finishResult(
            parsed.content,
            { url: url, status: res.status, statusText: res.statusText, elapsedMs: res.elapsedMs, bytes: res.bytes },
            parsed.finishReason,
            false
          );
        }
        return finishResult(
          text,
          { url: url, status: res.status, statusText: res.statusText, elapsedMs: res.elapsedMs, bytes: res.bytes },
          reader.getFinishReason(),
          true
        );
      }).catch(function (err) {
        throw decorateError(err, url, timeoutMs);
      });
    }

    return requestAIFetch(config, url, bodyText, headers, timeoutMs, events, started);
  }


  function ActionButton(props) {
    return e(
      TouchableOpacity,
      {
        style: [
          styles.btn,
          props.primary ? styles.btnPrimary : null,
          props.danger ? styles.btnDanger : null,
          props.disabled || props.loading ? styles.btnDisabled : null,
          props.style || null,
        ],
        disabled: props.disabled || props.loading,
        onPress: props.onPress,
      },
      props.loading
        ? e(ActivityIndicator, { size: 'small', color: '#fff' })
        : e(Text, { style: [styles.btnText, props.primary || props.danger ? styles.btnTextLight : null] }, props.title)
    );
  }

  function Section(props) {
    return e(View, { style: styles.card },
      props.title ? e(Text, { style: styles.cardTitle }, props.title) : null,
      props.children
    );
  }

  // 按方案的 blocks 渲染手机线框图，颜色/圆角/层级来自方案的 designTokens。
  function wireBlockOf(block, t) {
    var label = block.text || '';
    var desc = block.desc || '';
    var itemRadius = Math.max(10, t.radius - 4);
    if (block.type === 'title') {
      return e(Text, { style: { fontSize: 15, lineHeight: 21, fontWeight: '700', color: t.text } }, label);
    }
    if (block.type === 'button') {
      return e(View, {
        style: {
          backgroundColor: t.primary,
          borderRadius: itemRadius,
          paddingVertical: 9,
          alignItems: 'center',
        },
      }, e(Text, { style: { fontSize: 11, lineHeight: 15, color: t.onPrimary, fontWeight: '600' } }, label));
    }
    if (block.type === 'input') {
      return e(View, {
        style: {
          borderWidth: 1,
          borderColor: t.border,
          borderRadius: itemRadius,
          paddingHorizontal: 8,
          paddingVertical: 8,
          backgroundColor: t.surface,
        },
      }, e(Text, { style: { fontSize: 10, color: t.muted } }, label));
    }
    if (block.type === 'list') {
      return e(View, {
        style: {
          backgroundColor: t.surface,
          borderRadius: t.radius,
          borderWidth: 1,
          borderColor: t.border,
          overflow: 'hidden',
        },
      }, [0, 1, 2].map(function (index) {
        return e(View, {
          key: index,
          style: {
            flexDirection: 'row',
            alignItems: 'center',
            paddingHorizontal: 9,
            paddingVertical: 8,
            borderTopWidth: index === 0 ? 0 : RN.StyleSheet.hairlineWidth,
            borderTopColor: t.border,
          },
        },
          e(View, { style: { width: 6, height: 6, borderRadius: 3, backgroundColor: t.primary, marginRight: 7 } }),
          e(Text, { style: { fontSize: 10, color: index === 0 ? t.text : t.muted, flex: 1 } }, index === 0 ? label : label + ' ' + (index + 1))
        );
      }));
    }
    if (block.type === 'image') {
      return e(View, {
        style: {
          height: 52,
          borderRadius: itemRadius,
          backgroundColor: t.border,
          alignItems: 'center',
          justifyContent: 'center',
        },
      }, e(Text, { style: { fontSize: 10, color: t.muted } }, label));
    }
    if (block.type === 'card') {
      return e(View, {
        style: {
          backgroundColor: t.surface,
          borderRadius: t.radius,
          borderWidth: 1,
          borderColor: t.border,
          padding: 10,
        },
      },
        e(Text, { style: { fontSize: 11, lineHeight: 15, fontWeight: '600', color: t.text } }, label),
        desc ? e(Text, { style: { fontSize: 10, lineHeight: 14, color: t.muted, marginTop: 3 } }, desc) : null
      );
    }
    if (block.type === 'row') {
      var cell = function (text, primary) {
        return e(View, {
          style: {
            flex: 1,
            borderWidth: 1,
            borderColor: primary ? t.primary : t.border,
            borderRadius: itemRadius,
            paddingVertical: 7,
            alignItems: 'center',
            marginRight: 4,
            backgroundColor: t.surface,
          },
        }, e(Text, { style: { fontSize: 9, color: primary ? t.primary : t.muted } }, text));
      };
      return e(View, { style: { flexDirection: 'row' } }, cell(label, false), cell('操作', true));
    }
    return e(Text, { style: { fontSize: 11, lineHeight: 15, color: t.muted } }, label);
  }

  function PhonePreview(props) {
    var screen = props.screen || { title: '主界面', blocks: [] };
    var t = normalizeTokens(props.tokens);
    return e(View, {
      style: {
        width: 186,
        borderWidth: 2,
        borderColor: t.border,
        borderRadius: 20,
        backgroundColor: t.bg,
        paddingHorizontal: 10,
        paddingTop: 10,
        paddingBottom: 14,
        marginRight: 12,
      },
    },
      e(View, { style: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 2 } },
        e(Text, { style: { fontSize: 9, color: t.muted } }, '9:41'),
        e(Text, { style: { fontSize: 9, color: t.muted } }, '5G  100%')
      ),
      e(Text, {
        style: {
          fontSize: 13,
          lineHeight: 18,
          fontWeight: '600',
          color: t.text,
          textAlign: 'center',
          marginTop: 8,
          marginBottom: 8,
          paddingBottom: 6,
          borderBottomWidth: RN.StyleSheet.hairlineWidth,
          borderBottomColor: t.border,
        },
      }, screen.title),
      e(View, { style: { minHeight: 150 } },
        toArray(screen.blocks).map(function (block, index) {
          return e(View, { key: index, style: { marginTop: index === 0 ? 0 : Math.max(6, t.spacing) } }, wireBlockOf(block, t));
        })
      )
    );
  }

  return function AiPluginBuilder() {
    var [tab, setTab] = React.useState('generate');
    var [baseUrl, setBaseUrl] = React.useState(DEFAULT_BASE);
    var [model, setModel] = React.useState(DEFAULT_MODEL);
    var [apiKey, setApiKey] = React.useState('');
    var [keyDraft, setKeyDraft] = React.useState('');
    var [editingKey, setEditingKey] = React.useState(false);
    var [timeoutSec, setTimeoutSec] = React.useState(String(DEFAULT_TIMEOUT_SEC));
    var [maxTokens, setMaxTokens] = React.useState(String(DEFAULT_MAX_TOKENS));
    var [streamOn, setStreamOn] = React.useState(true);
    var [skill, setSkill] = React.useState(DEFAULT_SKILL);
    var [uiSpec, setUiSpec] = React.useState(UI_SPEC);
    var [customSkills, setCustomSkills] = React.useState([]);
    var [editingSkill, setEditingSkill] = React.useState(null);
    var [models, setModels] = React.useState([]);
    var [modelsInfo, setModelsInfo] = React.useState('');
    var [fetchingModels, setFetchingModels] = React.useState(false);
    var [testInfo, setTestInfo] = React.useState('');
    var [progress, setProgress] = React.useState(null);
    var [formatRetry, setFormatRetry] = React.useState(null);
    var [prompt, setPrompt] = React.useState('');
    var [busy, setBusy] = React.useState(false);
    var [status, setStatus] = React.useState('');
    var [error, setError] = React.useState('');
    var [stage, setStage] = React.useState('need');
    var [plan, setPlan] = React.useState(null);
    var [planFeedback, setPlanFeedback] = React.useState('');
    var [planEdit, setPlanEdit] = React.useState(null);
    var [session, setSession] = React.useState(null);
    var [changeRequest, setChangeRequest] = React.useState('');
    var [showDiff, setShowDiff] = React.useState(false);
    var [viewFile, setViewFile] = React.useState('index.js');
    var [history, setHistory] = React.useState([]);
    var [library, setLibrary] = React.useState([]);
    var [renamingId, setRenamingId] = React.useState('');
    var [renameDraft, setRenameDraft] = React.useState('');
    var [importText, setImportText] = React.useState('');
    var [installedRegistry, setInstalledRegistry] = React.useState([]);
    var [conflict, setConflict] = React.useState(null);
    var [catalog, setCatalog] = React.useState([]);
    var [confirming, setConfirming] = React.useState(false);
    var [working, setWorking] = React.useState('');

    var rounds = session && session.rounds ? session.rounds : [];
    var activeIndex = session ? Math.min(session.activeIndex || 0, Math.max(0, rounds.length - 1)) : 0;
    var current = rounds.length ? rounds[activeIndex] : null;
    var latestRound = rounds.length ? rounds[rounds.length - 1] : null;

    React.useEffect(function () {
      Promise.all([
        api.storage.get(KEYS.baseUrl),
        api.storage.get(KEYS.apiKey),
        api.storage.get(KEYS.model),
        api.storage.get(KEYS.timeout),
        api.storage.get(KEYS.maxTokens),
        api.storage.get(KEYS.stream),
        api.storage.get(KEYS.skill),
        api.storage.get(KEYS.history),
        api.storage.get(KEYS.customSkills),
        api.storage.get(KEYS.session),
        api.storage.get(KEYS.sessions),
        api.storage.get(KEYS.installed),
        api.storage.get(KEYS.uiSpec),
      ]).then(function (values) {
        if (values[0]) setBaseUrl(values[0]);
        if (values[1]) setApiKey(values[1]);
        if (values[2]) setModel(values[2]);
        if (values[3]) setTimeoutSec(values[3]);
        if (values[4]) setMaxTokens(values[4]);
        if (values[5] !== null && values[5] !== undefined) setStreamOn(values[5] !== 'false');
        if (values[6]) setSkill(values[6]);
        if (values[7]) {
          try {
            var list = JSON.parse(values[7]);
            if (Array.isArray(list)) setHistory(list);
          } catch (err) {}
        }
        if (values[8]) {
          try {
            var skills = JSON.parse(values[8]);
            if (Array.isArray(skills)) setCustomSkills(skills);
          } catch (err) {}
        }
        var savedSession = null;
        if (values[9]) {
          try { savedSession = normalizeSessionItem(JSON.parse(values[9])); } catch (err) {}
        }
        var lib = [];
        if (values[10]) {
          try {
            var parsed = JSON.parse(values[10]);
            if (Array.isArray(parsed)) {
              lib = parsed.map(normalizeSessionItem).filter(function (item) { return !!item; });
            }
          } catch (err) {}
        }
        if (!lib.length && savedSession) lib = [savedSession];
        lib.sort(function (a, b) { return (b.updatedAt || 0) - (a.updatedAt || 0); });
        lib = lib.slice(0, 12);
        setLibrary(lib);
        if (values[11]) {
          try {
            var registry = JSON.parse(values[11]);
            if (Array.isArray(registry)) setInstalledRegistry(registry);
          } catch (err) {}
        }
        if (values[12]) setUiSpec(values[12]);
        var restore = lib[0] || savedSession;
        if (restore && restore.rounds.length) {
          setSession(restore);
          if (restore.plan) setPlan(restore.plan);
          if (restore.prompt) setPrompt(restore.prompt);
          setStage('result');
        }
      }).catch(function () {});
      api.pluginBuilder.catalog().then(function (list) {
        setCatalog(list || []);
      }).catch(function () {});
    }, []);

    // 会话库持久化：插件私有存储，重启/升级后仍在；卸载后需要导出导入找回。
    React.useEffect(function () {
      if (!session || !session.rounds || !session.rounds.length) return;
      var item = normalizeSessionItem(session);
      if (!item) return;
      setLibrary(function (prev) {
        var list = prev.filter(function (entry) { return entry.id !== item.id; });
        list.unshift(item);
        list.sort(function (a, b) { return (b.updatedAt || 0) - (a.updatedAt || 0); });
        list = list.slice(0, 12);
        api.storage.set(KEYS.sessions, JSON.stringify(list)).catch(function () {});
        return list;
      });
      api.storage.set(KEYS.session, JSON.stringify(item)).catch(function () {});
    }, [session]);

    var configNow = function () {
      return {
        baseUrl: baseUrl,
        apiKey: apiKey,
        model: String(model || '').trim(),
        timeoutSec: Number(timeoutSec) || DEFAULT_TIMEOUT_SEC,
        maxTokens: Number(maxTokens),
        stream: streamOn,
      };
    };

    var fail = function (err) {
      setBusy(false);
      setWorking('');
      setProgress(null);
      if (err && (err.url || err.status || err.phase || err.kind)) {
        setError(describeRequestError(err, configNow()));
      } else {
        setError((err && err.message) || String(err));
      }
    };

    var saveConfig = function () {
      var sec = Math.max(MIN_TIMEOUT_SEC, Math.min(MAX_TIMEOUT_SEC, Number(timeoutSec) || DEFAULT_TIMEOUT_SEC));
      var tokens = Math.floor(Number(maxTokens));
      if (isNaN(tokens) || tokens < 0) tokens = DEFAULT_MAX_TOKENS;
      setTimeoutSec(String(sec));
      setMaxTokens(String(tokens));
      Promise.all([
        api.storage.set(KEYS.baseUrl, normalizeBase(baseUrl)),
        api.storage.set(KEYS.model, String(model || '').trim()),
        api.storage.set(KEYS.timeout, String(sec)),
        api.storage.set(KEYS.maxTokens, String(tokens)),
        api.storage.set(KEYS.stream, streamOn ? 'true' : 'false'),
      ]).then(function () {
        setStatus('配置已保存（超时 ' + sec + ' 秒，最大输出 ' + (tokens || '不限制') + ' tokens）');
        setError('');
      }).catch(fail);
    };

    var saveKey = function () {
      var next = String(keyDraft || '').trim();
      api.storage.set(KEYS.apiKey, next).then(function () {
        setApiKey(next);
        setKeyDraft('');
        setEditingKey(false);
        setStatus(next ? 'API Key 已保存在本机（仅脱敏显示）' : '已清除 API Key');
        setError('');
      }).catch(fail);
    };

    var saveSkill = function () {
      var next = String(skill || '').trim() ? String(skill) : DEFAULT_SKILL;
      api.storage.set(KEYS.skill, next).then(function () {
        setSkill(next);
        setStatus('Skill 已保存，之后生成会自动带上');
        setError('');
      }).catch(fail);
    };

    var restoreSkill = function () {
      setSkill(DEFAULT_SKILL);
      api.storage.set(KEYS.skill, DEFAULT_SKILL).catch(function () {});
      setStatus('已恢复默认 Skill');
      setError('');
    };

    var saveUiSpec = function () {
      var next = String(uiSpec || '').trim() ? String(uiSpec) : UI_SPEC;
      api.storage.set(KEYS.uiSpec, next).then(function () {
        setUiSpec(next);
        setStatus('界面设计规范已保存，方案与生成都会带上');
        setError('');
      }).catch(fail);
    };

    var restoreUiSpec = function () {
      setUiSpec(UI_SPEC);
      api.storage.set(KEYS.uiSpec, UI_SPEC).catch(function () {});
      setStatus('已恢复默认界面设计规范');
      setError('');
    };

    var applyPreset = function (preset) {
      setBaseUrl(preset.baseUrl);
      setModel(preset.model);
      setModels([]);
      setModelsInfo('已填入「' + preset.label + '」预设，可点「拉取模型」按 /models 校正');
      setTestInfo('');
      setStatus('已填入 ' + preset.label + ' 预设，仍可手动修改');
      setError('');
    };

    var fetchModelsNow = function (showState) {
      var cfg = configNow();
      if (!cfg.apiKey) {
        setModelsInfo('请先填写 API Key');
        return Promise.reject(new Error('请先填写 API Key'));
      }
      if (showState) setFetchingModels(true);
      return fetchModels(cfg).then(function (result) {
        setModels(result.ids);
        var extra = '';
        if (result.ids.length && result.ids.indexOf(cfg.model) < 0) {
          extra = '；当前模型「' + cfg.model + '」不在列表里，可点选下方模型';
        }
        setModelsInfo('已从 ' + result.url + ' 获取 ' + result.ids.length + ' 个模型（' + fmtDuration(result.elapsedMs) + '）' + extra);
        setFetchingModels(false);
        return result;
      }).catch(function (err) {
        var detail = err && err.body ? truncate(err.body, 160) : ((err && err.message) || String(err));
        setModelsInfo('获取模型列表失败：' + (err && err.status ? 'HTTP ' + err.status + ' ' : '') + detail);
        setFetchingModels(false);
        throw err;
      });
    };

    var shortError = function (err) {
      if (!err) return '未知错误';
      var head = err.status ? 'HTTP ' + err.status : (err.message || '请求失败');
      return err.body ? head + '：' + truncate(err.body, 120) : head;
    };

    var testConnection = function () {
      var cfg = configNow();
      if (!apiKey) {
        setError('请先在「配置」里填写 API Key');
        setTab('config');
        return;
      }
      cfg.stream = false;
      cfg.maxTokens = 16;
      setBusy(true);
      setWorking('正在测试连接');
      setError('');
      setStatus('');
      setTestInfo('');

      var modelsResult = null;
      var modelsError = null;

      fetchModels(cfg).then(function (result) {
        modelsResult = result;
        setModels(result.ids);
        return null;
      }).catch(function (err) {
        modelsError = err;
        return null;
      }).then(function () {
        return requestAI(cfg, [{ role: 'user', content: '只回复 OK' }], {});
      }).then(function (res) {
        var lines = ['连接成功'];
        lines.push('实际请求：' + res.url);
        lines.push('HTTP ' + res.status + ' · 耗时 ' + fmtDuration(res.elapsedMs));
        if (modelsResult) {
          var names = modelsResult.ids.slice(0, 10).join(', ');
          lines.push('模型列表：' + modelsResult.ids.length + ' 个' + (names ? '（' + names + (modelsResult.ids.length > 10 ? '…' : '') + '）' : ''));
        } else {
          lines.push('模型列表不可用：' + shortError(modelsError) + '（不影响生成）');
        }
        var hint = baseUrlHint(cfg.baseUrl);
        if (hint) lines.push(hint);
        setTestInfo(lines.join('\n'));
        setBusy(false);
        setWorking('');
        setStatus('连接成功');
      }).catch(function (err) {
        // 推理型模型可能把 max_tokens 全用在 reasoning 上，content 为空但连接是通的
        if (err && err.status === 200) {
          var lines2 = ['连接成功（HTTP 200，但正文为空）'];
          lines2.push('实际请求：' + err.url);
          lines2.push('耗时：' + fmtDuration(err.elapsedMs));
          lines2.push('服务端返回：' + truncate(err.body, 200));
          lines2.push('说明：该模型可能把输出额度用在了推理内容上，生成时会把最大输出 tokens 调大。');
          if (modelsResult) {
            lines2.push('模型列表：' + modelsResult.ids.join(', '));
          }
          setTestInfo(lines2.join('\n'));
          setBusy(false);
          setWorking('');
          setStatus('连接成功');
          return;
        }
        var base = normalizeBase(cfg.baseUrl);
        if (err && err.status === 404 && !/\/v1$/i.test(base) && !/\/chat\/completions$/i.test(base)) {
          var altBase = base + '/v1';
          var altCfg = Object.assign({}, cfg, { baseUrl: altBase });
          requestAI(altCfg, [{ role: 'user', content: '只回复 OK' }], {}).then(function (res) {
            setTestInfo([
              '当前地址返回 404，但补上 /v1 后连接成功',
              '建议把 API 地址改为：' + altBase,
              '实际请求：' + res.url,
              'HTTP ' + res.status + ' · 耗时 ' + fmtDuration(res.elapsedMs),
            ].join('\n'));
            setBusy(false);
            setWorking('');
            setStatus('连接成功（建议补 /v1）');
          }).catch(function () {
            setBusy(false);
            setWorking('');
            setError(describeRequestError(err, cfg));
          });
          return;
        }
        setBusy(false);
        setWorking('');
        setError(describeRequestError(err, cfg));
      });
    };

    var saveHistory = function (entry) {
      setHistory(function (prev) {
        var next = [entry].concat(prev).slice(0, HISTORY_LIMIT);
        api.storage.set(KEYS.history, JSON.stringify(next)).catch(function () {});
        return next;
      });
    };

    var composeSystem = function () {
      var base = String(skill || '').trim() || DEFAULT_SKILL;
      var ui = String(uiSpec || '').trim() || UI_SPEC;
      var extras = customSkills.map(function (item) {
        if (!item || !String(item.content || '').trim()) return '';
        return '【自定义技能：' + (item.name || '未命名') + '】\n' + String(item.content).trim();
      }).filter(function (text) { return !!text; }).join('\n\n');
      return base + (extras ? '\n\n' + extras : '') + '\n\n' + ui;
    };

    var planForAI = function (value) {
      if (!value) return null;
      return {
        manifest: value.manifest,
        permissionReasons: value.permissionReasons,
        designTokens: value.designTokens,
        screens: value.screens,
        interactions: value.interactions,
        storage: value.storage,
        steps: value.steps,
      };
    };

    var runModel = function (messages, workingText, onOk) {
      setBusy(true);
      setWorking(workingText);
      setError('');
      setStatus('');
      setProgress(null);
      setFormatRetry(null);
      setConfirming(false);

      var lastUpdate = 0;
      var lastPhase = '';
      var onProgress = function (info) {
        var now = Date.now();
        // 阶段切换必须立即展示；只有接收中的高频预览做节流
        if (info.phase !== lastPhase) {
          lastPhase = info.phase;
          lastUpdate = now;
          setProgress(info);
          return;
        }
        if (now - lastUpdate < 250) return;
        lastUpdate = now;
        setProgress(info);
      };

      requestAI(configNow(), messages, { onProgress: onProgress }).then(function (res) {
        return Promise.resolve(onOk(res));
      }).then(function () {
        setBusy(false);
        setWorking('');
        setProgress(null);
      }).catch(function (err) {
        fail(err);
      });
    };

    var ensureKey = function () {
      if (apiKey) return true;
      setError('请先在「配置」里填写 API Key');
      setTab('config');
      return false;
    };

    // 方案阶段：只产出方案，不产出代码。
    var requestPlan = function (feedback, usePrevious) {
      var need = String((plan && plan.prompt) || prompt || '').trim();
      if (!need) {
        setError('请先描述你想要的插件');
        return;
      }
      if (!ensureKey()) return;
      var content = '用户需求：\n' + need + '\n\n请先输出结构化方案（JSON），此阶段不要写代码。';
      if (usePrevious && plan) {
        content += '\n\n当前方案（JSON）：\n' + JSON.stringify(planForAI(plan), null, 2);
      }
      if (feedback) {
        content += '\n\n用户对方案的补充要求：\n' + feedback + '\n\n请按这些要求重写完整方案。';
      }
      runModel([
        { role: 'system', content: composeSystem() + '\n\n' + PLAN_SKILL },
        { role: 'user', content: content },
      ], feedback ? 'AI 正在重写方案' : 'AI 正在设计插件方案', function (res) {
        var nextPlan;
        try {
          nextPlan = parsePlan(res.content, need);
        } catch (err) {
          setError(
            err.message +
            '\n已接收 ' + res.content.length + ' 字符，耗时 ' + fmtDuration(res.elapsedMs) + '，HTTP ' + res.status + '。' +
            '\n可点「按 Skill 纠偏重试」，或补充要求后重试。'
          );
          setFormatRetry({ stage: 'plan', prompt: need, feedback: feedback || '', raw: res.content });
          return null;
        }
        setPlan(nextPlan);
        setStage('plan');
        setPlanEdit(null);
        setPlanFeedback('');
        setFormatRetry(null);
        setStatus('方案已生成（' + fmtDuration(res.elapsedMs) + '）。确认前可查看界面预览图，也可让 AI 重写或手动编辑要点。');
        return null;
      });
    };

    var makePlan = function () {
      requestPlan('', false);
    };

    var rewritePlan = function () {
      var feedback = String(planFeedback || '').trim();
      if (!feedback) {
        setError('请先填写对方案的补充要求，例如「把主界面改成两列」');
        return;
      }
      requestPlan(feedback, true);
    };

    var openPlanEditor = function () {
      if (!plan) return;
      setPlanEdit({
        id: plan.manifest.id,
        name: plan.manifest.name,
        version: plan.manifest.version,
        description: plan.manifest.description,
        permissions: plan.manifest.permissions.slice(),
        reasonText: plan.manifest.permissions.map(function (key) {
          return key + '：' + (plan.permissionReasons[key] || '');
        }).join('\n'),
        screenText: screensToLines(plan.screens),
        interactionText: plan.interactions.join('\n'),
        storageText: plan.storage.join('\n'),
        stepsText: plan.steps.join('\n'),
      });
      setError('');
    };

    var updatePlanEdit = function (patch) {
      setPlanEdit(function (prev) { return Object.assign({}, prev || {}, patch); });
    };

    var togglePlanPermission = function (key) {
      if (!planEdit) return;
      var list = toArray(planEdit.permissions).slice();
      var index = list.indexOf(key);
      if (index >= 0) list.splice(index, 1);
      else list.push(key);
      updatePlanEdit({ permissions: list });
    };

    var savePlanEdit = function () {
      if (!planEdit || !plan) return;
      var permissions = toArray(planEdit.permissions).filter(function (key) {
        return PERMISSION_KEYS.indexOf(key) >= 0;
      });
      var reasons = {};
      String(planEdit.reasonText || '').split('\n').forEach(function (line) {
        var text = line.trim();
        if (!text) return;
        var at = text.indexOf('：');
        if (at < 0) at = text.indexOf(':');
        if (at <= 0) return;
        var key = text.slice(0, at).trim();
        var reason = text.slice(at + 1).trim();
        if (PERMISSION_KEYS.indexOf(key) >= 0 && reason) reasons[key] = reason;
      });
      permissions.forEach(function (key) {
        if (!reasons[key]) reasons[key] = '用于实现方案中的相关功能';
      });
      var splitLines = function (text) {
        return String(text || '').split('\n').map(function (line) { return line.trim(); })
          .filter(function (line) { return !!line; });
      };
      setPlan({
        manifest: {
          id: String(planEdit.id || '').trim(),
          name: String(planEdit.name || '').trim(),
          version: semverOf(planEdit.version),
          description: String(planEdit.description || '').trim(),
          permissions: permissions,
        },
        permissionReasons: reasons,
        designTokens: plan.designTokens || normalizeTokens(null),
        screens: linesToScreens(planEdit.screenText),
        interactions: splitLines(planEdit.interactionText),
        storage: splitLines(planEdit.storageText),
        steps: splitLines(planEdit.stepsText),
        prompt: plan.prompt,
      });
      setPlanEdit(null);
      setStatus('方案要点已保存，可确认并生成');
      setError('');
    };

    var applyCheck = function (payload, check, info) {
      var warnings = (check.warnings || []).slice();
      if (info.meta && info.meta.truncated) {
        warnings.push('模型输出达到 max_tokens 上限（finish_reason=length），代码可能被截断；可在「配置」里调大最大输出 tokens');
      }
      var meta = info.meta || {};
      var manifest = Object.assign({}, check.manifest || payload.manifest || {});
      manifest.version = semverOf(manifest.version || (payload.manifest && payload.manifest.version) || '1.0.0');
      var entry = {
        createdAt: Date.now(),
        round: rounds.length + 1,
        kind: info.kind,
        request: info.request || '',
        prompt: info.userPrompt || prompt,
        raw: JSON.stringify(payload),
        files: info.files,
        manifest: manifest,
        ok: check.ok,
        errors: check.errors || [],
        warnings: warnings,
        elapsedMs: meta.elapsedMs || 0,
        streamed: !!meta.streamed,
        truncated: !!meta.truncated,
      };
      setSession(function (prev) {
        var base = info.kind === 'generate' || !prev
          ? {
              id: 's' + Date.now() + '_' + Math.floor(Math.random() * 1000),
              name: sessionNameOf(info.plan || plan, info.userPrompt || prompt),
              createdAt: Date.now(),
              prompt: info.userPrompt || prompt,
              plan: info.plan || plan,
              rounds: [],
              activeIndex: 0,
            }
          : prev;
        var list = base.rounds.concat([entry]);
        return {
          id: base.id,
          name: base.name,
          createdAt: base.createdAt,
          updatedAt: Date.now(),
          prompt: base.prompt,
          plan: base.plan || info.plan || plan,
          rounds: list,
          activeIndex: list.length - 1,
        };
      });
      setStage('result');
      setViewFile('index.js');
      setShowDiff(false);
      setConfirming(false);
      setChangeRequest('');
      var timing = meta.elapsedMs
        ? '（' + (meta.streamed ? '流式接收 ' : '总耗时 ') + fmtDuration(meta.elapsedMs) + (meta.status ? '，HTTP ' + meta.status : '') + '）'
        : '';
      if (check.ok) {
        setStatus('第 ' + entry.round + ' 轮校验通过' + timing + (warnings.length ? '；提示：' + warnings.join('；') : ''));
      } else {
        setStatus('第 ' + entry.round + ' 轮校验未通过' + timing + '，可让 AI 按具体错误修正');
      }
      saveHistory(entry);
      return entry;
    };

    var validatePayload = function (payload, info) {
      var manifest = Object.assign({}, payload.manifest || {});
      if (info.version) manifest.version = semverOf(info.version);
      var nextPayload = Object.assign({}, payload, { manifest: manifest });
      var files = info.filesOverride || buildFiles(nextPayload);
      setStatus('正在校验生成结果');
      return api.pluginBuilder.validate(files).then(function (check) {
        return applyCheck(nextPayload, check, Object.assign({}, info, { files: files }));
      });
    };

    var generateFromPlan = function () {
      if (!plan) return;
      if (!ensureKey()) return;
      var planText = JSON.stringify({ plan: planForAI(plan) }, null, 2);
      runModel([
        { role: 'system', content: composeSystem() },
        {
          role: 'user',
          content:
            '已确认的插件方案（JSON）：\n' + planText +
            '\n\n请严格按方案实现，并按 Skill 输出单个 JSON 对象，包含 manifest 与 indexJs。' +
            'manifest 使用方案里的 id、name、version 与 permissions；确有必要可增减权限，但代码里必须真实使用对应 api。',
        },
      ], 'AI 正在按方案生成插件', function (res) {
        var payload;
        try {
          payload = parsePayload(res.content);
        } catch (err) {
          var detail = err.message;
          if (res.truncated) {
            detail += '\n模型输出达到 max_tokens 上限（finish_reason=length），响应被截断；请调大最大输出 tokens 或简化方案。';
          }
          detail += '\n已接收 ' + res.content.length + ' 字符，耗时 ' + fmtDuration(res.elapsedMs) + '，HTTP ' + res.status + '。';
          detail += '\n可点「按 Skill 纠偏重试」，把格式要求和上次原始输出一起发回模型。';
          setError(detail);
          setFormatRetry({ stage: 'code', prompt: plan.prompt || prompt, raw: res.content });
          return null;
        }
        return validatePayload(payload, {
          kind: 'generate',
          request: '按确认的方案生成',
          version: plan.manifest.version,
          userPrompt: plan.prompt || prompt,
          plan: plan,
          meta: res,
        });
      });
    };

    var editCode = function () {
      var need = String(changeRequest || '').trim();
      if (!need) {
        setError('请先写下要改什么，例如「把按钮改大」或「加一个历史记录」');
        return;
      }
      if (!current) return;
      if (!ensureKey()) return;
      var source = current;
      var baseVersion = (source.manifest && source.manifest.version) || '1.0.0';
      var nextVersion = bumpPatch(baseVersion);
      var code = source.files && source.files['index.js'] ? String(source.files['index.js']) : '';
      runModel([
        { role: 'system', content: composeSystem() },
        {
          role: 'user',
          content:
            '这是插件的当前完整版本（v' + baseVersion + '）。请在保持现有功能的前提下按要求修改，并输出修改后的完整代码。\n\n' +
            '当前 manifest.json：\n' + JSON.stringify(source.manifest || {}, null, 2) +
            '\n\n当前 index.js 全文：\n' + code +
            '\n\n本轮修改要求：\n' + need +
            '\n\n请只输出 Skill 规定的单个 JSON 对象，必须包含完整 manifest 与 indexJs 全文，不要只给补丁或解释。版本号由我统一递增，你可以保留原值。',
        },
      ], 'AI 正在修改插件（第 ' + (rounds.length + 1) + ' 轮）', function (res) {
        var payload;
        try {
          payload = parsePayload(res.content);
        } catch (err) {
          setError(
            err.message + '\n已接收 ' + res.content.length + ' 字符，耗时 ' + fmtDuration(res.elapsedMs) + '。' +
            '\n可点「按 Skill 纠偏重试」重新要求完整 JSON。'
          );
          setFormatRetry({ stage: 'code', prompt: source.prompt || prompt, raw: res.content, change: need });
          return null;
        }
        return validatePayload(payload, {
          kind: 'edit',
          request: need,
          version: nextVersion,
          userPrompt: source.prompt || prompt,
          plan: session ? session.plan : plan,
          meta: res,
        });
      });
    };

    var repair = function () {
      if (!current) return;
      if (!ensureKey()) return;
      var problems = (current.errors || [])
        .map(function (item) { return '- ' + item.field + '：' + item.message; })
        .join('\n');
      var code = current.files && current.files['index.js'] ? String(current.files['index.js']) : '';
      var nextVersion = bumpPatch(current.manifest && current.manifest.version);
      runModel([
        { role: 'system', content: composeSystem() },
        {
          role: 'user',
          content:
            '下面这版插件未通过宿主校验，请逐条修正后重新输出完整 JSON。\n\n' +
            '原始需求：' + (current.prompt || prompt) + '\n\n' +
            '当前 manifest.json：\n' + JSON.stringify(current.manifest || {}, null, 2) + '\n\n' +
            '当前 index.js 全文：\n' + code + '\n\n' +
            '具体校验错误：\n' + problems + '\n\n' +
            '请只返回修正后的完整 JSON（manifest + indexJs 全文），不要只给补丁或解释。',
        },
      ], 'AI 正在按校验问题修正', function (res) {
        var payload;
        try {
          payload = parsePayload(res.content);
        } catch (err) {
          setError(err.message + '\n已接收 ' + res.content.length + ' 字符，耗时 ' + fmtDuration(res.elapsedMs) + '。');
          setFormatRetry({ stage: 'code', prompt: current.prompt || prompt, raw: res.content });
          return null;
        }
        return validatePayload(payload, {
          kind: 'fix',
          request: '按校验错误修正',
          version: nextVersion,
          userPrompt: current.prompt || prompt,
          plan: session ? session.plan : plan,
          meta: res,
        });
      });
    };

    var retryFormat = function () {
      if (!formatRetry) return;
      if (!ensureKey()) return;
      if (formatRetry.stage === 'plan') {
        requestPlan(formatRetry.feedback || '', true);
        return;
      }
      var requirement = formatRetry.change
        ? '\n\n本轮修改要求：' + formatRetry.change
        : '';
      runModel([
        { role: 'system', content: composeSystem() },
        {
          role: 'user',
          content:
            '你上一次的输出没有满足 Skill 要求的 JSON 格式，无法解析。\n\n' +
            '用户需求：' + formatRetry.prompt + requirement + '\n\n' +
            '上一次原始输出（可能被截断）：\n' + truncate(formatRetry.raw, 6000) + '\n\n' +
            '请严格只输出 Skill 规定的单个 JSON 对象，必须包含 manifest 和 indexJs，不要代码块、不要解释。',
        },
      ], 'AI 正在按 Skill 纠偏', function (res) {
        var payload;
        try {
          payload = parsePayload(res.content);
        } catch (err) {
          setError(err.message + '\n已接收 ' + res.content.length + ' 字符，耗时 ' + fmtDuration(res.elapsedMs) + '。');
          return null;
        }
        var baseVersion = latestRound && latestRound.manifest ? latestRound.manifest.version : ((plan && plan.manifest.version) || '1.0.0');
        return validatePayload(payload, {
          kind: 'fix',
          request: '按 Skill 格式纠偏',
          version: bumpPatch(baseVersion),
          userPrompt: formatRetry.prompt,
          plan: session ? session.plan : plan,
          meta: res,
        });
      });
    };

    var viewRound = function (index) {
      setSession(function (prev) {
        if (!prev) return prev;
        return Object.assign({}, prev, { activeIndex: index });
      });
      setShowDiff(false);
      setConfirming(false);
      var target = rounds[index];
      setStatus(target ? '正在查看第 ' + target.round + ' 轮（v' + versionOf(target.manifest) + '）' : '');
    };

    var rollbackTo = function (index) {
      var target = rounds[index];
      if (!target || !target.ok) return;
      var baseVersion = latestRound && latestRound.manifest ? latestRound.manifest.version : target.manifest.version;
      var nextVersion = bumpPatch(baseVersion);
      var payload = {
        manifest: Object.assign({}, target.manifest),
        indexJs: target.files['index.js'],
        iconBase64: null,
      };
      payload.manifest.version = nextVersion;
      var files = {};
      Object.keys(target.files || {}).forEach(function (name) {
        files[name] = target.files[name];
      });
      files['manifest.json'] = JSON.stringify(payload.manifest, null, 2);
      files['index.js'] = payload.indexJs;
      setStatus('正在回退到第 ' + target.round + ' 轮');
      validatePayload(payload, {
        kind: 'rollback',
        request: '回退到第 ' + target.round + ' 轮（v' + versionOf(target.manifest) + '）',
        version: nextVersion,
        userPrompt: session ? session.prompt : prompt,
        plan: session ? session.plan : plan,
        filesOverride: files,
        meta: { elapsedMs: 0, streamed: false, truncated: false },
      }).catch(fail);
    };

    var doExport = function () {
      if (!current) return;
      var mf = current.manifest || {};
      var name = (mf.id || 'plugin') + '-' + versionOf(mf) + '.zip';
      setBusy(true);
      setWorking('正在打包导出');
      setError('');
      api.exportFile.zip(current.files, name).then(function (result) {
        setBusy(false);
        setWorking('');
        setStatus('已导出到 ' + result.path + '（' + result.size + ' 字节）');
      }).catch(fail);
    };

    var upsertRegistry = function (record) {
      var entry = {
        id: record.id,
        name: record.name,
        version: versionOf(record),
        installedAt: Date.now(),
      };
      setInstalledRegistry(function (prev) {
        var list = prev.filter(function (item) { return item.id !== entry.id; });
        list.unshift(entry);
        api.storage.set(KEYS.installed, JSON.stringify(list)).catch(function () {});
        return list;
      });
    };

    var findConflict = function (manifest) {
      var id = String(manifest.id || '').toLowerCase();
      var name = String(manifest.name || '').trim();
      var sameId = null;
      var sameName = null;
      installedRegistry.forEach(function (item) {
        if (String(item.id || '').toLowerCase() === id) sameId = item;
        else if (name && item.name === name) sameName = item;
      });
      return sameId || sameName ? { sameId: sameId, sameName: sameName } : null;
    };

    var nextPluginId = function (baseId) {
      var base = String(baseId || 'com.ai.generated');
      var index = 2;
      var exists = function (id) {
        if (installedRegistry.some(function (item) { return item.id === id; })) return true;
        return library.some(function (item) {
          var m = item.plan && item.plan.manifest;
          return m && m.id === id;
        });
      };
      while (exists(base + '.' + index)) index += 1;
      return base + '.' + index;
    };

    var nextPluginName = function (baseName) {
      var base = String(baseName || 'AI 插件').slice(0, 24);
      var index = 2;
      while (installedRegistry.some(function (item) { return item.name === base + ' ' + index; })) {
        index += 1;
      }
      return base + ' ' + index;
    };

    // 安装入口：先查本插件安装记录，有冲突就交给用户选择，不再直接失败。
    var startInstall = function () {
      if (!current || !current.ok) return;
      var mf = current.manifest || {};
      var hit = findConflict(mf);
      setConfirming(false);
      setError('');
      if (hit) {
        setConflict({
          sameId: hit.sameId,
          sameName: hit.sameName,
          currentId: mf.id,
          currentName: mf.name,
          currentVersion: versionOf(mf),
        });
        setStatus('检测到插件冲突，请选择处理方式');
        return;
      }
      setConflict(null);
      setConfirming(true);
    };

    var installCurrent = function (mode) {
      if (!current || !current.ok) return;
      var manifest = Object.assign({}, current.manifest || {});
      var files = Object.assign({}, current.files || {});
      var installed = conflict && conflict.sameId ? conflict.sameId : null;
      var note = '';
      if (mode === 'bump') {
        var installedVersion = installed ? versionOf(installed) : '1.0.0';
        var targetVersion = versionOf(manifest);
        manifest.version = versionGt(targetVersion, installedVersion) ? targetVersion : bumpPatch(installedVersion);
        note = '已升版本到 v' + manifest.version + '；同 id 覆盖安装，旧插件的 storage/files 数据保留';
      } else if (mode === 'rename') {
        manifest.id = nextPluginId(manifest.id);
        manifest.name = nextPluginName(manifest.name);
        note = '已改为新 id ' + manifest.id + '、新名称「' + manifest.name + '」；作为全新插件安装，不迁移旧插件数据';
      } else {
        note = '同 id 覆盖安装，旧代码被替换；插件私有数据按 id 保留';
      }
      files['manifest.json'] = JSON.stringify(manifest, null, 2);

      setBusy(true);
      setWorking('正在安装插件');
      setError('');
      setConfirming(false);
      setConflict(null);

      api.pluginBuilder.validate(files).then(function (check) {
        if (!check.ok) {
          var first = check.errors && check.errors[0];
          throw new Error('调整后的 manifest 未通过校验：' + (first ? first.field + ' - ' + first.message : '未知错误'));
        }
        return api.pluginBuilder.install(files);
      }).then(function (record) {
        setBusy(false);
        setWorking('');
        upsertRegistry({ id: record.id, name: record.name, version: record.version || manifest.version });
        setStatus('已安装「' + record.name + '」v' + versionOf(record) + '（' + note + '），正在打开…');
        api.pluginBuilder.open(record.id, record.name).catch(function (err) {
          setError('安装成功，但打开失败：' + ((err && err.message) || String(err)));
        });
      }).catch(function (err) {
        setBusy(false);
        setWorking('');
        var detail = (err && err.message) || String(err);
        var list = err && err.errors
          ? err.errors.map(function (item) { return '· ' + item.field + '：' + item.message; }).join('\n')
          : '';
        setError(
          '安装失败：' + detail +
          (list ? '\n' + list : '') +
          '\n可选处理：升版本安装（同 id、保留数据） / 改名成新 id / 覆盖安装。'
        );
      });
    };

    var openSession = function (item) {
      var normalized = normalizeSessionItem(item);
      if (!normalized) return;
      setSession(normalized);
      setPlan(normalized.plan || null);
      setPrompt(normalized.prompt || '');
      setStage('result');
      setTab('generate');
      setViewFile('index.js');
      setShowDiff(false);
      setConfirming(false);
      setConflict(null);
      setError('');
      setStatus('已打开会话「' + normalized.name + '」，共 ' + normalized.rounds.length + ' 轮');
    };

    var beginRenameSession = function (item) {
      setRenamingId(item.id);
      setRenameDraft(item.name || '');
      setError('');
    };

    var saveRenameSession = function () {
      var name = String(renameDraft || '').trim();
      if (!renamingId) return;
      if (!name) {
        setError('会话名称不能为空');
        return;
      }
      setLibrary(function (prev) {
        var list = prev.map(function (item) {
          return item.id === renamingId ? Object.assign({}, item, { name: name }) : item;
        });
        api.storage.set(KEYS.sessions, JSON.stringify(list)).catch(function () {});
        return list;
      });
      setSession(function (prev) {
        return prev && prev.id === renamingId ? Object.assign({}, prev, { name: name }) : prev;
      });
      setRenamingId('');
      setRenameDraft('');
      setStatus('会话已重命名为「' + name + '」');
    };

    var deleteSession = function (item) {
      setLibrary(function (prev) {
        var list = prev.filter(function (entry) { return entry.id !== item.id; });
        api.storage.set(KEYS.sessions, JSON.stringify(list)).catch(function () {});
        return list;
      });
      if (session && session.id === item.id) {
        setSession(null);
        setPlan(null);
        setStage('need');
        setStatus('已删除当前会话');
      } else {
        setStatus('已删除会话「' + item.name + '」');
      }
    };

    var exportPayload = function (list) {
      return JSON.stringify({
        app: 'plugin-manager',
        kind: 'ai-pluginbuilder-sessions',
        version: 1,
        exportedAt: new Date().toISOString(),
        sessions: list,
      }, null, 2);
    };

    var doExportSessions = function () {
      if (!library.length) {
        setError('没有可导出的会话');
        return;
      }
      setBusy(true);
      setWorking('正在导出会话');
      setError('');
      api.exportFile.zip({ 'sessions.json': exportPayload(library) }, 'ai-pluginbuilder-sessions.zip')
        .then(function (result) {
          setBusy(false);
          setWorking('');
          setStatus('已导出 ' + library.length + ' 个会话到 ' + result.path + '；解压后把 sessions.json 内容粘贴回来即可导入');
        }).catch(fail);
    };

    var copySessions = function () {
      if (!library.length) {
        setError('没有可复制的会话');
        return;
      }
      api.clipboard.set(exportPayload(library)).then(function () {
        setStatus('已复制 ' + library.length + ' 个会话到剪贴板，可粘贴到聊天/笔记长期保存');
      }).catch(fail);
    };

    var pasteFromClipboard = function () {
      api.clipboard.get().then(function (text) {
        setImportText(text || '');
        setStatus('已读取剪贴板，请检查内容后点「导入会话」');
        setError('');
      }).catch(fail);
    };

    var importSessions = function () {
      var text = String(importText || '').trim();
      if (!text) {
        setError('请先粘贴导出的会话 JSON');
        return;
      }
      var data;
      try {
        data = JSON.parse(text);
      } catch (err) {
        setError('导入失败：内容不是合法 JSON');
        return;
      }
      var incoming = Array.isArray(data) ? data : (data && data.sessions);
      if (!Array.isArray(incoming)) {
        setError('导入失败：JSON 里没有 sessions 数组');
        return;
      }
      var normalized = incoming.map(normalizeSessionItem).filter(function (item) { return !!item; });
      if (!normalized.length) {
        setError('导入失败：没有可用的会话');
        return;
      }
      setLibrary(function (prev) {
        var map = {};
        prev.forEach(function (item) { map[item.id] = item; });
        normalized.forEach(function (item) { map[item.id] = item; });
        var list = Object.keys(map).map(function (key) { return map[key]; });
        list.sort(function (a, b) { return (b.updatedAt || 0) - (a.updatedAt || 0); });
        list = list.slice(0, 12);
        api.storage.set(KEYS.sessions, JSON.stringify(list)).catch(function () {});
        return list;
      });
      setImportText('');
      setError('');
      setStatus('已导入 ' + normalized.length + ' 个会话' + (data && data.exportedAt ? '（导出于 ' + data.exportedAt + '）' : ''));
    };

    var saveCustomSkills = function (list) {
      setCustomSkills(list);
      api.storage.set(KEYS.customSkills, JSON.stringify(list)).catch(function () {});
    };

    var startSkillEdit = function (item) {
      setEditingSkill(item
        ? { id: item.id, name: item.name, content: item.content }
        : { id: '', name: '', content: '' });
      setError('');
    };

    var updateSkillEdit = function (patch) {
      setEditingSkill(function (prev) { return Object.assign({}, prev || {}, patch); });
    };

    var saveSkillEntry = function () {
      if (!editingSkill) return;
      var name = String(editingSkill.name || '').trim();
      var content = String(editingSkill.content || '').trim();
      if (!name) {
        setError('请给这条技能起个名字');
        return;
      }
      if (!content) {
        setError('技能内容不能为空');
        return;
      }
      var id = editingSkill.id || ('skill-' + Date.now());
      var next = customSkills.slice();
      var found = false;
      for (var i = 0; i < next.length; i += 1) {
        if (next[i].id === id) {
          next[i] = { id: id, name: name, content: content };
          found = true;
          break;
        }
      }
      if (!found) next.push({ id: id, name: name, content: content });
      saveCustomSkills(next);
      setEditingSkill(null);
      setStatus('自定义技能「' + name + '」已保存，生成与改码时会一并带上');
      setError('');
    };

    var removeSkillEntry = function (id) {
      saveCustomSkills(customSkills.filter(function (item) { return item.id !== id; }));
      setStatus('已删除自定义技能');
    };

    var startNew = function () {
      setPrompt('');
      setPlan(null);
      setSession(null);
      api.storage.remove(KEYS.session).catch(function () {});
      setStage('need');
      setTab('generate');
      setStatus('已新建会话，可以描述新插件；旧会话仍保留在「会话」里');
      setError('');
      setConfirming(false);
      setConflict(null);
      setPlanEdit(null);
      setFormatRetry(null);
      setChangeRequest('');
      setShowDiff(false);
    };

    var permissionLabel = function (key) {
      for (var i = 0; i < catalog.length; i += 1) {
        if (catalog[i].key === key) return catalog[i].label + '（' + key + '）';
      }
      return key;
    };
    var permissionDesc = function (key) {
      for (var i = 0; i < catalog.length; i += 1) {
        if (catalog[i].key === key) return catalog[i].desc;
      }
      return '';
    };

    var progressLabel = function () {
      if (!progress) return working || '处理中…';
      var elapsed = fmtDuration(progress.elapsedMs);
      if (progress.phase === 'connecting') {
        return '正在连接/等待响应：' + (progress.url || chatUrlOf(baseUrl)) + '（已等待 ' + elapsed + '）';
      }
      if (progress.phase === 'waiting') {
        return '已建立连接（HTTP ' + (progress.status || '?') + '），等待模型返回…（' + elapsed + '）';
      }
      var size = progress.bytes ? progress.bytes + ' 字节 / ' : '';
      var chars = progress.preview ? progress.preview.length + ' 字符' : '';
      if (progress.thinking) {
        return '模型正在推理（reasoning_content）：' + size + chars + '（' + elapsed + '）';
      }
      return '正在接收响应：' + size + chars + '（' + elapsed + '）';
    };

    var renderConfig = function () {
      return e(View, null,
        e(Section, { title: 'AI 接口配置' },
          e(Text, { style: styles.hint }, '兼容 OpenAI 的 /chat/completions。先选服务商预设，也可以手动改地址和模型。'),
          e(Text, { style: styles.label }, '服务商预设'),
          e(View, { style: styles.chipRow },
            PRESETS.map(function (preset) {
              var active = normalizeBase(baseUrl) === preset.baseUrl;
              return e(TouchableOpacity, {
                key: preset.key,
                style: [styles.chip, active ? styles.chipActive : null],
                onPress: function () { applyPreset(preset); },
              }, e(Text, { style: active ? styles.chipTextActive : styles.chipText }, preset.label));
            })
          ),
          e(Text, { style: styles.label }, 'API 地址'),
          e(TextInput, {
            style: styles.input,
            value: baseUrl,
            onChangeText: function (v) { setBaseUrl(v); setStatus(''); },
            placeholder: 'https://api.deepseek.com',
            autoCapitalize: 'none',
            autoCorrect: false,
          }),
          e(Text, { style: styles.urlHint }, baseUrlHint(baseUrl)),
          e(Text, { style: styles.label }, '模型名'),
          e(TextInput, {
            style: styles.input,
            value: model,
            onChangeText: function (v) { setModel(v); setStatus(''); },
            placeholder: 'deepseek-chat',
            autoCapitalize: 'none',
            autoCorrect: false,
          }),
          e(View, { style: styles.row },
            e(ActionButton, {
              title: fetchingModels ? '拉取中…' : '拉取模型列表',
              onPress: function () { fetchModelsNow(true).catch(function () {}); },
              loading: fetchingModels,
              style: styles.flex1,
            }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '清空模型', onPress: function () { setModels([]); setModelsInfo(''); }, style: styles.flex1 })
          ),
          modelsInfo ? e(Text, { style: styles.modelsInfo }, modelsInfo) : null,
          models.length
            ? e(View, { style: styles.chipRow },
                models.slice(0, 60).map(function (id) {
                  var active = id === model;
                  return e(TouchableOpacity, {
                    key: id,
                    style: [styles.chip, active ? styles.chipActive : null],
                    onPress: function () { setModel(id); setStatus('已选择模型 ' + id); },
                  }, e(Text, { style: active ? styles.chipTextActive : styles.chipText }, id));
                })
              )
            : null,
          e(Text, { style: styles.label }, 'API Key'),
          editingKey
            ? e(View, null,
                e(TextInput, {
                  style: styles.input,
                  value: keyDraft,
                  onChangeText: setKeyDraft,
                  placeholder: 'sk-...',
                  autoCapitalize: 'none',
                  autoCorrect: false,
                  secureTextEntry: true,
                }),
                e(View, { style: styles.row },
                  e(ActionButton, { title: '保存 Key', primary: true, onPress: saveKey, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  e(ActionButton, { title: '取消', onPress: function () { setEditingKey(false); setKeyDraft(''); }, style: styles.flex1 })
                )
              )
            : e(View, null,
                e(Text, { style: styles.keyText }, apiKey ? '已保存：' + maskKey(apiKey) : '尚未配置'),
                e(View, { style: styles.row },
                  e(ActionButton, { title: apiKey ? '更换 Key' : '填写 Key', primary: true, onPress: function () { setEditingKey(true); }, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  apiKey ? e(ActionButton, { title: '清除', danger: true, onPress: function () { api.storage.remove(KEYS.apiKey).then(function () { setApiKey(''); setStatus('已清除 API Key'); }); }, style: styles.flex1 }) : null
                )
              ),
          e(Text, { style: styles.note }, 'Key 只保存在本机插件私有存储里，界面始终脱敏显示，不会回传或写入日志。'),
          e(Text, { style: styles.label }, '超时（秒）'),
          e(TextInput, {
            style: styles.input,
            value: String(timeoutSec),
            onChangeText: setTimeoutSec,
            placeholder: String(DEFAULT_TIMEOUT_SEC),
            keyboardType: 'numeric',
          }),
          e(Text, { style: styles.note }, '按空闲超时计算：连接或等待响应超过该时间算超时；收到流式数据后会重新计时，默认 ' + DEFAULT_TIMEOUT_SEC + ' 秒。'),
          e(Text, { style: styles.label }, '最大输出 tokens'),
          e(TextInput, {
            style: styles.input,
            value: String(maxTokens),
            onChangeText: setMaxTokens,
            placeholder: String(DEFAULT_MAX_TOKENS),
            keyboardType: 'numeric',
          }),
          e(Text, { style: styles.note }, '填 0 表示不主动限制；长代码被截断时可调大，例如 8192 或 16384。'),
          e(TouchableOpacity, {
            style: styles.toggleRow,
            onPress: function () { setStreamOn(!streamOn); },
          },
            e(Text, { style: styles.toggleLabel }, '流式接收'),
            e(Text, { style: streamOn ? styles.toggleOn : styles.toggleOff }, streamOn ? '已开启（边收边显示）' : '已关闭（等完整响应）')
          ),
          e(View, { style: styles.row },
            e(ActionButton, { title: '保存配置', primary: true, onPress: saveConfig, style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '测试连接', onPress: testConnection, loading: busy && working === '正在测试连接', style: styles.flex1 })
          )
        ),
        status ? e(Text, { style: styles.statusText }, status) : null,
        error ? e(View, { style: styles.errorBox }, e(Text, { style: styles.errorTitle }, '出错了'), e(Text, { style: styles.errorLine }, error)) : null,
        testInfo ? e(Section, { title: '连接测试结果' }, e(Text, { style: styles.testInfo }, testInfo)) : null,
        e(Section, { title: '说明' },
          e(Text, { style: styles.hint }, '· 生成结果会先做宿主校验：manifest 必填字段、id 格式、SemVer、入口路径、权限白名单、入口语法扫描。'),
          e(Text, { style: styles.hint }, '· 安装复用现有安装管线，不能绕过校验；装完可在已安装列表里看到，也可直接打开。'),
          e(Text, { style: styles.hint }, '· AI 生成的代码属于不可信内容，安装前请确认权限清单；首次运行宿主仍会再次确认。')
        )
      );
    };

    var kindLabel = function (kind) {
      if (kind === 'generate') return '生成';
      if (kind === 'edit') return '修改';
      if (kind === 'fix') return '修正';
      if (kind === 'rollback') return '回退';
      if (kind === 'history') return '历史';
      return kind || '生成';
    };

    var renderRounds = function () {
      if (!rounds.length) return null;
      var previous = activeIndex > 0 ? rounds[activeIndex - 1] : null;
      var diff = previous && showDiff
        ? diffStat(
            previous.files && previous.files['index.js'],
            current && current.files && current.files['index.js']
          )
        : null;
      return e(Section, { title: '轮次记录（' + rounds.length + '）' },
        e(Text, { style: styles.hint }, '每轮输出都会重新校验；改码基于当前查看的版本，版本号自动 patch +1，可回退到任一通过版本。'),
        rounds.map(function (round, index) {
          var active = index === activeIndex;
          return e(View, { key: String(round.createdAt) + '-' + index, style: [styles.roundItem, active ? styles.roundItemActive : null] },
            e(View, { style: styles.rowBetween },
              e(Text, { style: styles.roundTitle }, '第 ' + round.round + ' 轮 · ' + kindLabel(round.kind) + ' · v' + versionOf(round.manifest)),
              e(Text, { style: round.ok ? styles.badgeOk : styles.badgeBad }, round.ok ? '通过' : '未通过')
            ),
            round.request ? e(Text, { style: styles.roundReq }, round.request) : null,
            e(Text, { style: styles.historyTime }, nowText(round.createdAt) + (round.elapsedMs ? ' · ' + fmtDuration(round.elapsedMs) : '')),
            active
              ? null
              : e(View, { style: styles.row },
                  e(ActionButton, { title: '查看', onPress: function () { viewRound(index); }, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  round.ok
                    ? e(ActionButton, { title: '回退到此版', primary: true, onPress: function () { rollbackTo(index); }, style: styles.flex1 })
                    : null
                )
          );
        }),
        previous
          ? e(View, null,
              e(View, { style: styles.row },
                e(ActionButton, { title: showDiff ? '收起对比' : '对比上一版', onPress: function () { setShowDiff(!showDiff); } })
              ),
              diff
                ? e(View, { style: styles.diffBox },
                    e(Text, { style: styles.diffTitle }, '与第 ' + previous.round + ' 轮相比：+' + diff.added + ' 行 / -' + diff.removed + ' 行'),
                    diff.sample.map(function (line, idx) {
                      return e(Text, { key: idx, style: line.charAt(0) === '+' ? styles.diffAdd : styles.diffDel }, line);
                    })
                  )
                : null
            )
          : null
      );
    };

    var renderResult = function () {
      if (!current) return null;
      var mf = current.manifest || {};
      var perms = Array.isArray(mf.permissions) ? mf.permissions : [];
      var fileContent = current.files[viewFile];
      var text = typeof fileContent === 'string' ? fileContent : '[二进制文件]';
      return e(View, null,
        e(Section, { title: '第 3 步 · 结果与迭代' },
          e(View, { style: styles.rowBetween },
            e(Text, { style: styles.resultName }, (mf.name || mf.id || '未命名插件') + ' v' + versionOf(mf)),
            e(Text, { style: current.ok ? styles.badgeOk : styles.badgeBad }, current.ok ? '校验通过' : '校验未通过')
          ),
          e(Text, { style: styles.hint }, '第 ' + current.round + ' 轮 · ' + kindLabel(current.kind) +
            '\nid：' + (mf.id || '-') + '\n入口：' + (mf.entry || '-') + '\n描述：' + (mf.description || '无')),
          e(Text, { style: styles.label }, '将要申请的权限（' + perms.length + '）'),
          perms.length === 0
            ? e(Text, { style: styles.hint }, '无受限权限')
            : perms.map(function (key) {
                return e(View, { key: key, style: styles.permRow },
                  e(Text, { style: styles.permLabel }, permissionLabel(key)),
                  e(Text, { style: styles.permDesc }, permissionDesc(key))
                );
              }),
          current.warnings && current.warnings.length
            ? e(Text, { style: styles.warnText }, '提示：' + current.warnings.join('；'))
            : null,
          !current.ok
            ? e(View, { style: styles.errorBox },
                e(Text, { style: styles.errorTitle }, '未通过校验的问题（第 ' + current.round + ' 轮）'),
                (current.errors || []).map(function (item, idx) {
                  return e(Text, { key: idx, style: styles.errorLine }, '· ' + item.field + '：' + item.message);
                }),
                e(View, { style: styles.row },
                  e(ActionButton, { title: '让 AI 按错误修正', primary: true, onPress: repair, loading: busy && working === 'AI 正在按校验问题修正', style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  plan ? e(ActionButton, { title: '返回方案', onPress: function () { setStage('plan'); }, style: styles.flex1 }) : null
                )
              )
            : null,
          e(View, { style: styles.fileTabs },
            ['manifest.json', 'index.js'].filter(function (name) { return current.files[name]; }).map(function (name) {
              return e(TouchableOpacity, {
                key: name,
                style: [styles.fileTab, viewFile === name ? styles.fileTabActive : null],
                onPress: function () { setViewFile(name); },
              }, e(Text, { style: viewFile === name ? styles.fileTabTextActive : styles.fileTabText }, name));
            })
          ),
          e(ScrollView, { horizontal: true, style: styles.codeBox },
            e(Text, { style: styles.code }, text)
          )
        ),
        e(Section, { title: '继续修改（自然语言）' },
          e(Text, { style: styles.hint }, 'AI 会拿到当前版本完整代码 + 你的修改要求，输出完整新版本；每轮都会重新校验，失败可按错误修正。'),
          e(TextInput, {
            style: [styles.input, styles.promptInput],
            value: changeRequest,
            onChangeText: function (v) { setChangeRequest(v); setStatus(''); },
            placeholder: '例如：把按钮改大一些；再加一个历史记录列表',
            multiline: true,
            textAlignVertical: 'top',
          }),
          e(ActionButton, {
            title: '提交修改',
            primary: true,
            onPress: editCode,
            loading: busy && working.indexOf('AI 正在修改插件') === 0,
          }),
          e(Text, { style: styles.note }, '每次修改都会生成新版本，安装后可直接打开验证；不满意可在轮次记录里回退。'),
          e(ActionButton, { title: '新建插件（清空当前会话）', onPress: startNew })
        ),
        renderRounds(),
        e(Section, { title: '安装' },
          e(View, { style: styles.row },
            e(ActionButton, { title: '安装此版本并打开', primary: true, disabled: !current.ok, onPress: startInstall, style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '导出 zip', onPress: doExport, style: styles.flex1 })
          ),
          conflict
            ? e(View, { style: styles.conflictBox },
                e(Text, { style: styles.confirmTitle }, '检测到插件冲突'),
                conflict.sameId
                  ? e(Text, { style: styles.errorLine }, '同 id 已安装：' + conflict.sameId.name + ' v' + versionOf(conflict.sameId) + '（' + conflict.sameId.id + '）')
                  : null,
                conflict.sameName
                  ? e(Text, { style: styles.errorLine }, '同名已安装：' + conflict.sameName.name + ' v' + versionOf(conflict.sameName) + '（' + conflict.sameName.id + '）')
                  : null,
                e(Text, { style: styles.hint }, '当前将安装：' + (conflict.currentName || mf.name) + ' v' + (conflict.currentVersion || versionOf(mf)) + '（' + (conflict.currentId || mf.id) + '）'),
                e(Text, { style: styles.note }, '覆盖/升版本：同 id 覆盖代码，插件私有数据（storage/files）按 id 保留。改名安装：生成新 id 与新名称，作为独立插件安装，旧插件和它的数据原样保留，不自动迁移。'),
                conflict.sameId
                  ? e(ActionButton, { title: '覆盖安装（同 id，保留数据）', primary: true, onPress: function () { installCurrent('overwrite'); }, loading: busy && working === '正在安装插件' })
                  : null,
                conflict.sameId
                  ? e(ActionButton, { title: '升版本安装（同 id，保留数据）', onPress: function () { installCurrent('bump'); }, loading: busy && working === '正在安装插件' })
                  : null,
                e(ActionButton, { title: '改名成新 id 安装（数据不迁移）', onPress: function () { installCurrent('rename'); }, loading: busy && working === '正在安装插件' }),
                e(ActionButton, { title: '取消', onPress: function () { setConflict(null); setStatus('已取消安装'); } })
              )
            : null,
          confirming
            ? e(View, { style: styles.confirmBox },
                e(Text, { style: styles.confirmTitle }, '确认安装「' + (mf.name || mf.id) + '」v' + versionOf(mf) + '？'),
                e(Text, { style: styles.hint }, '这个插件将申请以下权限：'),
                perms.length === 0
                  ? e(Text, { style: styles.hint }, '无受限权限')
                  : perms.map(function (key) {
                      return e(Text, { key: key, style: styles.confirmPerm }, '· ' + permissionLabel(key) + '：' + permissionDesc(key));
                    }),
                e(Text, { style: styles.warnText }, 'AI 生成的代码属于不可信内容。安装会复用宿主校验与权限管线，首次运行仍会要求你再次确认权限。'),
                e(View, { style: styles.row },
                  e(ActionButton, { title: '取消', onPress: function () { setConfirming(false); }, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  e(ActionButton, { title: '确认安装并打开', primary: true, onPress: function () { installCurrent('overwrite'); }, loading: busy && working === '正在安装插件', style: styles.flex1 })
                )
              )
            : null
        )
      );
    };

    var renderNeed = function () {
      return e(Section, { title: '第 1 步 · 描述需求' },
        e(Text, { style: styles.hint }, '例如：一个番茄钟，可设置 25 分钟专注与 5 分钟休息，开始后显示倒计时，结束时震动提醒。'),
        e(Text, { style: styles.label }, '快速示例'),
        e(View, { style: styles.chipRow },
          EXAMPLES.map(function (item) {
            return e(TouchableOpacity, {
              key: item.label,
              style: styles.chip,
              onPress: function () { setPrompt(item.text); setStatus('已填入示例需求，下一步生成方案'); setError(''); },
            }, e(Text, { style: styles.chipText }, item.label));
          })
        ),
        e(TextInput, {
          style: [styles.input, styles.promptInput],
          value: prompt,
          onChangeText: function (v) { setPrompt(v); setStatus(''); },
          placeholder: '用一句话说清功能、交互与需要保存的数据…',
          multiline: true,
          textAlignVertical: 'top',
        }),
        e(View, { style: styles.row },
          e(ActionButton, { title: '生成方案', primary: true, onPress: makePlan, loading: busy && working === 'AI 正在设计插件方案', style: styles.flex1 }),
          e(View, { style: styles.gap }),
          e(ActionButton, {
            title: '清空',
            onPress: startNew,
            style: styles.flex1,
          })
        ),
        e(Text, { style: styles.note }, '先生成方案，确认后才写代码。方案包含 id/版本、权限及理由、界面草图、交互、存储与标准开发步骤。')
      );
    };

    var renderPlanEditor = function () {
      if (!planEdit) return null;
      var editField = function (label, key, placeholder, extraStyle) {
        return e(View, null,
          e(Text, { style: styles.label }, label),
          e(TextInput, {
            style: [styles.input, extraStyle || null],
            value: String(planEdit[key] || ''),
            onChangeText: function (v) { updatePlanEdit({ [key]: v }); },
            placeholder: placeholder || '',
            multiline: !!extraStyle,
            textAlignVertical: extraStyle ? 'top' : 'center',
            autoCapitalize: 'none',
            autoCorrect: false,
          })
        );
      };
      return e(Section, { title: '手动编辑方案要点' },
        e(Text, { style: styles.hint }, '改完点「保存要点」，再回到方案页确认生成。界面草图会按下面内容重新画。'),
        editField('插件名称', 'name', '例如 天气查看'),
        editField('插件 id', 'id', 'com.example.weather'),
        editField('版本', 'version', '1.0.0'),
        editField('一句话描述', 'description', '显示当前城市天气'),
        e(Text, { style: styles.label }, '权限（点选增删）'),
        e(View, { style: styles.chipRow },
          PERMISSION_KEYS.map(function (key) {
            var active = toArray(planEdit.permissions).indexOf(key) >= 0;
            return e(TouchableOpacity, {
              key: key,
              style: [styles.chip, active ? styles.chipActive : null],
              onPress: function () { togglePlanPermission(key); },
            }, e(Text, { style: active ? styles.chipTextActive : styles.chipText }, key));
          })
        ),
        editField('权限理由（每行「权限名：理由」）', 'reasonText', 'storage：保存待办列表', styles.editArea),
        editField('界面草图（## 屏幕名 另起一屏，每行「类型|文字」）', 'screenText', '## 主界面\n标题|天气\n输入框|输入城市\n按钮|刷新\n文字|25°C 晴', styles.editArea),
        editField('主要交互（每行一条）', 'interactionText', '', styles.editAreaSmall),
        editField('数据存储（每行一条）', 'storageText', '', styles.editAreaSmall),
        editField('开发步骤（每行一步）', 'stepsText', '', styles.editArea),
        e(View, { style: styles.row },
          e(ActionButton, { title: '保存要点', primary: true, onPress: savePlanEdit, style: styles.flex1 }),
          e(View, { style: styles.gap }),
          e(ActionButton, { title: '取消编辑', onPress: function () { setPlanEdit(null); }, style: styles.flex1 })
        )
      );
    };

    var renderPlan = function () {
      if (!plan) return null;
      var mf = plan.manifest || {};
      var perms = toArray(mf.permissions);
      var tokens = normalizeTokens(plan.designTokens);
      var swatch = function (color) {
        return e(View, { style: { width: 16, height: 16, borderRadius: 5, backgroundColor: color, marginRight: 6 } });
      };
      var reasonOf = function (key) { return plan.permissionReasons[key] || ''; };
      return e(View, null,
        e(Section, { title: '第 2 步 · 方案（确认前预览）' },
          e(View, { style: styles.rowBetween },
            e(Text, { style: styles.resultName }, (mf.name || '未命名插件') + ' v' + versionOf(mf)),
            e(Text, { style: styles.badgePlan }, '待确认')
          ),
          e(Text, { style: styles.hint }, 'id：' + (mf.id || '-') + '\n描述：' + (mf.description || '无')),
          e(Text, { style: styles.label }, '界面预览图（按方案渲染的线框图）'),
          e(View, { style: { flexDirection: 'row', alignItems: 'center', marginTop: 6 } },
            swatch(tokens.primary),
            swatch(tokens.bg),
            swatch(tokens.surface),
            swatch(tokens.text),
            swatch(tokens.success),
            swatch(tokens.danger),
            e(Text, { style: styles.tokenText }, tokens.mode === 'dark' ? '深色' : '浅色')
          ),
          e(Text, { style: styles.note }, '主色 ' + tokens.primary + ' · 圆角 ' + tokens.radius + ' · 间距 ' + tokens.spacing + ' · 文字 ' + tokens.text + ' / ' + tokens.muted),
          e(ScrollView, { horizontal: true, style: styles.previewScroll },
            toArray(plan.screens).map(function (screen, index) {
              return e(PhonePreview, { key: index, screen: screen, tokens: tokens });
            })
          ),
          e(Text, { style: styles.note }, '以上是根据方案实时渲染的界面草图，不是文字描述；确认后 AI 按它生成真实代码。'),
          e(Text, { style: styles.label }, '要申请的权限（' + perms.length + '）'),
          perms.length === 0
            ? e(Text, { style: styles.hint }, '无受限权限')
            : perms.map(function (key) {
                return e(View, { key: key, style: styles.permRow },
                  e(Text, { style: styles.permLabel }, permissionLabel(key)),
                  e(Text, { style: styles.permDesc }, reasonOf(key))
                );
              }),
          plan.interactions.length
            ? e(View, null,
                e(Text, { style: styles.label }, '主要交互'),
                plan.interactions.map(function (text, idx) {
                  return e(Text, { key: idx, style: styles.planLine }, '· ' + text);
                })
              )
            : null,
          plan.storage.length
            ? e(View, null,
                e(Text, { style: styles.label }, '数据存储'),
                plan.storage.map(function (text, idx) {
                  return e(Text, { key: idx, style: styles.planLine }, '· ' + text);
                })
              )
            : null,
          plan.steps.length
            ? e(View, null,
                e(Text, { style: styles.label }, '标准开发步骤'),
                plan.steps.map(function (text, idx) {
                  return e(Text, { key: idx, style: styles.planLine }, (idx + 1) + '. ' + text);
                })
              )
            : null
        ),
        renderPlanEditor(),
        e(Section, { title: '确认与调整' },
          e(ActionButton, {
            title: '确认并生成代码',
            primary: true,
            onPress: generateFromPlan,
            loading: busy && working === 'AI 正在按方案生成插件',
          }),
          e(Text, { style: styles.label }, '让 AI 按补充要求重写方案'),
          e(TextInput, {
            style: [styles.input, styles.editAreaSmall],
            value: planFeedback,
            onChangeText: function (v) { setPlanFeedback(v); },
            placeholder: '例如：主界面加一个历史记录入口，权限只要 storage',
            multiline: true,
            textAlignVertical: 'top',
          }),
          e(View, { style: styles.row },
            e(ActionButton, { title: '让 AI 重写方案', onPress: rewritePlan, loading: busy && working === 'AI 正在重写方案', style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, {
              title: planEdit ? '取消手动编辑' : '手动编辑要点',
              onPress: function () { if (planEdit) setPlanEdit(null); else openPlanEditor(); },
              style: styles.flex1,
            })
          ),
          e(View, { style: styles.row },
            e(ActionButton, {
              title: '返回修改需求',
              onPress: function () { setStage('need'); setError(''); },
              style: styles.flex1,
            }),
            e(View, { style: styles.gap }),
            e(ActionButton, {
              title: '重新生成方案',
              onPress: makePlan,
              loading: busy && working === 'AI 正在设计插件方案',
              style: styles.flex1,
            })
          )
        )
      );
    };

    var renderGenerate = function () {
      return e(View, null,
        stage === 'need' ? renderNeed() : null,
        stage === 'plan' ? renderPlan() : null,
        stage === 'result' ? renderResult() : null,
        busy
          ? e(View, { style: styles.progressBox },
              e(View, { style: styles.progressHead },
                e(ActivityIndicator, { size: 'small' }),
                e(Text, { style: styles.progressLabel }, progressLabel())
              ),
              progress && progress.preview
                ? e(ScrollView, { style: styles.progressPreview },
                    e(Text, { style: styles.progressText }, progress.preview.slice(-500))
                  )
                : null
            )
          : null,
        status ? e(Text, { style: styles.statusText }, status) : null,
        error
          ? e(View, { style: styles.errorBox },
              e(Text, { style: styles.errorTitle }, '出错了'),
              e(Text, { style: styles.errorLine }, error),
              formatRetry
                ? e(View, { style: styles.row },
                    e(ActionButton, {
                      title: '按 Skill 纠偏重试',
                      primary: true,
                      onPress: retryFormat,
                      loading: busy && (working === 'AI 正在按 Skill 纠偏' || working === 'AI 正在重写方案'),
                      style: styles.flex1,
                    })
                  )
                : null
            )
          : null
      );
    };

    var renderSessions = function () {
      return e(View, null,
        status ? e(Text, { style: styles.statusText }, status) : null,
        error ? e(View, { style: styles.errorBox }, e(Text, { style: styles.errorTitle }, '出错了'), e(Text, { style: styles.errorLine }, error)) : null,
        e(Section, { title: '会话库（' + library.length + '）' },
          e(Text, { style: styles.hint }, '会话保存在插件私有存储，关闭插件、重启 App、覆盖升级都还在；卸载插件或换设备会丢失，需要用导出/剪贴板找回。'),
          e(View, { style: styles.row },
            e(ActionButton, { title: '新建会话', primary: true, onPress: startNew, style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '导出全部', onPress: doExportSessions, loading: busy && working === '正在导出会话', style: styles.flex1 })
          ),
          e(View, { style: styles.row },
            e(ActionButton, { title: '复制到剪贴板', onPress: copySessions, style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '读取剪贴板', onPress: pasteFromClipboard, style: styles.flex1 })
          ),
          e(TextInput, {
            style: [styles.input, styles.importArea],
            value: importText,
            onChangeText: setImportText,
            placeholder: '把导出的会话 JSON 粘贴到这里，再点「导入会话」',
            multiline: true,
            textAlignVertical: 'top',
            autoCapitalize: 'none',
            autoCorrect: false,
          }),
          e(ActionButton, { title: '导入会话', onPress: importSessions }),
          e(Text, { style: styles.note }, '能保住：会话名称、方案、全部轮次与代码；不能保住：导出之后的新修改需要重新导出，改名成新 id 的插件数据不随会话迁移。导出内容不含 API Key。')
        ),
        library.length === 0
          ? e(Section, { title: '还没有会话' },
              e(Text, { style: styles.hint }, '回到「生成」描述需求，生成方案并确认后会自动建立一个会话。')
            )
          : library.map(function (item) {
              var lastRound = item.rounds[item.rounds.length - 1] || {};
              var mf = (lastRound && lastRound.manifest) || (item.plan && item.plan.manifest) || {};
              var active = session && session.id === item.id;
              return e(View, { key: item.id, style: [styles.historyItem, active ? styles.roundItemActive : null] },
                e(View, { style: styles.rowBetween },
                  e(Text, { style: styles.historyName }, item.name),
                  e(Text, { style: lastRound.ok ? styles.badgeOk : styles.badgeBad }, lastRound.ok ? '可安装' : '未通过')
                ),
                renamingId === item.id
                  ? e(View, null,
                      e(TextInput, {
                        style: styles.input,
                        value: renameDraft,
                        onChangeText: setRenameDraft,
                        placeholder: '会话名称',
                      }),
                      e(View, { style: styles.row },
                        e(ActionButton, { title: '保存名称', primary: true, onPress: saveRenameSession, style: styles.flex1 }),
                        e(View, { style: styles.gap }),
                        e(ActionButton, { title: '取消', onPress: function () { setRenamingId(''); }, style: styles.flex1 })
                      )
                    )
                  : null,
                e(Text, { style: styles.historyPrompt }, 'v' + versionOf(mf) + ' · ' + item.rounds.length + ' 轮 · ' + (mf.name || mf.id || '未命名插件')),
                e(Text, { style: styles.historyPrompt }, (item.prompt || '').slice(0, 80)),
                e(Text, { style: styles.historyTime }, nowText(item.updatedAt) + (active ? ' · 当前会话' : '')),
                e(View, { style: styles.row },
                  e(ActionButton, { title: '继续', primary: true, onPress: function () { openSession(item); }, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  e(ActionButton, { title: '重命名', onPress: function () { beginRenameSession(item); }, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  e(ActionButton, { title: '删除', danger: true, onPress: function () { deleteSession(item); }, style: styles.flex1 })
                )
              );
            })
      );
    };

    var renderSkill = function () {
      return e(View, null,
        e(Section, { title: '界面设计规范（UI Skill）' },
          e(Text, { style: styles.hint }, '内置界面设计规范，方案阶段与代码生成都会自动作为 system 提示发送，约束配色、字号、间距、圆角、组件状态、布局与交互。可在此查看、编辑或恢复默认。'),
          e(TextInput, {
            style: [styles.input, styles.skillInput],
            value: uiSpec,
            onChangeText: setUiSpec,
            multiline: true,
            textAlignVertical: 'top',
            autoCapitalize: 'none',
            autoCorrect: false,
          }),
          e(View, { style: styles.row },
            e(ActionButton, { title: '保存 UI 规范', primary: true, onPress: saveUiSpec, style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '恢复默认', onPress: restoreUiSpec, style: styles.flex1 })
          ),
          e(Text, { style: styles.note }, '当前 ' + uiSpec.length + ' 字符。与下方标准 Skill 一起发送；自定义技能不能覆盖这里的硬性约束。')
        ),
        e(Section, { title: '标准开发流程 Skill（系统提示）' },
          e(Text, { style: styles.hint }, '生成方案、按方案生成代码、根据反馈改码时都会自动作为 system 提示发送。这里固化插件规范与标准开发流程：manifest 字段、id 与 SemVer、entry、权限白名单、组件与 api 能力、语法限制、体积上限和输出格式。'),
          e(TextInput, {
            style: [styles.input, styles.skillInput],
            value: skill,
            onChangeText: setSkill,
            multiline: true,
            textAlignVertical: 'top',
            autoCapitalize: 'none',
            autoCorrect: false,
          }),
          e(View, { style: styles.row },
            e(ActionButton, { title: '保存 Skill', primary: true, onPress: saveSkill, style: styles.flex1 }),
            e(View, { style: styles.gap }),
            e(ActionButton, { title: '恢复默认', onPress: restoreSkill, style: styles.flex1 })
          ),
          e(Text, { style: styles.note }, '当前 ' + skill.length + ' 字符。Skill 会随生成请求发给你配置的 AI 服务商，不要在 Skill 里写 API Key。')
        ),
        e(Section, { title: '自定义技能（' + customSkills.length + '）' },
          e(Text, { style: styles.hint }, '可自行追加约束或偏好，例如「界面统一用蓝色主题」。会按顺序拼接在标准 Skill 之后，生成与改码都会带上。'),
          customSkills.length === 0
            ? e(Text, { style: styles.emptyText }, '还没有自定义技能')
            : customSkills.map(function (item) {
                return e(View, { key: item.id, style: styles.historyItem },
                  e(Text, { style: styles.historyName }, item.name),
                  e(Text, { style: styles.historyPrompt }, truncate(item.content, 160)),
                  e(View, { style: styles.row },
                    e(ActionButton, { title: '编辑', primary: true, onPress: function () { startSkillEdit(item); }, style: styles.flex1 }),
                    e(View, { style: styles.gap }),
                    e(ActionButton, { title: '删除', danger: true, onPress: function () { removeSkillEntry(item.id); }, style: styles.flex1 })
                  )
                );
              }),
          editingSkill
            ? e(View, null,
                e(Text, { style: styles.label }, '技能名称'),
                e(TextInput, {
                  style: styles.input,
                  value: editingSkill.name,
                  onChangeText: function (v) { updateSkillEdit({ name: v }); },
                  placeholder: '例如：界面风格',
                }),
                e(Text, { style: styles.label }, '技能内容'),
                e(TextInput, {
                  style: [styles.input, styles.editArea],
                  value: editingSkill.content,
                  onChangeText: function (v) { updateSkillEdit({ content: v }); },
                  placeholder: '写给模型的额外约束，例如：所有按钮使用圆角与蓝色主题',
                  multiline: true,
                  textAlignVertical: 'top',
                  autoCapitalize: 'none',
                  autoCorrect: false,
                }),
                e(View, { style: styles.row },
                  e(ActionButton, { title: '保存技能', primary: true, onPress: saveSkillEntry, style: styles.flex1 }),
                  e(View, { style: styles.gap }),
                  e(ActionButton, { title: '取消', onPress: function () { setEditingSkill(null); }, style: styles.flex1 })
                )
              )
            : e(ActionButton, { title: '新增自定义技能', onPress: function () { startSkillEdit(null); } })
        )
      );
    };

    return e(View, { style: styles.root },
      e(View, { style: styles.tabBar },
        [
          { key: 'generate', label: '生成' },
          { key: 'config', label: '配置' },
          { key: 'skill', label: '技能' },
          { key: 'history', label: '会话' },
        ].map(function (item) {
          return e(TouchableOpacity, {
            key: item.key,
            style: [styles.tab, tab === item.key ? styles.tabActive : null],
            onPress: function () { setTab(item.key); },
          }, e(Text, { style: tab === item.key ? styles.tabTextActive : styles.tabText }, item.label));
        })
      ),
      e(ScrollView, {
        style: styles.body,
        contentContainerStyle: styles.bodyContent,
        keyboardShouldPersistTaps: 'handled',
      },
        tab === 'generate' ? renderGenerate() : null,
        tab === 'config' ? renderConfig() : null,
        tab === 'skill' ? renderSkill() : null,
        tab === 'history' ? renderSessions() : null
      )
    );
  };
};

var styles = RN.StyleSheet.create({
  root: { flex: 1, backgroundColor: '#f4f6f9' },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderBottomWidth: RN.StyleSheet.hairlineWidth,
    borderBottomColor: '#e2e6eb',
  },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center' },
  tabActive: { borderBottomWidth: 2, borderBottomColor: '#4a90d9' },
  tabText: { fontSize: 14, color: '#777' },
  tabTextActive: { fontSize: 14, color: '#2f6fb3', fontWeight: '600' },
  body: { flex: 1 },
  bodyContent: { padding: 12, paddingBottom: 32 },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 14,
    marginBottom: 12,
  },
  cardTitle: { fontSize: 16, fontWeight: '600', color: '#222', marginBottom: 10 },
  label: { fontSize: 13, color: '#555', marginTop: 10, marginBottom: 6 },
  hint: { fontSize: 12, color: '#888', lineHeight: 19, marginBottom: 6 },
  urlHint: { fontSize: 12, color: '#2f6fb3', lineHeight: 18, marginTop: 6, marginBottom: 4 },
  note: { fontSize: 11, color: '#999', lineHeight: 17, marginTop: 10 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 4 },
  chip: {
    borderWidth: 1,
    borderColor: '#d9e2ec',
    backgroundColor: '#f7fafd',
    borderRadius: 14,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginRight: 8,
    marginBottom: 8,
  },
  chipActive: { backgroundColor: '#4a90d9', borderColor: '#4a90d9' },
  chipText: { fontSize: 12, color: '#3b6fa8' },
  chipTextActive: { fontSize: 12, color: '#fff' },
  modelsInfo: {
    fontSize: 12,
    color: '#2f6fb3',
    backgroundColor: '#eef5fd',
    borderRadius: 6,
    padding: 8,
    lineHeight: 18,
    marginTop: 8,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 12,
    paddingVertical: 10,
    borderTopWidth: RN.StyleSheet.hairlineWidth,
    borderTopColor: '#eceff3',
  },
  toggleLabel: { fontSize: 13, color: '#333' },
  toggleOn: { fontSize: 12, color: '#237804' },
  toggleOff: { fontSize: 12, color: '#888' },
  testInfo: { fontSize: 12, color: '#333', lineHeight: 20 },
  skillInput: { height: 260, fontSize: 12, lineHeight: 18 },
  input: {
    borderWidth: 1,
    borderColor: '#dfe3e8',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 14,
    color: '#222',
    backgroundColor: '#fbfcfd',
  },
  promptInput: { minHeight: 96, textAlignVertical: 'top' },
  keyText: {
    fontSize: 14,
    color: '#333',
    backgroundColor: '#f7f9fb',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 10,
    marginBottom: 8,
  },
  row: { flexDirection: 'row', alignItems: 'center', marginTop: 10, flexWrap: 'wrap' },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  gap: { width: 10 },
  flex1: { flex: 1, minWidth: 120 },
  btn: {
    minHeight: 42,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#d9dee5',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
    marginTop: 8,
  },
  btnPrimary: { backgroundColor: '#4a90d9', borderColor: '#4a90d9' },
  btnDanger: { backgroundColor: '#e05b59', borderColor: '#e05b59' },
  btnDisabled: { opacity: 0.55 },
  btnText: { fontSize: 14, color: '#3b6fa8', fontWeight: '600' },
  btnTextLight: { color: '#fff' },
  statusText: {
    fontSize: 13,
    color: '#2f6fb3',
    backgroundColor: '#eef5fd',
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
    lineHeight: 19,
  },
  errorBox: {
    backgroundColor: '#fff1f0',
    borderWidth: 1,
    borderColor: '#ffccc7',
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
  },
  errorTitle: { fontSize: 13, fontWeight: '600', color: '#cf1322', marginBottom: 4 },
  errorLine: { fontSize: 12, color: '#a8071a', lineHeight: 18 },
  warnText: { fontSize: 12, color: '#ad6800', lineHeight: 18, marginTop: 8 },
  resultName: { fontSize: 15, fontWeight: '600', color: '#222', flexShrink: 1 },
  badgeOk: {
    fontSize: 11,
    color: '#237804',
    backgroundColor: '#f6ffed',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginLeft: 8,
    overflow: 'hidden',
  },
  badgeBad: {
    fontSize: 11,
    color: '#cf1322',
    backgroundColor: '#fff1f0',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginLeft: 8,
    overflow: 'hidden',
  },
  permRow: { marginTop: 8, borderLeftWidth: 3, borderLeftColor: '#b7d6f5', paddingLeft: 8 },
  permLabel: { fontSize: 13, color: '#333', fontWeight: '600' },
  permDesc: { fontSize: 11, color: '#888', lineHeight: 17, marginTop: 2 },
  confirmBox: {
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#ffe58f',
    backgroundColor: '#fffbe6',
    borderRadius: 8,
    padding: 12,
  },
  confirmTitle: { fontSize: 14, fontWeight: '600', color: '#874d00', marginBottom: 8 },
  confirmPerm: { fontSize: 12, color: '#874d00', lineHeight: 18 },
  fileTabs: { flexDirection: 'row', marginTop: 12 },
  fileTab: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 6,
    backgroundColor: '#f0f2f5',
    marginRight: 8,
  },
  fileTabActive: { backgroundColor: '#4a90d9' },
  fileTabText: { fontSize: 12, color: '#555' },
  fileTabTextActive: { fontSize: 12, color: '#fff' },
  codeBox: {
    marginTop: 10,
    maxHeight: 260,
    backgroundColor: '#1f2430',
    borderRadius: 8,
  },
  code: {
    padding: 12,
    color: '#d7e3f4',
    fontSize: 11,
    lineHeight: 16,
    fontFamily: 'monospace',
  },
  loadingBox: { flexDirection: 'row', alignItems: 'center', padding: 12 },
  loadingText: { fontSize: 13, color: '#666', marginLeft: 8 },
  progressBox: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
  },
  progressHead: { flexDirection: 'row', alignItems: 'center' },
  progressLabel: { flex: 1, fontSize: 12, color: '#3b6fa8', lineHeight: 18, marginLeft: 8 },
  progressPreview: {
    maxHeight: 120,
    backgroundColor: '#1f2430',
    borderRadius: 6,
    marginTop: 8,
  },
  progressText: { padding: 8, fontSize: 10, color: '#d7e3f4', lineHeight: 14, fontFamily: 'monospace' },
  emptyText: { fontSize: 13, color: '#999', paddingVertical: 20, textAlign: 'center' },
  historyItem: {
    borderWidth: 1,
    borderColor: '#eceff3',
    borderRadius: 8,
    padding: 10,
    marginTop: 10,
  },
  historyName: { fontSize: 14, fontWeight: '600', color: '#222', flex: 1 },
  historyPrompt: { fontSize: 12, color: '#666', lineHeight: 18, marginTop: 6 },
  historyTime: { fontSize: 11, color: '#aaa', marginTop: 4 },
  badgePlan: {
    fontSize: 11,
    color: '#874d00',
    backgroundColor: '#fffbe6',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginLeft: 8,
    overflow: 'hidden',
  },
  previewScroll: { marginTop: 8, marginBottom: 4 },
  tokenText: { fontSize: 11, color: '#6b7280' },
  phone: {
    width: 186,
    borderWidth: 2,
    borderColor: '#c7d2df',
    borderRadius: 16,
    backgroundColor: '#fff',
    paddingHorizontal: 8,
    paddingTop: 8,
    paddingBottom: 12,
    marginRight: 12,
  },
  phoneTop: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 2 },
  phoneStatus: { fontSize: 9, color: '#9aa7b5' },
  phoneScreenTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#33485f',
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 4,
    paddingBottom: 4,
    borderBottomWidth: RN.StyleSheet.hairlineWidth,
    borderBottomColor: '#e2e8f0',
  },
  phoneBody: { minHeight: 150 },
  wireBlock: { marginTop: 6 },
  wireTitle: { fontSize: 13, fontWeight: '700', color: '#22303f', textAlign: 'center' },
  wireText: { fontSize: 11, color: '#7b8794', lineHeight: 15 },
  wireInput: {
    borderWidth: 1,
    borderColor: '#d5dde7',
    borderRadius: 5,
    paddingHorizontal: 6,
    paddingVertical: 5,
    backgroundColor: '#fafcfe',
  },
  wireInputText: { fontSize: 10, color: '#9aa7b5' },
  wireButton: {
    backgroundColor: '#4a90d9',
    borderRadius: 5,
    paddingVertical: 6,
    alignItems: 'center',
  },
  wireButtonText: { fontSize: 11, color: '#fff', fontWeight: '600' },
  wireListRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
    borderBottomWidth: RN.StyleSheet.hairlineWidth,
    borderBottomColor: '#eef1f5',
  },
  wireDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: '#b7d6f5', marginRight: 5 },
  wireListText: { fontSize: 10, color: '#5d6b7a', flex: 1 },
  wireImage: {
    height: 56,
    borderRadius: 5,
    backgroundColor: '#e8eef5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  wireImageText: { fontSize: 10, color: '#7b8794' },
  wireCard: {
    borderWidth: 1,
    borderColor: '#e2e8f0',
    backgroundColor: '#f7fafd',
    borderRadius: 5,
    padding: 6,
  },
  wireCardText: { fontSize: 10, color: '#5d6b7a', lineHeight: 14 },
  wireRow: { flexDirection: 'row' },
  wireRowCell: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 4,
    paddingVertical: 6,
    alignItems: 'center',
    marginRight: 4,
    backgroundColor: '#fbfcfd',
  },
  wireRowText: { fontSize: 9, color: '#5d6b7a' },
  planLine: { fontSize: 12, color: '#4a5b6d', lineHeight: 19 },
  editArea: { minHeight: 96, fontSize: 12, lineHeight: 18, textAlignVertical: 'top' },
  editAreaSmall: { minHeight: 60, fontSize: 13, lineHeight: 18, textAlignVertical: 'top' },
  importArea: { height: 120, fontSize: 12, lineHeight: 18, textAlignVertical: 'top' },
  roundItem: {
    borderWidth: 1,
    borderColor: '#eceff3',
    borderRadius: 8,
    padding: 10,
    marginTop: 10,
    backgroundColor: '#fff',
  },
  roundItemActive: { borderColor: '#4a90d9', backgroundColor: '#f7fbff' },
  roundTitle: { fontSize: 13, fontWeight: '600', color: '#222', flexShrink: 1 },
  roundReq: { fontSize: 12, color: '#5d6b7a', lineHeight: 18, marginTop: 4 },
  diffBox: {
    marginTop: 10,
    backgroundColor: '#1f2430',
    borderRadius: 8,
    padding: 10,
  },
  diffTitle: { fontSize: 11, color: '#a9c4e4', marginBottom: 6 },
  diffAdd: { fontSize: 10, color: '#8ddb8d', lineHeight: 15, fontFamily: 'monospace' },
  diffDel: { fontSize: 10, color: '#f08a8a', lineHeight: 15, fontFamily: 'monospace' },
  conflictBox: {
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#ffd591',
    backgroundColor: '#fffbe6',
    borderRadius: 8,
    padding: 12,
  },
});

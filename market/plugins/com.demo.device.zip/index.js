module.exports = function({ React, RN, api }) {
  const { View, Text, Button, ScrollView, StyleSheet, Image } = RN;
  const styles = StyleSheet.create({
    container: { flex: 1, padding: 12, backgroundColor: '#fff' },
    title: { fontSize: 18, fontWeight: 'bold', marginBottom: 8 },
    row: { marginBottom: 6 },
    status: { marginTop: 12, padding: 12, backgroundColor: '#f5f5f5', borderRadius: 6 },
    msg: { fontSize: 13, color: '#333', lineHeight: 19 },
    photo: { width: 120, height: 120, marginTop: 8, borderRadius: 6, backgroundColor: '#eee' },
  });
  return function DeviceDemo() {
    const [msg, setMsg] = React.useState('点击按钮测试插件原生能力');
    const [photo, setPhoto] = React.useState(null);
    const [acc, setAcc] = React.useState('');

    // 注意：插件沙箱不支持 async/await，这里统一用 Promise 链
    const run = function (fn) {
      return Promise.resolve().then(fn).then(function (r) {
        if (typeof r === 'string') setMsg(r);
      }).catch(function (e) {
        setMsg('出错：' + (e && e.message ? e.message : String(e)));
      });
    };

    React.useEffect(() => {
      let off = null;
      api.sensors.start('accelerometer', { interval: 300 }).then(function () {
        off = api.sensors.subscribe('accelerometer', function (d) {
          setAcc('加速度 x=' + d.x.toFixed(2) + ' y=' + d.y.toFixed(2) + ' z=' + d.z.toFixed(2));
        });
      }).catch(function () {});
      return function () {
        if (off) off();
        api.sensors.stopAll().catch(function () {});
      };
    }, []);

    return React.createElement(View, { style: styles.container },
      React.createElement(Text, { style: styles.title }, '原生能力演示'),
      React.createElement(ScrollView, { style: { flex: 1 } },
        React.createElement(View, { style: styles.row }, React.createElement(Button, {
          title: '设备状态',
          onPress: function () { run(function () {
            return Promise.all([api.device.battery(), api.device.network(), api.device.info()])
              .then(function (r) {
                const b = r[0], n = r[1], i = r[2];
                return '电量 ' + b.level + '%（充电 ' + b.charging + '）  网络 ' + n.type + '  ' + i.brand + ' ' + i.model + '  SDK' + i.sdk;
              });
          }); },
        })),
        React.createElement(View, { style: styles.row }, React.createElement(Button, {
          title: '剪贴板',
          onPress: function () { run(function () {
            return api.clipboard.set('来自插件 ' + new Date().toLocaleTimeString())
              .then(function () { return api.clipboard.get(); })
              .then(function (text) { return '已写入并读回：' + text; });
          }); },
        })),
        React.createElement(View, { style: styles.row }, React.createElement(Button, {
          title: '震动',
          onPress: function () { run(function () {
            return api.vibrate.pattern([0, 80, 60, 160]).then(function () { return '已触发震动'; });
          }); },
        })),
        React.createElement(View, { style: styles.row }, React.createElement(Button, {
          title: '发通知（3 秒后）',
          onPress: function () { run(function () {
            return api.notifications.show({ title: '插件通知', body: '这是一条来自插件的本地通知', delay: 3000 })
              .then(function (id) { return '通知将在 3 秒后送达，id=' + id; });
          }); },
        })),
        React.createElement(View, { style: styles.row }, React.createElement(Button, {
          title: '文件读写',
          onPress: function () { run(function () {
            return api.files.writeText('demo.txt', 'hello plugin')
              .then(function () { return api.files.readText('demo.txt'); })
              .then(function (content) { return '写入并读回：' + content; });
          }); },
        })),
        React.createElement(View, { style: styles.row }, React.createElement(Button, {
          title: '可用传感器',
          onPress: function () { run(function () {
            return api.sensors.available().then(function (list) { return '可用传感器：' + list.join(', '); });
          }); },
        })),
        React.createElement(View, { style: styles.row }, React.createElement(Button, {
          title: '获取定位',
          onPress: function () { run(function () {
            return api.location.getCurrent({ timeout: 12000 }).then(function (l) {
              return '纬度 ' + l.latitude.toFixed(5) + '  经度 ' + l.longitude.toFixed(5) + '  精度 ' + l.accuracy.toFixed(0) + 'm';
            });
          }); },
        })),
        React.createElement(View, { style: styles.row }, React.createElement(Button, {
          title: '拍照',
          onPress: function () { run(function () {
            return api.camera.takePhoto().then(function (p) {
              setPhoto(p.uri);
              return '已拍照：' + p.path;
            });
          }); },
        })),
        React.createElement(View, { style: styles.row }, React.createElement(Button, {
          title: '生物识别',
          onPress: function () { run(function () {
            return api.biometric.authenticate({ title: '插件验证', subtitle: '请验证指纹或人脸' })
              .then(function (passed) { return passed ? '验证通过' : '验证未通过或已取消'; });
          }); },
        })),
        photo ? React.createElement(Image, { style: styles.photo, source: { uri: photo } }) : null
      ),
      React.createElement(View, { style: styles.status },
        React.createElement(Text, { style: styles.msg }, msg),
        acc ? React.createElement(Text, { style: styles.msg }, acc) : null)
    );
  };
};
module.exports = function ({ React, RN, api }) {
  var View = RN.View;
  var Text = RN.Text;
  var TextInput = RN.TextInput;
  var ScrollView = RN.ScrollView;
  var StyleSheet = RN.StyleSheet;
  var TouchableOpacity = RN.TouchableOpacity;
  var C = React.createElement;

  var HISTORY_KEY = 'sessions';
  var MAX_HISTORY = 50;
  var OP_KEYS = ['add', 'sub', 'mul', 'div'];
  var OP_LABELS = { add: '加法', sub: '减法', mul: '乘法', div: '除法' };
  var DIFFS = [
    { key: 'within20', label: '20 以内', hint: '加减结果不超过 20，乘除结果也不超过 20' },
    { key: 'within100', label: '100 以内', hint: '加减结果不超过 100，乘除用 1-9 口诀' },
    { key: 'twoDigitMul', label: '两位数乘一位数', hint: '乘法为 10-99 乘 2-9，除法为两位数除以一位数' },
    { key: 'exactDiv', label: '整除', hint: '除法保证能整除，加减乘按 100 以内' },
  ];
  var COUNTS = [10, 20, 50];

  var styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f6f7fb' },
    scroll: { padding: 14, paddingBottom: 28 },
    card: { backgroundColor: '#ffffff', borderRadius: 12, padding: 14, marginBottom: 12 },
    title: { fontSize: 22, fontWeight: '700', color: '#111827' },
    subtitle: { fontSize: 13, color: '#6b7280', lineHeight: 19, marginTop: 4 },
    sectionTitle: { fontSize: 15, fontWeight: '600', color: '#111827', marginBottom: 2 },
    sectionHint: { fontSize: 12, color: '#6b7280', lineHeight: 18 },
    chipRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 },
    chip: {
      paddingHorizontal: 14,
      paddingVertical: 10,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: '#d1d5db',
      backgroundColor: '#ffffff',
      marginRight: 8,
      marginBottom: 8,
    },
    chipOn: { backgroundColor: '#2563eb', borderColor: '#2563eb' },
    chipText: { fontSize: 14, color: '#374151' },
    chipTextOn: { color: '#ffffff', fontWeight: '600' },
    btn: {
      minHeight: 50,
      borderRadius: 10,
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: 16,
      marginTop: 10,
    },
    btnPrimary: { backgroundColor: '#2563eb' },
    btnSecondary: { backgroundColor: '#eef2ff' },
    btnGhost: { backgroundColor: '#ffffff', borderWidth: 1, borderColor: '#d1d5db' },
    btnText: { fontSize: 17, fontWeight: '600', color: '#ffffff' },
    btnTextSecondary: { fontSize: 16, fontWeight: '600', color: '#3730a3' },
    btnTextGhost: { fontSize: 15, fontWeight: '600', color: '#4b5563' },
    btnDisabled: { backgroundColor: '#c7d2fe' },
    msg: { fontSize: 13, color: '#b91c1c', lineHeight: 19, marginTop: 8 },
    tip: { fontSize: 12, color: '#9ca3af', lineHeight: 18, marginTop: 10 },
    topRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    progressText: { fontSize: 14, color: '#374151', fontWeight: '600' },
    progressTrack: {
      height: 8,
      backgroundColor: '#e5e7eb',
      borderRadius: 4,
      marginTop: 10,
      overflow: 'hidden',
    },
    progressBar: { height: 8, backgroundColor: '#2563eb', borderRadius: 4 },
    question: {
      fontSize: 34,
      fontWeight: '700',
      color: '#111827',
      textAlign: 'center',
      marginTop: 22,
      marginBottom: 18,
    },
    input: {
      borderWidth: 1,
      borderColor: '#cbd5e1',
      borderRadius: 10,
      paddingVertical: 10,
      paddingHorizontal: 12,
      fontSize: 28,
      textAlign: 'center',
      color: '#111827',
      backgroundColor: '#ffffff',
    },
    feedback: { borderRadius: 10, padding: 12, marginTop: 12, borderWidth: 1 },
    feedbackOk: { backgroundColor: '#ecfdf5', borderColor: '#10b981' },
    feedbackBad: { backgroundColor: '#fef2f2', borderColor: '#ef4444' },
    feedbackText: { fontSize: 15, lineHeight: 22, color: '#111827' },
    statRow: { flexDirection: 'row', marginTop: 12 },
    statCell: { flex: 1, alignItems: 'center' },
    statValue: { fontSize: 22, fontWeight: '700', color: '#111827' },
    statLabel: { fontSize: 12, color: '#6b7280', marginTop: 2 },
    bigAccuracy: { fontSize: 44, fontWeight: '700', color: '#2563eb', textAlign: 'center' },
    bigLabel: { fontSize: 13, color: '#6b7280', textAlign: 'center', marginTop: 2 },
    wrongItem: {
      borderTopWidth: 1,
      borderTopColor: '#f3f4f6',
      paddingVertical: 9,
    },
    wrongText: { fontSize: 15, color: '#111827' },
    wrongDetail: { fontSize: 13, color: '#6b7280', marginTop: 2, lineHeight: 18 },
    historyItem: {
      borderTopWidth: 1,
      borderTopColor: '#f3f4f6',
      paddingVertical: 10,
      flexDirection: 'row',
      alignItems: 'center',
    },
    historyMain: { flex: 1, paddingRight: 10 },
    historyTitle: { fontSize: 14, color: '#111827', fontWeight: '600' },
    historyMeta: { fontSize: 12, color: '#6b7280', marginTop: 2, lineHeight: 17 },
    redoBtn: {
      paddingHorizontal: 12,
      paddingVertical: 8,
      borderRadius: 8,
      backgroundColor: '#eef2ff',
    },
    redoText: { fontSize: 13, color: '#3730a3', fontWeight: '600' },
    trend: { flexDirection: 'row', alignItems: 'flex-end', height: 70, marginTop: 12 },
    trendItem: { flex: 1, alignItems: 'center', justifyContent: 'flex-end' },
    trendBar: { width: 14, backgroundColor: '#93c5fd', borderRadius: 3 },
    trendLabel: { fontSize: 9, color: '#9ca3af', marginTop: 3 },
    empty: { fontSize: 13, color: '#9ca3af', marginTop: 10, lineHeight: 19 },
  });

  function randInt(min, max) {
    return min + Math.floor(Math.random() * (max - min + 1));
  }

  function errText(e) {
    return e && e.message ? e.message : String(e);
  }

  function pad2(n) {
    return n < 10 ? '0' + n : '' + n;
  }

  function formatTime(d) {
    return (d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }

  function formatDuration(seconds) {
    var s = seconds;
    var m = Math.floor(s / 60);
    var rest = s % 60;
    return m > 0 ? m + ' 分 ' + rest + ' 秒' : rest + ' 秒';
  }

  function diffLabel(key) {
    for (var i = 0; i < DIFFS.length; i++) {
      if (DIFFS[i].key === key) return DIFFS[i].label;
    }
    return key;
  }

  function diffHint(key) {
    for (var i = 0; i < DIFFS.length; i++) {
      if (DIFFS[i].key === key) return DIFFS[i].hint;
    }
    return '';
  }

  function makeQuestion(op, diff) {
    var a;
    var b;
    if (op === 'add') {
      var max = diff === 'within20' ? 20 : 100;
      a = randInt(1, max - 1);
      b = randInt(1, max - a);
      return { op: op, a: a, b: b, answer: a + b, text: a + ' + ' + b + ' = ?' };
    }
    if (op === 'sub') {
      var maxSub = diff === 'within20' ? 20 : 100;
      a = randInt(2, maxSub);
      b = randInt(1, a - 1);
      return { op: op, a: a, b: b, answer: a - b, text: a + ' - ' + b + ' = ?' };
    }
    if (op === 'mul') {
      if (diff === 'twoDigitMul') {
        a = randInt(10, 99);
        b = randInt(2, 9);
      } else if (diff === 'within20') {
        a = randInt(1, 5);
        b = randInt(1, 4);
      } else {
        a = randInt(1, 9);
        b = randInt(1, 9);
      }
      return { op: op, a: a, b: b, answer: a * b, text: a + ' x ' + b + ' = ?' };
    }
    var divisor;
    var quotient;
    if (diff === 'within20') {
      divisor = randInt(2, 5);
      quotient = randInt(1, 4);
    } else if (diff === 'twoDigitMul') {
      divisor = randInt(2, 9);
      quotient = randInt(2, 11);
    } else {
      divisor = randInt(2, 9);
      quotient = randInt(2, 9);
    }
    a = divisor * quotient;
    return { op: op, a: a, b: divisor, answer: quotient, text: a + ' / ' + divisor + ' = ?' };
  }

  function generateQuestions(keys, diff, count) {
    var list = [];
    for (var i = 0; i < count; i++) {
      var op = keys[i % keys.length];
      var question = makeQuestion(op, diff);
      var guard = 0;
      while (guard < 20 && list.length > 0 && list[list.length - 1].text === question.text) {
        question = makeQuestion(op, diff);
        guard++;
      }
      list.push(question);
    }
    return list;
  }

  function parseHistory(raw) {
    var arr = [];
    if (raw) {
      try {
        arr = JSON.parse(raw);
      } catch (e) {
        arr = [];
      }
    }
    if (!Array.isArray(arr)) return [];
    return arr;
  }

  function Chip(props) {
    return C(
      TouchableOpacity,
      {
        onPress: props.onPress,
        activeOpacity: 0.75,
        style: [styles.chip, props.active ? styles.chipOn : null],
      },
      C(Text, { style: [styles.chipText, props.active ? styles.chipTextOn : null] }, props.label)
    );
  }

  function Btn(props) {
    var tone = props.tone || 'primary';
    var style = tone === 'secondary' ? styles.btnSecondary : tone === 'ghost' ? styles.btnGhost : styles.btnPrimary;
    var textStyle = tone === 'secondary' ? styles.btnTextSecondary : tone === 'ghost' ? styles.btnTextGhost : styles.btnText;
    return C(
      TouchableOpacity,
      {
        onPress: props.disabled ? null : props.onPress,
        activeOpacity: 0.8,
        style: [styles.btn, style, props.disabled ? styles.btnDisabled : null],
      },
      C(Text, { style: textStyle }, props.title)
    );
  }

  return function MathPractice() {
    var stageState = React.useState('home');
    var stage = stageState[0];
    var setStage = stageState[1];

    var opsState = React.useState({ add: true, sub: true, mul: true, div: true });
    var ops = opsState[0];
    var setOps = opsState[1];

    var diffState = React.useState('within100');
    var diff = diffState[0];
    var setDiff = diffState[1];

    var countState = React.useState(10);
    var count = countState[0];
    var setCount = countState[1];

    var historyState = React.useState([]);
    var history = historyState[0];
    var setHistory = historyState[1];

    var questionsState = React.useState([]);
    var questions = questionsState[0];
    var setQuestions = questionsState[1];

    var indexState = React.useState(0);
    var qIndex = indexState[0];
    var setQIndex = indexState[1];

    var recordsState = React.useState([]);
    var records = recordsState[0];
    var setRecords = recordsState[1];

    var inputState = React.useState('');
    var input = inputState[0];
    var setInput = inputState[1];

    var feedbackState = React.useState(null);
    var feedback = feedbackState[0];
    var setFeedback = feedbackState[1];

    var startedState = React.useState(0);
    var startedAt = startedState[0];
    var setStartedAt = startedState[1];

    var resultState = React.useState(null);
    var result = resultState[0];
    var setResult = resultState[1];

    var modeState = React.useState('normal');
    var mode = modeState[0];
    var setMode = modeState[1];

    var sessionDiffState = React.useState('within100');
    var sessionDiff = sessionDiffState[0];
    var setSessionDiff = sessionDiffState[1];

    var msgState = React.useState('');
    var msg = msgState[0];
    var setMsg = msgState[1];

    var showAllState = React.useState(false);
    var showAll = showAllState[0];
    var setShowAll = showAllState[1];

    React.useEffect(function () {
      api.storage
        .get(HISTORY_KEY)
        .then(function (raw) {
          setHistory(parseHistory(raw));
        })
        .catch(function (e) {
          setMsg('读取历史失败：' + errText(e));
        });
    }, []);

    var toggleOp = function (key) {
      var next = { add: ops.add, sub: ops.sub, mul: ops.mul, div: ops.div };
      next[key] = !next[key];
      setOps(next);
      setMsg('');
    };

    var selectedKeys = function () {
      var keys = [];
      for (var i = 0; i < OP_KEYS.length; i++) {
        if (ops[OP_KEYS[i]]) keys.push(OP_KEYS[i]);
      }
      return keys;
    };

    var labelsFromRecords = function (recs) {
      var seen = {};
      var out = [];
      for (var i = 0; i < recs.length; i++) {
        var key = recs[i].op;
        if (!seen[key]) {
          seen[key] = true;
          out.push(OP_LABELS[key] || key);
        }
      }
      return out;
    };

    var startPractice = function (list, nextMode, nextDiff) {
      var useDiff = nextDiff || diff;
      setQuestions(list);
      setQIndex(0);
      setRecords([]);
      setInput('');
      setFeedback(null);
      setStartedAt(Date.now());
      setResult(null);
      setMode(nextMode || 'normal');
      setSessionDiff(useDiff);
      setStage('practice');
      setMsg('');
    };

    var beginNew = function () {
      var keys = selectedKeys();
      if (keys.length === 0) {
        setMsg('请至少选择一种题型');
        return;
      }
      startPractice(generateQuestions(keys, diff, count), 'normal', diff);
    };

    var finish = function (recs) {
      var seconds = Math.max(1, Math.round((Date.now() - startedAt) / 1000));
      var correct = 0;
      var wrong = 0;
      var skipped = 0;
      var wrongList = [];
      for (var i = 0; i < recs.length; i++) {
        var r = recs[i];
        if (r.ok) {
          correct++;
        } else if (r.skipped) {
          skipped++;
          wrongList.push({ op: r.op, a: r.a, b: r.b, text: r.text, answer: r.answer, user: null, skipped: true });
        } else {
          wrong++;
          wrongList.push({ op: r.op, a: r.a, b: r.b, text: r.text, answer: r.answer, user: r.user, skipped: false });
        }
      }
      var total = recs.length;
      var accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;
      var entry = {
        id: Date.now(),
        time: formatTime(new Date()),
        ops: labelsFromRecords(recs),
        diff: diffLabel(sessionDiff),
        diffKey: sessionDiff,
        count: total,
        correct: correct,
        wrong: wrong,
        skipped: skipped,
        accuracy: accuracy,
        seconds: seconds,
        mode: mode,
        wrongQuestions: wrongList,
      };
      setResult(entry);
      setStage('result');
      setMsg('');

      var next = [entry];
      for (var j = 0; j < history.length; j++) {
        next.push(history[j]);
      }
      if (next.length > MAX_HISTORY) next = next.slice(0, MAX_HISTORY);
      setHistory(next);
      api.storage
        .set(HISTORY_KEY, JSON.stringify(next))
        .catch(function (e) {
          setMsg('历史保存失败：' + errText(e));
        });
    };

    var submit = function () {
      if (feedback) return;
      var raw = input.trim();
      if (!raw) {
        setMsg('请先输入答案，或点「跳过」');
        return;
      }
      var value = Number(raw);
      if (isNaN(value)) {
        setMsg('请输入数字');
        return;
      }
      var question = questions[qIndex];
      var ok = value === question.answer;
      var rec = {
        op: question.op,
        a: question.a,
        b: question.b,
        text: question.text,
        answer: question.answer,
        user: value,
        skipped: false,
        ok: ok,
      };
      setRecords(records.concat([rec]));
      setFeedback({ ok: ok, answer: question.answer, user: value });
      setMsg('');
    };

    var skip = function () {
      if (feedback) return;
      var question = questions[qIndex];
      var rec = {
        op: question.op,
        a: question.a,
        b: question.b,
        text: question.text,
        answer: question.answer,
        user: null,
        skipped: true,
        ok: false,
      };
      var recs = records.concat([rec]);
      if (qIndex + 1 >= questions.length) {
        finish(recs);
        return;
      }
      setRecords(recs);
      setQIndex(qIndex + 1);
      setInput('');
      setMsg('');
    };

    var nextQuestion = function () {
      if (qIndex + 1 >= questions.length) {
        finish(records);
        return;
      }
      setQIndex(qIndex + 1);
      setInput('');
      setFeedback(null);
      setMsg('');
    };

    var redoWrong = function (entry) {
      var list = entry && entry.wrongQuestions ? entry.wrongQuestions : [];
      if (list.length === 0) return;
      var questionsAgain = [];
      for (var i = 0; i < list.length; i++) {
        questionsAgain.push({
          op: list[i].op || 'add',
          a: list[i].a || 0,
          b: list[i].b || 0,
          text: list[i].text,
          answer: list[i].answer,
        });
      }
      startPractice(questionsAgain, 'redo', entry.diffKey || diff);
    };

    var exitPractice = function () {
      setStage('home');
      setQuestions([]);
      setRecords([]);
      setFeedback(null);
      setInput('');
      setMsg('');
    };

    var homeView = function () {
      var recent = showAll ? history : history.slice(0, 5);
      var trend = history.slice(0, 10).reverse();
      return C(
        ScrollView,
        { style: styles.container, contentContainerStyle: styles.scroll },
        C(
          View,
          { style: styles.card },
          C(Text, { style: styles.title }, '运算练习'),
          C(Text, { style: styles.subtitle }, '选择题型、难度与题量，逐题作答即时判分，支持错题重做与成绩记录'),
          msg ? C(Text, { style: styles.msg }, msg) : null
        ),
        C(
          View,
          { style: styles.card },
          C(Text, { style: styles.sectionTitle }, '题型（可多选）'),
          C(Text, { style: styles.sectionHint }, '至少选择一种'),
          C(
            View,
            { style: styles.chipRow },
            OP_KEYS.map(function (key) {
              return C(Chip, {
                key: key,
                label: OP_LABELS[key],
                active: !!ops[key],
                onPress: function () {
                  toggleOp(key);
                },
              });
            })
          )
        ),
        C(
          View,
          { style: styles.card },
          C(Text, { style: styles.sectionTitle }, '难度'),
          C(Text, { style: styles.sectionHint }, diffHint(diff)),
          C(
            View,
            { style: styles.chipRow },
            DIFFS.map(function (item) {
              return C(Chip, {
                key: item.key,
                label: item.label,
                active: diff === item.key,
                onPress: function () {
                  setDiff(item.key);
                },
              });
            })
          )
        ),
        C(
          View,
          { style: styles.card },
          C(Text, { style: styles.sectionTitle }, '题量'),
          C(
            View,
            { style: styles.chipRow },
            COUNTS.map(function (n) {
              return C(Chip, {
                key: String(n),
                label: n + ' 题',
                active: count === n,
                onPress: function () {
                  setCount(n);
                },
              });
            })
          ),
          C(Btn, { title: '开始练习', onPress: beginNew })
        ),
        C(
          View,
          { style: styles.card },
          C(Text, { style: styles.sectionTitle }, '历史成绩'),
          C(Text, { style: styles.sectionHint }, '共 ' + history.length + ' 次记录，最多保留 ' + MAX_HISTORY + ' 次'),
          history.length > 0
            ? C(
                View,
                { style: styles.trend },
                trend.map(function (item, i) {
                  var h = Math.max(6, Math.round(item.accuracy * 0.5));
                  return C(
                    View,
                    { key: String(item.id) + '-' + i, style: styles.trendItem },
                    C(View, { style: [styles.trendBar, { height: h }] }),
                    C(Text, { style: styles.trendLabel }, String(item.accuracy))
                  );
                })
              )
            : C(Text, { style: styles.empty }, '还没有记录，完成一轮练习后会出现在这里'),
          recent.map(function (item) {
            var title =
              (item.mode === 'redo' ? '错题重做 · ' : '') +
              item.ops.join(' + ') +
              ' · ' +
              item.diff +
              ' · ' +
              item.count +
              ' 题';
            var meta =
              item.time +
              '　正确率 ' +
              item.accuracy +
              '%　用时 ' +
              formatDuration(item.seconds) +
              '　错 ' +
              item.wrong +
              ' 跳 ' +
              item.skipped;
            return C(
              View,
              { key: String(item.id), style: styles.historyItem },
              C(
                View,
                { style: styles.historyMain },
                C(Text, { style: styles.historyTitle }, title),
                C(Text, { style: styles.historyMeta }, meta)
              ),
              item.wrongQuestions && item.wrongQuestions.length > 0
                ? C(
                    TouchableOpacity,
                    {
                      style: styles.redoBtn,
                      activeOpacity: 0.8,
                      onPress: function () {
                        redoWrong(item);
                      },
                    },
                    C(Text, { style: styles.redoText }, '重做错题')
                  )
                : null
            );
          }),
          history.length > 5
            ? C(Btn, {
                title: showAll ? '收起历史' : '查看全部记录',
                tone: 'ghost',
                onPress: function () {
                  setShowAll(!showAll);
                },
              })
            : null
        ),
        C(Text, { style: styles.tip }, '所有成绩保存在本插件私有存储中，不联网、不上传')
      );
    };

    var practiceView = function () {
      var question = questions[qIndex];
      var answered = feedback ? 1 : 0;
      var correctCount = 0;
      for (var i = 0; i < records.length; i++) {
        if (records[i].ok) correctCount++;
      }
      var pct = questions.length > 0 ? Math.round(((qIndex + answered) / questions.length) * 100) : 0;
      return C(
        ScrollView,
        { style: styles.container, contentContainerStyle: styles.scroll, keyboardShouldPersistTaps: 'handled' },
        C(
          View,
          { style: styles.card },
          C(
            View,
            { style: styles.topRow },
            C(Text, { style: styles.progressText }, '第 ' + (qIndex + 1) + ' / ' + questions.length + ' 题'),
            C(Text, { style: styles.progressText }, '已答对 ' + correctCount)
          ),
          C(
            View,
            { style: styles.progressTrack },
            C(View, { style: [styles.progressBar, { width: pct + '%' }] })
          ),
          C(Text, { style: styles.question }, question ? question.text : ''),
          C(TextInput, {
            style: styles.input,
            value: input,
            onChangeText: function (text) {
              setInput(text);
              if (msg) setMsg('');
            },
            keyboardType: 'number-pad',
            maxLength: 4,
            editable: !feedback,
            placeholder: '输入答案',
          }),
          msg ? C(Text, { style: styles.msg }, msg) : null,
          feedback
            ? C(
                View,
                {
                  style: [
                    styles.feedback,
                    feedback.ok ? styles.feedbackOk : styles.feedbackBad,
                  ],
                },
                C(
                  Text,
                  { style: styles.feedbackText },
                  feedback.ok
                    ? '答对了，' + question.text.replace('?', String(question.answer))
                    : '答错了，正确答案是 ' + question.answer + (feedback.user === null ? '' : '（你填了 ' + feedback.user + '）')
                )
              )
            : null,
          feedback
            ? C(Btn, {
                title: qIndex + 1 >= questions.length ? '查看结果' : '下一题',
                onPress: nextQuestion,
              })
            : C(Btn, { title: '提交答案', onPress: submit }),
          feedback
            ? null
            : C(Btn, { title: '跳过这题', tone: 'ghost', onPress: skip }),
          C(Btn, { title: '退出练习（不保存）', tone: 'ghost', onPress: exitPractice })
        )
      );
    };

    var resultView = function () {
      var entry = result;
      if (!entry) return homeView();
      var wrongList = entry.wrongQuestions || [];
      return C(
        ScrollView,
        { style: styles.container, contentContainerStyle: styles.scroll },
        C(
          View,
          { style: styles.card },
          C(Text, { style: styles.sectionTitle }, '练习结果'),
          C(Text, { style: styles.bigAccuracy }, String(entry.accuracy) + '%'),
          C(Text, { style: styles.bigLabel }, '正确率'),
          C(
            View,
            { style: styles.statRow },
            C(
              View,
              { style: styles.statCell },
              C(Text, { style: styles.statValue }, String(entry.correct)),
              C(Text, { style: styles.statLabel }, '答对')
            ),
            C(
              View,
              { style: styles.statCell },
              C(Text, { style: styles.statValue }, String(entry.wrong)),
              C(Text, { style: styles.statLabel }, '答错')
            ),
            C(
              View,
              { style: styles.statCell },
              C(Text, { style: styles.statValue }, String(entry.skipped)),
              C(Text, { style: styles.statLabel }, '跳过')
            )
          ),
          C(
            View,
            { style: styles.statRow },
            C(
              View,
              { style: styles.statCell },
              C(Text, { style: styles.statValue }, formatDuration(entry.seconds)),
              C(Text, { style: styles.statLabel }, '用时')
            ),
            C(
              View,
              { style: styles.statCell },
              C(Text, { style: styles.statValue }, String(entry.count)),
              C(Text, { style: styles.statLabel }, '总题数')
            )
          ),
          C(
            Text,
            { style: styles.tip },
            entry.ops.join(' + ') + ' · ' + entry.diff + (entry.mode === 'redo' ? ' · 错题重做' : '')
          )
        ),
        C(
          View,
          { style: styles.card },
          C(Text, { style: styles.sectionTitle }, '错题清单（' + wrongList.length + '）'),
          wrongList.length === 0
            ? C(Text, { style: styles.empty }, '全部答对，没有错题')
            : wrongList.map(function (item, i) {
                return C(
                  View,
                  { key: 'wrong-' + i, style: styles.wrongItem },
                  C(Text, { style: styles.wrongText }, item.text.replace('?', String(item.answer))),
                  C(
                    Text,
                    { style: styles.wrongDetail },
                    item.skipped
                      ? '你跳过了这题'
                      : '你填了 ' + item.user + '，正确答案是 ' + item.answer
                  )
                );
              })
        ),
        wrongList.length > 0
          ? C(Btn, {
              title: '重做错题（' + wrongList.length + ' 题）',
              onPress: function () {
                redoWrong(entry);
              },
            })
          : null,
        C(Btn, { title: '再练一轮', tone: 'secondary', onPress: beginNew }),
        C(Btn, { title: '返回首页', tone: 'ghost', onPress: exitPractice })
      );
    };

    if (stage === 'practice') return practiceView();
    if (stage === 'result') return resultView();
    return homeView();
  };
};

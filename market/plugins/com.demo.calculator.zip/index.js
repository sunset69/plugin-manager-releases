module.exports = function({ React, RN, api }) {
  const { View, Text, Button, StyleSheet, TextInput } = RN;
  const styles = StyleSheet.create({
    container: { flex: 1, padding: 16, backgroundColor: '#fff' },
    display: { fontSize: 48, textAlign: 'right', marginBottom: 16, padding: 16, backgroundColor: '#f0f0f0', borderRadius: 8 },
    row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
    btn: { flex: 1, marginHorizontal: 4 },
  });
  return function Calculator() {
    const [display, setDisplay] = React.useState('0');
    const [prev, setPrev] = React.useState(null);
    const [op, setOp] = React.useState(null);
    const inputDigit = (d) => {
      setDisplay(display === '0' ? d : display + d);
    };
    const inputOp = (nextOp) => {
      setPrev(parseFloat(display));
      setOp(nextOp);
      setDisplay('0');
    };
    const calc = () => {
      if (prev === null || op === null) return;
      const cur = parseFloat(display);
      let r = 0;
      if (op === '+') r = prev + cur;
      else if (op === '-') r = prev - cur;
      else if (op === '*') r = prev * cur;
      else if (op === '/') r = cur === 0 ? 0 : prev / cur;
      setDisplay(String(r));
      setPrev(null);
      setOp(null);
    };
    const clear = () => { setDisplay('0'); setPrev(null); setOp(null); };
    const Btn = ({ title, onPress }) => React.createElement(View, { style: styles.btn },
      React.createElement(Button, { title, onPress }));
    return React.createElement(View, { style: styles.container },
      React.createElement(Text, { style: styles.display }, display),
      React.createElement(View, { style: styles.row },
        React.createElement(Btn, { title: 'C', onPress: clear }),
        React.createElement(Btn, { title: '/', onPress: () => inputOp('/') }),
        React.createElement(Btn, { title: '*', onPress: () => inputOp('*') }),
        React.createElement(Btn, { title: '-', onPress: () => inputOp('-') })),
      React.createElement(View, { style: styles.row },
        React.createElement(Btn, { title: '7', onPress: () => inputDigit('7') }),
        React.createElement(Btn, { title: '8', onPress: () => inputDigit('8') }),
        React.createElement(Btn, { title: '9', onPress: () => inputDigit('9') }),
        React.createElement(Btn, { title: '+', onPress: () => inputOp('+') })),
      React.createElement(View, { style: styles.row },
        React.createElement(Btn, { title: '4', onPress: () => inputDigit('4') }),
        React.createElement(Btn, { title: '5', onPress: () => inputDigit('5') }),
        React.createElement(Btn, { title: '6', onPress: () => inputDigit('6') }),
        React.createElement(Btn, { title: '=', onPress: calc })),
      React.createElement(View, { style: styles.row },
        React.createElement(Btn, { title: '1', onPress: () => inputDigit('1') }),
        React.createElement(Btn, { title: '2', onPress: () => inputDigit('2') }),
        React.createElement(Btn, { title: '3', onPress: () => inputDigit('3') }),
        React.createElement(Btn, { title: '0', onPress: () => inputDigit('0') }))
    );
  };
};
// 棱跃（Prism Leap）：沙箱内的横版跳跃闯关
//
// 渲染约束（实测结论）：
// - 沙箱只有 RN 白名单组件，没有 Canvas/WebGL，画面全部由 View 拼几何色块；
// - 每帧只更新「镜头容器 + 玩家 + 少量敌人」这几个节点，静态地形一次挂载不再动，
//   否则每帧几十次原生更新会把帧率压到个位数（模拟器实测 5-9fps）。
// - 所有运动由 requestAnimationFrame + 定步长物理驱动，不依赖 Animated。
module.exports = function ({ React, RN, api }) {
  var View = RN.View;
  var Text = RN.Text;
  var StyleSheet = RN.StyleSheet;
  var TouchableOpacity = RN.TouchableOpacity;
  var ScrollView = RN.ScrollView;
  var BackHandler = RN.BackHandler;
  var C = React.createElement;

  var DESIGN_H = 360;
  var PW = 26;
  var PH = 32;
  var GRAVITY = 1750;
  var JUMP_V = -600;
  var MOVE_SPEED = 215;
  var MAX_FALL = 900;
  var COYOTE = 0.09;
  var JUMP_CUT = 190;
  var JUMP_BUFFER = 0.12;
  var STEP = 1 / 60;
  var PROGRESS_KEY = 'prismleap_progress_v1';

  // ---------------- 关卡数据（原创命名与布局） ----------------
  // 坐标以 360 高为基准，y 向下；ground 的 y 为地块顶部。
  var LEVELS = [
    {
      id: 'qingli',
      name: '青砾坡',
      subtitle: '沿着青色坡地学会起跳与踩踏',
      goalText: '目标：抵达坡顶的棱旗，尽量收齐 7 枚棱晶',
      sky: ['#07231f', '#0b3a34', '#12544a', '#1b6f60'],
      accent: '#5eead4',
      groundColor: '#123c34',
      platformColor: '#1e5f52',
      width: 2160,
      spawn: { x: 54, y: 262 },
      grounds: [
        { x: 0, y: 300, w: 520, h: 60 },
        { x: 620, y: 300, w: 420, h: 60 },
        { x: 1130, y: 300, w: 1030, h: 60 },
      ],
      platforms: [
        { x: 200, y: 236, w: 110, h: 16 },
        { x: 372, y: 188, w: 92, h: 14 },
        { x: 700, y: 224, w: 124, h: 16 },
        { x: 862, y: 168, w: 92, h: 14 },
        { x: 1180, y: 232, w: 140, h: 16 },
        { x: 1402, y: 186, w: 112, h: 14 },
        { x: 1600, y: 236, w: 124, h: 16 },
      ],
      hazards: [],
      enemies: [
        { type: 'crawler', x: 820, y: 278, from: 720, to: 1000 },
        { type: 'crawler', x: 1300, y: 278, from: 1200, to: 1400 },
        { type: 'crawler', x: 1760, y: 278, from: 1640, to: 1940 },
      ],
      coins: [
        { x: 244, y: 206 },
        { x: 412, y: 156 },
        { x: 756, y: 194 },
        { x: 902, y: 136 },
        { x: 1232, y: 202 },
        { x: 1452, y: 154 },
        { x: 1660, y: 206 },
      ],
      goal: { x: 2036, y: 300 },
      hint: '短按小跳、长按高跳；踩中锈壳虫可以弹起',
    },
    {
      id: 'xiutie',
      name: '锈铁回廊',
      subtitle: '断桥与棱刺之间，落点要果断',
      goalText: '目标：穿过锈铁回廊，收集 8 枚棱晶',
      sky: ['#241207', '#3d1f0c', '#5a2f12', '#74421c'],
      accent: '#fbbf24',
      groundColor: '#4a2a14',
      platformColor: '#74421c',
      width: 2420,
      spawn: { x: 46, y: 262 },
      grounds: [
        { x: 0, y: 300, w: 380, h: 60 },
        { x: 500, y: 300, w: 260, h: 60 },
        { x: 900, y: 300, w: 280, h: 60 },
        { x: 1320, y: 300, w: 380, h: 60 },
        { x: 1850, y: 300, w: 570, h: 60 },
      ],
      platforms: [
        { x: 150, y: 230, w: 100, h: 14 },
        { x: 400, y: 250, w: 70, h: 12 },
        { x: 600, y: 210, w: 92, h: 14 },
        { x: 780, y: 246, w: 96, h: 14 },
        { x: 1010, y: 206, w: 92, h: 14 },
        { x: 1200, y: 244, w: 96, h: 14 },
        { x: 1420, y: 214, w: 110, h: 14 },
        { x: 1600, y: 168, w: 92, h: 14 },
        { x: 1760, y: 236, w: 100, h: 14 },
        { x: 2000, y: 210, w: 120, h: 14 },
      ],
      hazards: [
        { x: 560, y: 288, w: 64, h: 12 },
        { x: 1450, y: 288, w: 72, h: 12 },
        { x: 1960, y: 288, w: 60, h: 12 },
      ],
      enemies: [
        { type: 'crawler', x: 930, y: 278, from: 900, to: 1150 },
        { type: 'crawler', x: 1380, y: 278, from: 1320, to: 1550 },
        { type: 'crawler', x: 2040, y: 278, from: 1900, to: 2200 },
        { type: 'floater', x: 830, y: 180, from: 760, to: 900 },
      ],
      coins: [
        { x: 196, y: 200 },
        { x: 430, y: 220 },
        { x: 640, y: 180 },
        { x: 1040, y: 176 },
        { x: 1240, y: 214 },
        { x: 1466, y: 184 },
        { x: 1640, y: 138 },
        { x: 2040, y: 180 },
      ],
      goal: { x: 2320, y: 300 },
      hint: '高处平台更安全，棱刺碰一下就会掉一条命',
    },
    {
      id: 'muzi',
      name: '暮紫塔阶',
      subtitle: '踩着浮石登塔，别在半空停太久',
      goalText: '目标：登上暮紫塔阶顶层，收集 9 枚棱晶',
      sky: ['#150a2b', '#241041', '#341a58', '#45236e'],
      accent: '#c4b5fd',
      groundColor: '#2b1a44',
      platformColor: '#452c6b',
      width: 2560,
      spawn: { x: 44, y: 262 },
      grounds: [
        { x: 0, y: 300, w: 460, h: 60 },
        { x: 660, y: 300, w: 300, h: 60 },
        { x: 1120, y: 300, w: 260, h: 60 },
        { x: 1560, y: 300, w: 300, h: 60 },
        { x: 2040, y: 300, w: 520, h: 60 },
      ],
      platforms: [
        { x: 230, y: 240, w: 96, h: 14 },
        { x: 380, y: 190, w: 86, h: 12 },
        { x: 540, y: 236, w: 80, h: 12 },
        { x: 760, y: 222, w: 92, h: 14 },
        { x: 900, y: 168, w: 88, h: 12 },
        { x: 1040, y: 226, w: 80, h: 12 },
        { x: 1240, y: 236, w: 92, h: 14 },
        { x: 1390, y: 182, w: 90, h: 12 },
        { x: 1530, y: 240, w: 84, h: 12 },
        { x: 1700, y: 226, w: 96, h: 14 },
        { x: 1860, y: 172, w: 92, h: 12 },
        { x: 2040, y: 222, w: 96, h: 14 },
        { x: 2200, y: 176, w: 100, h: 12 },
      ],
      hazards: [
        { x: 700, y: 288, w: 60, h: 12 },
        { x: 1160, y: 288, w: 64, h: 12 },
        { x: 1600, y: 288, w: 56, h: 12 },
        { x: 2140, y: 288, w: 64, h: 12 },
      ],
      enemies: [
        { type: 'crawler', x: 1180, y: 278, from: 1120, to: 1340 },
        { type: 'crawler', x: 1620, y: 278, from: 1560, to: 1800 },
        { type: 'crawler', x: 2240, y: 278, from: 2100, to: 2400 },
        { type: 'floater', x: 960, y: 150, from: 880, to: 1040 },
        { type: 'floater', x: 1900, y: 150, from: 1820, to: 1980 },
      ],
      coins: [
        { x: 274, y: 210 },
        { x: 420, y: 160 },
        { x: 576, y: 206 },
        { x: 800, y: 192 },
        { x: 942, y: 138 },
        { x: 1282, y: 206 },
        { x: 1434, y: 152 },
        { x: 1746, y: 196 },
        { x: 2244, y: 146 },
      ],
      goal: { x: 2440, y: 300 },
      hint: '塔阶间距更大，起跳前先走到平台边缘',
    },
  ];

  // ---------------- 存储 ----------------
  function defaultProgress() {
    return { unlocked: 1, best: {} };
  }

  function readProgress() {
    return api.storage
      .get(PROGRESS_KEY)
      .then(function (raw) {
        if (!raw) return defaultProgress();
        var data = JSON.parse(raw);
        var unlocked = Number(data && data.unlocked) || 1;
        if (unlocked < 1) unlocked = 1;
        if (unlocked > LEVELS.length) unlocked = LEVELS.length;
        return { unlocked: unlocked, best: (data && data.best) || {} };
      })
      .catch(function () {
        return defaultProgress();
      });
  }

  function writeProgress(data) {
    return api.storage
      .set(PROGRESS_KEY, JSON.stringify(data))
      .catch(function () {
        return null;
      });
  }

  // ---------------- 样式 ----------------
  var styles = StyleSheet.create({
    root: { flex: 1, overflow: 'hidden', backgroundColor: '#050b12' },
    world: { position: 'absolute', left: 0, top: 0 },
    band: { position: 'absolute', left: 0, right: 0 },
    blob: { position: 'absolute', borderRadius: 999 },
    block: { position: 'absolute', borderRadius: 4 },
    platform: { position: 'absolute', borderRadius: 5, borderTopWidth: 3 },
    hazard: { position: 'absolute', borderRadius: 2, backgroundColor: '#b91c1c', borderTopWidth: 2, borderTopColor: '#fecaca' },
    player: { position: 'absolute', borderRadius: 9, backgroundColor: '#f8fafc' },
    playerVisor: { position: 'absolute', left: 5, top: 7, width: 16, height: 9, borderRadius: 4, backgroundColor: '#0f172a' },
    playerCore: { position: 'absolute', left: 7, top: 4, width: 12, height: 5, borderRadius: 3, backgroundColor: '#a5f3fc' },
    crawler: { position: 'absolute', borderRadius: 9, backgroundColor: '#7c2d12' },
    crawlerShell: { position: 'absolute', left: 4, top: 3, right: 4, height: 6, borderRadius: 4, backgroundColor: '#f59e0b', opacity: 0.55 },
    eye: { position: 'absolute', top: 9, width: 4, height: 4, borderRadius: 2, backgroundColor: '#fef3c7' },
    floaterBody: { position: 'absolute', borderRadius: 14, borderWidth: 3, backgroundColor: 'rgba(15,23,42,0.55)' },
    floaterCore: { position: 'absolute', borderRadius: 5, backgroundColor: '#fca5a5' },
    coin: { position: 'absolute', width: 16, height: 16, borderRadius: 3, backgroundColor: '#fde68a' },
    coinCore: { position: 'absolute', left: 4, top: 4, width: 8, height: 8, borderRadius: 2, backgroundColor: '#fff7ed', opacity: 0.85 },
    goalPole: { position: 'absolute', width: 5, height: 92, borderRadius: 3, backgroundColor: '#e2e8f0' },
    goalFlag: { position: 'absolute', width: 30, height: 20, borderRadius: 4 },
    goalGlow: { position: 'absolute', width: 76, height: 76, borderRadius: 38, backgroundColor: '#34d399', opacity: 0.12 },
    hud: { position: 'absolute', left: 14, top: 10, right: 14, flexDirection: 'row', alignItems: 'center' },
    hudChip: { backgroundColor: 'rgba(2,6,23,0.55)', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 5, marginRight: 8 },
    hudText: { color: '#e2e8f0', fontSize: 12, fontWeight: '600' },
    life: { width: 10, height: 10, borderRadius: 3, backgroundColor: '#f472b6', marginRight: 4 },
    lifeOff: { backgroundColor: 'rgba(148,163,184,0.35)' },
    pauseBtn: { marginLeft: 'auto', backgroundColor: 'rgba(2,6,23,0.55)', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 5 },
    pad: {
      position: 'absolute',
      width: 76,
      height: 76,
      borderRadius: 38,
      borderWidth: 2,
      borderColor: 'rgba(226,232,240,0.45)',
      backgroundColor: 'rgba(15,23,42,0.34)',
      alignItems: 'center',
      justifyContent: 'center',
    },
    jumpPad: {
      position: 'absolute',
      width: 92,
      height: 92,
      borderRadius: 46,
      borderWidth: 2,
      borderColor: 'rgba(226,232,240,0.55)',
      backgroundColor: 'rgba(56,189,248,0.22)',
      alignItems: 'center',
      justifyContent: 'center',
    },
    padGlyph: { color: '#f8fafc', fontSize: 26, fontWeight: '700' },
    jumpGlyph: { color: '#f8fafc', fontSize: 22, fontWeight: '700' },
    overlay: { position: 'absolute', left: 0, top: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(2,6,23,0.72)' },
    card: { backgroundColor: 'rgba(9,17,30,0.94)', borderRadius: 18, paddingHorizontal: 22, paddingVertical: 18, borderWidth: 1, borderColor: 'rgba(148,163,184,0.25)', maxWidth: 520 },
    title: { color: '#f8fafc', fontSize: 30, fontWeight: '800', letterSpacing: 4 },
    subtitle: { color: '#94a3b8', fontSize: 12, marginTop: 6, lineHeight: 18 },
    section: { color: '#e2e8f0', fontSize: 15, fontWeight: '700', marginTop: 14, marginBottom: 6 },
    body: { color: '#cbd5f5', fontSize: 12, lineHeight: 19 },
    row: { flexDirection: 'row', alignItems: 'center', marginTop: 8 },
    btn: { borderRadius: 12, paddingHorizontal: 18, paddingVertical: 11, marginRight: 10, marginTop: 12, backgroundColor: '#38bdf8' },
    btnGhost: { backgroundColor: 'rgba(148,163,184,0.18)', borderWidth: 1, borderColor: 'rgba(148,163,184,0.35)' },
    btnPrimary: { backgroundColor: '#22d3ee' },
    btnText: { color: '#04121f', fontSize: 14, fontWeight: '800' },
    btnTextGhost: { color: '#e2e8f0', fontSize: 14, fontWeight: '700' },
    levelRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(148,163,184,0.1)', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 11, marginTop: 8, borderWidth: 1, borderColor: 'rgba(148,163,184,0.18)' },
    levelRowLocked: { opacity: 0.45 },
    levelIndex: { color: '#67e8f9', fontSize: 18, fontWeight: '800', width: 30 },
    levelName: { color: '#f1f5f9', fontSize: 15, fontWeight: '700' },
    levelMeta: { color: '#94a3b8', fontSize: 11, marginTop: 3 },
    landscapeHint: { color: '#67e8f9', fontSize: 12, marginTop: 8 },
    toast: { position: 'absolute', left: 0, right: 0, top: 56, alignItems: 'center' },
    toastBox: { backgroundColor: 'rgba(2,6,23,0.72)', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 7 },
    toastText: { color: '#fef3c7', fontSize: 12, fontWeight: '600' },
  });

  // ---------------- 物理辅助 ----------------
  function overlap(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  function clamp(v, lo, hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
  }

  function makeEnemy(def) {
    var size = def.type === 'floater' ? 26 : 28;
    var height = def.type === 'floater' ? 26 : 20;
    return {
      type: def.type,
      x: def.x,
      y: def.y,
      w: size,
      h: height,
      from: def.from == null ? def.x - 60 : def.from,
      to: def.to == null ? def.x + 60 : def.to,
      dir: 1,
      baseY: def.y,
      phase: Math.random() * 6.28,
      alive: true,
      squash: 1,
    };
  }

  function buildEngine(level, H) {
    var offset = H - DESIGN_H;
    function shift(list) {
      return list.map(function (item) {
        var copy = { x: item.x, y: item.y + offset, w: item.w, h: item.h };
        return copy;
      });
    }
    var solids = shift(level.grounds.concat(level.platforms));
    var hazards = shift(level.hazards);
    var coins = shift(level.coins).map(function (item) {
      return { x: item.x, y: item.y, w: 16, h: 16, taken: false };
    });
    var enemies = level.enemies.map(function (def) {
      var copy = { type: def.type, x: def.x, y: def.y + offset, from: def.from, to: def.to };
      return makeEnemy(copy);
    });
    return {
      level: level,
      H: H,
      offset: offset,
      solids: solids,
      hazards: hazards,
      coins: coins,
      enemies: enemies,
      goal: { x: level.goal.x, y: level.goal.y + offset - 88, w: 34, h: 92 },
      player: {
        x: level.spawn.x,
        y: level.spawn.y + offset,
        w: PW,
        h: PH,
        vx: 0,
        vy: 0,
        grounded: false,
        facing: 1,
        coyote: 0,
        buffer: 0,
        invuln: 0,
      },
      input: { left: false, right: false, jumpHeld: false, jumpQueued: false },
      cam: 0,
      lives: 3,
      coinsGot: 0,
      time: 0,
      finished: false,
    };
  }

  function stepPlayer(engine, dt) {
    var p = engine.player;
    var input = engine.input;
    var solids = engine.solids;

    if (input.left && !input.right) {
      p.vx = -MOVE_SPEED;
      p.facing = -1;
    } else if (input.right && !input.left) {
      p.vx = MOVE_SPEED;
      p.facing = 1;
    } else {
      p.vx = 0;
    }

    if (input.jumpQueued) {
      p.buffer = JUMP_BUFFER;
      input.jumpQueued = false;
    } else if (p.buffer > 0) {
      p.buffer -= dt;
    }

    if (p.coyote > 0) p.coyote -= dt;

    if (p.buffer > 0 && (p.grounded || p.coyote > 0)) {
      p.vy = JUMP_V;
      p.grounded = false;
      p.coyote = 0;
      p.buffer = 0;
    }

    if (!input.jumpHeld && p.vy < -JUMP_CUT) {
      p.vy = -JUMP_CUT;
    }

    p.vy += GRAVITY * dt;
    if (p.vy > MAX_FALL) p.vy = MAX_FALL;
    if (p.invuln > 0) p.invuln -= dt;

    // 横向移动 + 碰撞
    p.x += p.vx * dt;
    for (var i = 0; i < solids.length; i += 1) {
      var s = solids[i];
      if (overlap(p, s)) {
        if (p.vx > 0) p.x = s.x - p.w;
        else if (p.vx < 0) p.x = s.x + s.w;
        p.vx = 0;
      }
    }
    if (p.x < 0) p.x = 0;
    if (p.x + p.w > engine.level.width) p.x = engine.level.width - p.w;

    // 纵向移动 + 碰撞
    var wasGrounded = p.grounded;
    p.grounded = false;
    p.y += p.vy * dt;
    for (var j = 0; j < solids.length; j += 1) {
      var b = solids[j];
      if (overlap(p, b)) {
        if (p.vy > 0) {
          p.y = b.y - p.h;
          p.vy = 0;
          p.grounded = true;
        } else if (p.vy < 0) {
          p.y = b.y + b.h;
          p.vy = 0;
        }
      }
    }
    if (p.grounded) p.coyote = COYOTE;
    else if (wasGrounded && p.vy >= 0) p.coyote = COYOTE;

    // 棱刺
    for (var k = 0; k < engine.hazards.length; k += 1) {
      if (p.invuln <= 0 && overlap(p, engine.hazards[k])) {
        return 'hurt';
      }
    }

    // 掉落
    if (p.y > engine.H + 90) return 'fall';

    // 敌人
    for (var m = 0; m < engine.enemies.length; m += 1) {
      var e = engine.enemies[m];
      if (!e.alive) continue;
      if (!overlap(p, e)) continue;
      var feet = p.y + p.h;
      var stomp = p.vy > 40 && feet - e.y < e.h * 0.85;
      if (stomp && p.invuln <= 0) {
        e.alive = false;
        e.squash = 0.35;
        p.vy = -360;
        p.grounded = false;
      } else if (p.invuln <= 0) {
        return 'hurt';
      }
    }

    // 棱晶
    for (var n = 0; n < engine.coins.length; n += 1) {
      var c = engine.coins[n];
      if (c.taken) continue;
      if (overlap(p, c)) {
        c.taken = true;
        engine.coinsGot += 1;
      }
    }

    // 终点
    if (overlap(p, engine.goal)) {
      engine.finished = true;
      return 'clear';
    }

    // 镜头跟随
    var viewW = engine.viewW || 800;
    if (!isFinite(p.x) || !isFinite(p.y) || !isFinite(viewW)) {
      p.x = engine.level.spawn.x;
      p.y = engine.level.spawn.y + engine.offset;
      p.vx = 0;
      p.vy = 0;
    }
    // 左侧允许负镜头：让角色在关卡起点也停在 38% 处，不被左下方向键压住
    engine.cam = clamp(p.x + p.w / 2 - viewW * 0.38, -viewW * 0.38, Math.max(0, engine.level.width - viewW));

    return null;
  }

  function stepEnemies(engine, dt) {
    for (var i = 0; i < engine.enemies.length; i += 1) {
      var e = engine.enemies[i];
      if (!e.alive) continue;
      if (e.type === 'floater') {
        e.phase += dt * 2.4;
        e.y = e.baseY + Math.sin(e.phase) * 18;
        e.x += e.dir * 26 * dt;
        if (e.x < e.from) {
          e.x = e.from;
          e.dir = 1;
        } else if (e.x + e.w > e.to) {
          e.x = e.to - e.w;
          e.dir = -1;
        }
      } else {
        e.x += e.dir * 34 * dt;
        if (e.x < e.from) {
          e.x = e.from;
          e.dir = 1;
        } else if (e.x + e.w > e.to) {
          e.x = e.to - e.w;
          e.dir = -1;
        }
      }
    }
  }

  // ---------------- 组件 ----------------
  function Game() {
    var [layout, setLayout] = React.useState(null);
    var [phase, setPhase] = React.useState('home');
    var [levelIndex, setLevelIndex] = React.useState(0);
    var [progress, setProgress] = React.useState(defaultProgress());
    var [hud, setHud] = React.useState({ lives: 3, coins: 0, total: 0, name: '' });
    var [result, setResult] = React.useState({ coins: 0, total: 0, best: 0, isNewBest: false });

    var phaseRef = React.useRef('home');
    var engineRef = React.useRef(null);
    var layoutRef = React.useRef(null);
    var progressRef = React.useRef(progress);
    var levelIndexRef = React.useRef(0);
    var worldRef = React.useRef(null);
    var playerRef = React.useRef(null);
    var enemyRefs = React.useRef([]);
    var coinRefs = React.useRef([]);
    var padRefs = React.useRef({ left: null, right: null, jump: null });
    var hudRef = React.useRef({ lives: 3, coins: 0 });
    var frameRef = React.useRef({ raf: 0, last: 0, acc: 0, alive: true });

    layoutRef.current = layout;
    progressRef.current = progress;
    levelIndexRef.current = levelIndex;

    function changePhase(next) {
      phaseRef.current = next;
      setPhase(next);
    }

    function refreshHud(engine) {
      if (!engine) return;
      var prev = hudRef.current;
      if (prev.lives === engine.lives && prev.coins === engine.coinsGot) return;
      hudRef.current = { lives: engine.lives, coins: engine.coinsGot };
      setHud({ lives: engine.lives, coins: engine.coinsGot, total: engine.coins.length, name: engine.level.name });
    }

    function paint() {
      var engine = engineRef.current;
      if (!engine) return;
      if (!isFinite(engine.cam)) engine.cam = 0;
      if (worldRef.current && worldRef.current.setNativeProps) {
        worldRef.current.setNativeProps({ style: { transform: [{ translateX: -engine.cam }] } });
      }
      var p = engine.player;
      if (playerRef.current && playerRef.current.setNativeProps) {
        playerRef.current.setNativeProps({
          style: {
            opacity: p.invuln > 0 ? 0.45 : 1,
            transform: [{ translateX: p.x }, { translateY: p.y }, { scaleX: p.facing }],
          },
        });
      }
      for (var i = 0; i < engine.enemies.length; i += 1) {
        var el = enemyRefs.current[i];
        if (!el || !el.setNativeProps) continue;
        var e = engine.enemies[i];
        el.setNativeProps({
          style: {
            opacity: e.alive ? 1 : 0.25,
            transform: [
              { translateX: e.x },
              { translateY: e.y },
              { scaleY: e.alive ? 1 : e.squash },
            ],
          },
        });
      }
      for (var j = 0; j < engine.coins.length; j += 1) {
        var coinRef = coinRefs.current[j];
        if (!coinRef || !coinRef.setNativeProps) continue;
        var c = engine.coins[j];
        if (c.taken && !c.painted) {
          c.painted = true;
          coinRef.setNativeProps({ style: { opacity: 0 } });
        }
      }
    }

    function resetToSpawn(engine) {
      var p = engine.player;
      p.x = engine.level.spawn.x;
      p.y = engine.level.spawn.y + engine.offset;
      p.vx = 0;
      p.vy = 0;
      p.grounded = false;
      p.invuln = 1.2;
      p.buffer = 0;
      p.coyote = 0;
      engine.cam = 0;
      engine.input.left = false;
      engine.input.right = false;
      engine.input.jumpHeld = false;
      engine.input.jumpQueued = false;
    }

    function startLevel(index) {
      var H = (layoutRef.current && layoutRef.current.h) || DESIGN_H;
      var W = (layoutRef.current && layoutRef.current.w) || 640;
      var engine = buildEngine(LEVELS[index], H);
      engine.viewW = W;
      engineRef.current = engine;
      enemyRefs.current = [];
      coinRefs.current = [];
      hudRef.current = { lives: engine.lives, coins: 0 };
      setHud({ lives: engine.lives, coins: 0, total: engine.coins.length, name: engine.level.name });
      setLevelIndex(index);
      changePhase('playing');
    }

    function finishLevel(engine) {
      var level = engine.level;
      var total = engine.coins.length;
      var earned = engine.coinsGot;
      var current = progressRef.current;
      var bestPrev = (current.best && current.best[level.id]) || 0;
      var best = Math.max(bestPrev, earned);
      var nextUnlocked = Math.max(current.unlocked, Math.min(LEVELS.length, levelIndexRef.current + 2));
      var merged = {};
      Object.keys(current.best || {}).forEach(function (key) {
        merged[key] = current.best[key];
      });
      merged[level.id] = best;
      var next = { unlocked: nextUnlocked, best: merged };
      progressRef.current = next;
      setProgress(next);
      writeProgress(next);
      setResult({ coins: earned, total: total, best: best, isNewBest: earned > bestPrev });
      changePhase('clear');
    }

    function handleDeath(reason) {
      var engine = engineRef.current;
      if (!engine) return;
      engine.lives -= 1;
      refreshHud(engine);
      if (engine.lives <= 0) {
        changePhase('fail');
        return;
      }
      resetToSpawn(engine);
    }

    // 物理与渲染循环
    React.useEffect(function () {
      var frame = frameRef.current;
      function tick(now) {
        if (!frame.alive) return;
        var ts = typeof now === 'number' ? now : Date.now();
        if (!frame.last) frame.last = ts;
        var dt = (ts - frame.last) / 1000;
        frame.last = ts;
        if (dt > 0.1) dt = 0.1;

        var engine = engineRef.current;
        if (engine && phaseRef.current === 'playing') {
          frame.acc += dt;
          var guard = 0;
          while (frame.acc >= STEP && guard < 4) {
            frame.acc -= STEP;
            guard += 1;
            stepEnemies(engine, STEP);
            var event = stepPlayer(engine, STEP);
            engine.time += STEP;
            if (event === 'hurt' || event === 'fall') {
              handleDeath(event);
              break;
            }
            if (event === 'clear') {
              finishLevel(engine);
              break;
            }
          }
          if (frame.acc > STEP * 4) frame.acc = 0;
          paint();
          refreshHud(engine);
        }
        frame.raf = requestAnimationFrame(tick);
      }
      frame.raf = requestAnimationFrame(tick);
      return function () {
        frame.alive = false;
        cancelAnimationFrame(frame.raf);
      };
    }, []);

    React.useEffect(function () {
      readProgress().then(function (data) {
        setProgress(data);
      });
    }, []);

    React.useEffect(function () {
      var sub = BackHandler.addEventListener('hardwareBackPress', function () {
        var current = phaseRef.current;
        if (current === 'playing') {
          changePhase('paused');
          return true;
        }
        if (current === 'paused') {
          changePhase('playing');
          return true;
        }
        if (current === 'select' || current === 'clear' || current === 'fail') {
          changePhase('home');
          return true;
        }
        return false;
      });
      return function () {
        if (sub && sub.remove) sub.remove();
      };
    }, []);

    function setPadVisual(name, active) {
      var el = padRefs.current[name];
      if (!el || !el.setNativeProps) return;
      var base = name === 'jump' ? styles.jumpPad : styles.pad;
      el.setNativeProps({
        style: [
          base,
          active ? { backgroundColor: 'rgba(56,189,248,0.55)', borderColor: '#e0f2fe' } : null,
        ],
      });
    }

    function pressDir(dir, active) {
      var engine = engineRef.current;
      if (!engine || phaseRef.current !== 'playing') return;
      if (dir < 0) engine.input.left = active;
      else engine.input.right = active;
      setPadVisual(dir < 0 ? 'left' : 'right', active);
    }

    function pressJump(active) {
      var engine = engineRef.current;
      if (!engine || phaseRef.current !== 'playing') return;
      engine.input.jumpHeld = active;
      if (active) engine.input.jumpQueued = true;
      setPadVisual('jump', active);
    }

    // ---------------- 渲染片段 ----------------
    var cardMaxH = (layout ? layout.h : DESIGN_H) - 26;

    function renderSky(level) {
      var H = (layout && layout.h) || DESIGN_H;
      var W = (layout && layout.w) || 640;
      var bands = [];
      var colors = level.sky;
      var bandH = H / colors.length;
      for (var i = 0; i < colors.length; i += 1) {
        bands.push(C(View, {
          key: 'band' + i,
          style: [styles.band, { top: bandH * i, height: bandH + 1, backgroundColor: colors[i] }],
        }));
      }
      bands.push(C(View, { key: 'glowA', style: [styles.blob, { left: W * 0.08, top: H * 0.1, width: 160, height: 160, backgroundColor: level.accent, opacity: 0.08 }] }));
      bands.push(C(View, { key: 'glowB', style: [styles.blob, { left: W * 0.62, top: -40, width: 220, height: 220, backgroundColor: level.accent, opacity: 0.05 }] }));
      return bands;
    }

    function renderStatic(engine) {
      var nodes = [];
      var level = engine.level;
      var accent = level.accent;

      for (var g = 0; g < level.grounds.length; g += 1) {
        var gr = level.grounds[g];
        nodes.push(C(View, {
          key: 'g' + g,
          style: [styles.block, {
            left: gr.x,
            top: gr.y + engine.offset,
            width: gr.w,
            height: gr.h,
            backgroundColor: level.groundColor,
            borderTopWidth: 3,
            borderTopColor: accent,
          }],
        }));
      }

      for (var p = 0; p < level.platforms.length; p += 1) {
        var pf = level.platforms[p];
        nodes.push(C(View, {
          key: 'p' + p,
          style: [styles.platform, {
            left: pf.x,
            top: pf.y + engine.offset,
            width: pf.w,
            height: pf.h,
            backgroundColor: level.platformColor || level.groundColor,
            borderTopColor: accent,
          }],
        }));
      }

      for (var hz = 0; hz < engine.hazards.length; hz += 1) {
        var hazard = engine.hazards[hz];
        nodes.push(C(View, {
          key: 'hz' + hz,
          style: [styles.hazard, { left: hazard.x, top: hazard.y, width: hazard.w, height: hazard.h }],
        }));
      }

      for (var c = 0; c < engine.coins.length; c += 1) {
        var coin = engine.coins[c];
        nodes.push(C(View, {
          key: 'c' + c,
          ref: (function (idx) {
            return function (el) {
              coinRefs.current[idx] = el;
            };
          })(c),
          style: [styles.coin, {
            left: coin.x,
            top: coin.y,
            backgroundColor: accent,
            transform: [{ rotate: '45deg' }],
          }],
        }, C(View, { style: styles.coinCore })));
      }

      for (var e = 0; e < engine.enemies.length; e += 1) {
        var enemy = engine.enemies[e];
        var children = [];
        if (enemy.type === 'floater') {
          children.push(C(View, {
            key: 'fb',
            style: [styles.floaterBody, {
              width: enemy.w,
              height: enemy.h,
              borderColor: accent,
            }],
          }, C(View, { style: [styles.floaterCore, { left: 8, top: 8, width: 8, height: 8 }] })));
        } else {
          children.push(C(View, {
            key: 'cb',
            style: [styles.crawler, { width: enemy.w, height: enemy.h }],
          },
            C(View, { style: styles.crawlerShell }),
            C(View, { style: [styles.eye, { left: 6 }] }),
            C(View, { style: [styles.eye, { right: 6 }] })
          ));
        }
        nodes.push(C(View, {
          key: 'e' + e,
          ref: (function (idx) {
            return function (el) {
              enemyRefs.current[idx] = el;
            };
          })(e),
          style: { position: 'absolute', left: 0, top: 0, transform: [{ translateX: enemy.x }, { translateY: enemy.y }] },
        }, children));
      }

      var goal = engine.goal;
      nodes.push(C(View, {
        key: 'goalGlow',
        style: [styles.goalGlow, { left: goal.x - 24, top: goal.y - 46, backgroundColor: accent }],
      }));
      nodes.push(C(View, {
        key: 'goalPole',
        style: [styles.goalPole, { left: goal.x + 8, top: goal.y - 92, backgroundColor: '#e2e8f0' }],
      }));
      nodes.push(C(View, {
        key: 'goalFlag',
        style: [styles.goalFlag, { left: goal.x + 13, top: goal.y - 88, backgroundColor: accent }],
      }));

      return nodes;
    }

    function renderPlayer() {
      return C(View, {
        key: 'player',
        ref: playerRef,
        style: [styles.player, { left: 0, top: 0, width: PW, height: PH, transform: [{ translateX: 0 }, { translateY: 0 }] }],
      },
        C(View, { style: styles.playerCore }),
        C(View, { style: styles.playerVisor })
      );
    }

    function renderPads() {
      var leftPad = C(View, {
        key: 'padLeft',
        ref: function (el) { padRefs.current.left = el; },
        style: [styles.pad, { left: 20, bottom: 22 }],
        onStartShouldSetResponder: function () { return true; },
        onResponderTerminationRequest: function () { return false; },
        onResponderGrant: function () { pressDir(-1, true); },
        onResponderRelease: function () { pressDir(-1, false); },
        onResponderTerminate: function () { pressDir(-1, false); },
      }, C(Text, { style: styles.padGlyph }, '◀'));

      var rightPad = C(View, {
        key: 'padRight',
        ref: function (el) { padRefs.current.right = el; },
        style: [styles.pad, { left: 112, bottom: 22 }],
        onStartShouldSetResponder: function () { return true; },
        onResponderTerminationRequest: function () { return false; },
        onResponderGrant: function () { pressDir(1, true); },
        onResponderRelease: function () { pressDir(1, false); },
        onResponderTerminate: function () { pressDir(1, false); },
      }, C(Text, { style: styles.padGlyph }, '▶'));

      var jumpPad = C(View, {
        key: 'padJump',
        ref: function (el) { padRefs.current.jump = el; },
        style: [styles.jumpPad, { right: 22, bottom: 18 }],
        onStartShouldSetResponder: function () { return true; },
        onResponderTerminationRequest: function () { return false; },
        onResponderGrant: function () { pressJump(true); },
        onResponderRelease: function () { pressJump(false); },
        onResponderTerminate: function () { pressJump(false); },
      }, C(Text, { style: styles.jumpGlyph }, '跃'));

      return [leftPad, rightPad, jumpPad];
    }

    function renderHud() {
      var lives = [];
      for (var i = 0; i < 3; i += 1) {
        lives.push(C(View, { key: 'life' + i, style: [styles.life, i >= hud.lives ? styles.lifeOff : null] }));
      }
      return C(View, { key: 'hud', style: styles.hud },
        C(View, { key: 'lives', style: styles.hudChip }, C(View, { style: { flexDirection: 'row' } }, lives)),
        C(View, { key: 'coins', style: styles.hudChip }, C(Text, { style: styles.hudText }, '棱晶 ' + hud.coins + '/' + hud.total)),
        C(View, { key: 'name', style: styles.hudChip }, C(Text, { style: styles.hudText }, hud.name)),
        C(TouchableOpacity, {
          key: 'pause',
          style: styles.pauseBtn,
          onPress: function () { changePhase('paused'); },
        }, C(Text, { style: styles.hudText }, '暂停'))
      );
    }

    function renderHome() {
      var portrait = layout && layout.w < layout.h;
      var compact = !layout || layout.h < 440;
      return C(View, { key: 'home', style: styles.overlay },
        C(ScrollView, { style: [styles.card, { maxHeight: cardMaxH }] },
          C(Text, { key: 't', style: [styles.title, compact ? { fontSize: 24 } : null] }, '棱 跃'),
          C(Text, { key: 's', style: styles.subtitle }, compact ? '跳跃 · 踩敌 · 收集棱晶 · 抵达棱旗' : '在折光坡地上跳跃、踩敌、收集棱晶，抵达棱旗。'),
          compact ? null : C(Text, { key: 'h1', style: styles.section }, '操作'),
          C(Text, { key: 'o', style: styles.body }, compact ? '左下 ◀ ▶ 移动，右下「跃」跳跃（短按小跳 / 长按高跳）。' : '左下 ◀ ▶ 移动；右下「跃」起跳。\n短按小跳，按住跳得更高；踩中敌人可弹起。'),
          compact ? null : C(Text, { key: 'h2', style: styles.section }, '进度'),
          compact ? null : C(Text, { key: 'g', style: styles.body }, '已解锁 ' + progress.unlocked + ' / ' + LEVELS.length + ' 关，最高收集会记在本机。'),
          portrait ? C(Text, { key: 'p', style: styles.landscapeHint }, '建议横屏游玩：旋转手机即可，布局会自动适配。') : null,
          C(View, { key: 'b', style: styles.row },
            C(TouchableOpacity, { style: [styles.btn, styles.btnPrimary], onPress: function () { startLevel(Math.min(progress.unlocked - 1, LEVELS.length - 1)); } },
              C(Text, { style: styles.btnText }, '开始')),
            C(TouchableOpacity, { style: [styles.btn, styles.btnGhost], onPress: function () { changePhase('select'); } },
              C(Text, { style: styles.btnTextGhost }, '选关')),
            C(TouchableOpacity, { style: [styles.btn, styles.btnGhost], onPress: function () { api.navigate.back(); } },
              C(Text, { style: styles.btnTextGhost }, '退出'))
          )
        )
      );
    }

    function renderSelect() {
      var rows = [];
      for (var i = 0; i < LEVELS.length; i += 1) {
        var lv = LEVELS[i];
        var unlocked = i < progress.unlocked;
        var best = (progress.best && progress.best[lv.id]) || 0;
        rows.push(C(TouchableOpacity, {
          key: lv.id,
          style: [styles.levelRow, unlocked ? null : styles.levelRowLocked],
          onPress: (function (idx) {
            return function () {
              if (idx < progress.unlocked) startLevel(idx);
            };
          })(i),
        },
          C(Text, { style: styles.levelIndex }, String(i + 1)),
          C(View, { style: { flex: 1 } },
            C(Text, { style: styles.levelName }, lv.name + (unlocked ? '' : '（未解锁）')),
            C(Text, { style: styles.levelMeta }, lv.goalText),
            C(Text, { style: styles.levelMeta }, unlocked ? '最高棱晶 ' + best + ' 枚' : '先通过上一关')
          )
        ));
      }
      return C(View, { key: 'select', style: styles.overlay },
        C(ScrollView, { style: [styles.card, { maxHeight: cardMaxH }] },
          C(Text, { style: styles.section }, '选择关卡'),
          C(Text, { style: styles.body }, '三关难度递增，通关后自动解锁下一关。'),
          rows,
          C(View, { style: styles.row },
            C(TouchableOpacity, { style: [styles.btn, styles.btnGhost], onPress: function () { changePhase('home'); } },
              C(Text, { style: styles.btnTextGhost }, '返回'))
          )
        )
      );
    }

    function renderPause() {
      return C(View, { key: 'paused', style: styles.overlay },
        C(ScrollView, { style: [styles.card, { maxHeight: cardMaxH }] },
          C(Text, { style: styles.section }, '已暂停'),
          C(Text, { style: styles.body }, '进度已保留在当前关卡，继续后从暂停处开始。'),
          C(View, { style: styles.row },
            C(TouchableOpacity, { style: [styles.btn, styles.btnPrimary], onPress: function () { changePhase('playing'); } },
              C(Text, { style: styles.btnText }, '继续')),
            C(TouchableOpacity, { style: [styles.btn, styles.btnGhost], onPress: function () { startLevel(levelIndex); } },
              C(Text, { style: styles.btnTextGhost }, '重来')),
            C(TouchableOpacity, { style: [styles.btn, styles.btnGhost], onPress: function () { changePhase('home'); } },
              C(Text, { style: styles.btnTextGhost }, '返回首页'))
          )
        )
      );
    }

    function renderClear() {
      var hasNext = levelIndex + 1 < LEVELS.length;
      return C(View, { key: 'clear', style: styles.overlay },
        C(ScrollView, { style: [styles.card, { maxHeight: cardMaxH }] },
          C(Text, { style: styles.title }, '过关'),
          C(Text, { style: styles.body }, LEVELS[levelIndex].name + ' · 棱晶 ' + result.coins + '/' + result.total + (result.isNewBest ? '（新纪录）' : '')),
          C(Text, { style: styles.body }, hasNext ? '已解锁下一关：' + LEVELS[levelIndex + 1].name : '三关全部完成，进度已保存。'),
          C(View, { style: styles.row },
            hasNext ? C(TouchableOpacity, { style: [styles.btn, styles.btnPrimary], onPress: function () { startLevel(levelIndex + 1); } },
              C(Text, { style: styles.btnText }, '下一关')) : null,
            C(TouchableOpacity, { style: [styles.btn, styles.btnGhost], onPress: function () { changePhase('select'); } },
              C(Text, { style: styles.btnTextGhost }, '选关')),
            C(TouchableOpacity, { style: [styles.btn, styles.btnGhost], onPress: function () { changePhase('home'); } },
              C(Text, { style: styles.btnTextGhost }, '返回首页'))
          )
        )
      );
    }

    function renderFail() {
      return C(View, { key: 'fail', style: styles.overlay },
        C(ScrollView, { style: [styles.card, { maxHeight: cardMaxH }] },
          C(Text, { style: styles.section }, '生命耗尽'),
          C(Text, { style: styles.body }, '本关重新开始会重置生命与棱晶，已通过的关卡进度不受影响。'),
          C(View, { style: styles.row },
            C(TouchableOpacity, { style: [styles.btn, styles.btnPrimary], onPress: function () { startLevel(levelIndex); } },
              C(Text, { style: styles.btnText }, '重试本关')),
            C(TouchableOpacity, { style: [styles.btn, styles.btnGhost], onPress: function () { changePhase('home'); } },
              C(Text, { style: styles.btnTextGhost }, '返回首页'))
          )
        )
      );
    }

    var engine = engineRef.current;
    var showWorld = engine && (phase === 'playing' || phase === 'paused' || phase === 'clear' || phase === 'fail');
    var currentLevel = showWorld ? engine.level : LEVELS[Math.min(levelIndex, LEVELS.length - 1)];

    var rootProps = {
      style: styles.root,
      onLayout: function (e) {
        var l = e.nativeEvent.layout;
        if (!l || !l.width) return;
        if (!layout || Math.abs(layout.w - l.width) > 1 || Math.abs(layout.h - l.height) > 1) {
          setLayout({ w: l.width, h: l.height });
          var engine = engineRef.current;
          if (engine) {
            engine.viewW = l.width;
            // 旋转后高度变化较大：按新尺寸重建当前关，避免地形错位
            if ((phaseRef.current === 'playing' || phaseRef.current === 'paused') && Math.abs(engine.H - l.height) > 24) {
              startLevel(levelIndexRef.current);
            }
          }
        }
      },
    };

    var inner = [];
    inner.push(C(View, {
      key: 'sky',
      style: { position: 'absolute', left: 0, top: 0, right: 0, bottom: 0 },
    }, renderSky(currentLevel)));

    if (showWorld) {
      inner.push(C(View, {
        key: 'world',
        ref: worldRef,
        style: [styles.world, { width: engine.level.width, height: engine.H }],
      }, renderStatic(engine).concat([renderPlayer()])));
    }
    inner.push(C(View, { key: 'hudLayer', style: { position: 'absolute', left: 0, top: 0, right: 0, bottom: 0 }, pointerEvents: 'box-none' },
      (phase === 'playing' || phase === 'paused') && engine ? renderHud() : null,
      phase === 'playing' ? renderPads() : null
    ));

    if (phase === 'home') inner.push(renderHome());
    if (phase === 'select') inner.push(renderSelect());
    if (phase === 'paused') inner.push(renderPause());
    if (phase === 'clear') inner.push(renderClear());
    if (phase === 'fail') inner.push(renderFail());

    return C(View, rootProps, inner);
  }

  return Game;
};

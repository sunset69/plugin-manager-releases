module.exports = function({ React, RN, api }) {
  const { View, Text, TextInput, Button, StyleSheet, ScrollView, TouchableOpacity } = RN;
  const styles = StyleSheet.create({
    container: { flex: 1, padding: 16, backgroundColor: '#fff' },
    input: { borderWidth: 1, borderColor: '#ddd', padding: 12, marginBottom: 12, borderRadius: 6, fontSize: 16 },
    noteRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fffbe6', borderRadius: 6, marginBottom: 8, borderWidth: 1, borderColor: '#ffe58f', padding: 12 },
    noteText: { fontSize: 16, flex: 1 },
    delBtn: { color: '#ff4d4f', fontSize: 16, fontWeight: '600', paddingHorizontal: 8 },
  });
  return function Notes() {
    const [notes, setNotes] = React.useState([]);
    const [text, setText] = React.useState('');
    React.useEffect(() => {
      api.storage.get('notes').then((saved) => {
        if (saved) setNotes(JSON.parse(saved));
      }).catch(() => {});
    }, []);
    const addNote = () => {
      if (!text.trim()) return;
      const next = [{ id: Date.now(), text: text.trim() }, ...notes];
      setNotes(next);
      api.storage.set('notes', JSON.stringify(next));
      setText('');
    };
    const removeNote = (id) => {
      const next = notes.filter((n) => n.id !== id);
      setNotes(next);
      api.storage.set('notes', JSON.stringify(next));
    };
    return React.createElement(View, { style: styles.container },
      React.createElement(TextInput, { style: styles.input, placeholder: '写点什么...', value: text, onChangeText: setText }),
      React.createElement(Button, { title: '添加笔记', onPress: addNote }),
      React.createElement(ScrollView, { style: { marginTop: 12 } },
        ...notes.map((n) => React.createElement(View, { key: n.id, style: styles.noteRow },
          React.createElement(Text, { style: styles.noteText }, n.text),
          React.createElement(TouchableOpacity, { onPress: () => removeNote(n.id) },
            React.createElement(Text, { style: styles.delBtn }, '删除')))))
    );
  };
};
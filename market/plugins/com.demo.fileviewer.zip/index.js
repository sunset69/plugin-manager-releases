// 文件预览插件
//
// 设计目标（可扩展）：文件类型识别与渲染彻底分开。
// - 每种类型是一个「渲染器」，通过 registerRenderer 注册：匹配规则 + 渲染实现 + 是否可编辑；
// - 主流程只做「选文件 → 找渲染器 → 渲染」，新增类型只加一个注册项，不改主流程；
// - 没有匹配的渲染器时，自动落到 external 渲染器，明确告知交给系统应用打开及原因。
//
// 能力边界（不假装能预览）：
// - 文本 / 代码 / Markdown：在 App 内渲染并支持编辑、覆盖保存与另存；
// - 图片 / 漫画目录：在 App 内渲染，支持翻页、连续滚动与双指缩放；
// - PDF / Word / Excel / PPT / 音视频 / 未知格式：交给系统应用打开，界面写明原因。
module.exports = function ({ React, RN, api }) {
  const {
    View,
    Text,
    Button,
    TextInput,
    ScrollView,
    StyleSheet,
    Image,
    TouchableOpacity,
    FlatList,
    ActivityIndicator,
    Alert,
    BackHandler,
    ZoomableImage,
  } = RN;
  const h = React.createElement;

  const COLOR = {
    bg: '#0f1115',
    card: '#171a21',
    card2: '#1e222b',
    text: '#e8eaed',
    dim: '#9aa0a6',
    accent: '#4c8dff',
    border: '#2a2e39',
    ok: '#3ddc97',
    warn: '#ffb454',
    danger: '#ff6b6b',
  };

  const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: COLOR.bg },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 12,
      paddingVertical: 10,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: COLOR.border,
      backgroundColor: COLOR.card,
    },
    headerTitle: { color: COLOR.text, fontSize: 15, fontWeight: '600' },
    headerSub: { color: COLOR.dim, fontSize: 11, marginTop: 2 },
    body: { flex: 1 },
    home: { padding: 14 },
    hero: { color: COLOR.text, fontSize: 20, fontWeight: '700', marginBottom: 4 },
    heroSub: { color: COLOR.dim, fontSize: 13, lineHeight: 19, marginBottom: 16 },
    card: {
      backgroundColor: COLOR.card,
      borderRadius: 10,
      borderWidth: StyleSheet.hairlineWidth,
      borderColor: COLOR.border,
      padding: 12,
      marginBottom: 12,
    },
    cardTitle: { color: COLOR.text, fontSize: 14, fontWeight: '600', marginBottom: 8 },
    row: { flexDirection: 'row', alignItems: 'center' },
    spacer: { height: 8 },
    btnRow: { marginBottom: 8 },
    note: { color: COLOR.dim, fontSize: 12, lineHeight: 18 },
    badge: {
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 10,
      fontSize: 11,
      overflow: 'hidden',
    },
    banner: { paddingHorizontal: 12, paddingVertical: 8, fontSize: 12 },
    listItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 9,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: COLOR.border,
    },
    itemName: { color: COLOR.text, fontSize: 13, flex: 1 },
    itemMeta: { color: COLOR.dim, fontSize: 11, marginTop: 2 },
    itemAction: { color: COLOR.accent, fontSize: 12, paddingHorizontal: 6, paddingVertical: 4 },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
    errTitle: { color: COLOR.text, fontSize: 15, fontWeight: '600', marginBottom: 6, textAlign: 'center' },
    errMsg: { color: COLOR.dim, fontSize: 13, lineHeight: 20, textAlign: 'center', marginBottom: 14 },
    errActions: { alignSelf: 'stretch' },
    textBox: {
      flex: 1,
      color: COLOR.text,
      fontSize: 13,
      lineHeight: 19,
      fontFamily: 'monospace',
      padding: 12,
      textAlignVertical: 'top',
    },
    readerScroll: { padding: 12 },
    readerText: { color: COLOR.text, fontSize: 13, lineHeight: 20, fontFamily: 'monospace' },
    toolbar: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 8,
      paddingVertical: 8,
      borderTopWidth: StyleSheet.hairlineWidth,
      borderTopColor: COLOR.border,
      backgroundColor: COLOR.card,
    },
    toolbarInfo: { color: COLOR.dim, fontSize: 12, flex: 1, paddingHorizontal: 6 },
    chip: {
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 14,
      backgroundColor: COLOR.card2,
      marginLeft: 6,
    },
    chipText: { color: COLOR.text, fontSize: 12 },
    chipActive: { backgroundColor: COLOR.accent },
    chipTextActive: { color: '#fff' },
    imageWrap: { flex: 1, backgroundColor: '#000' },
    comicPage: { height: 460, marginBottom: 6, backgroundColor: '#000' },
    infoLine: { color: COLOR.dim, fontSize: 12, lineHeight: 18 },
    strong: { color: COLOR.text, fontSize: 13, fontWeight: '600' },
  });

  // ============ 通用工具 ============

  function errMsg(e) {
    return (e && e.message) || String(e || '未知错误');
  }

  function errCode(e) {
    return (e && e.code) || '';
  }

  function extOf(name) {
    const text = String(name || '');
    const dot = text.lastIndexOf('.');
    if (dot < 0) return '';
    return text.slice(dot + 1).toLowerCase();
  }

  function sizeLabel(bytes) {
    const n = Number(bytes) || 0;
    if (n >= 1024 * 1024 * 1024) return (n / 1024 / 1024 / 1024).toFixed(1) + 'GB';
    if (n >= 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + 'MB';
    if (n >= 1024) return (n / 1024).toFixed(1) + 'KB';
    return n + 'B';
  }

  const TEXT_EXT = [
    'txt', 'text', 'md', 'markdown', 'log', 'csv', 'json', 'xml', 'yml', 'yaml',
    'ini', 'conf', 'cfg', 'properties', 'toml', 'env', 'gitignore',
    'js', 'jsx', 'mjs', 'cjs', 'ts', 'tsx', 'css', 'scss', 'less', 'html', 'htm',
    'vue', 'svelte', 'py', 'java', 'kt', 'kts', 'c', 'h', 'cpp', 'hpp', 'cs',
    'go', 'rs', 'rb', 'php', 'sql', 'sh', 'bash', 'zsh', 'bat', 'cmd', 'ps1',
    'gradle', 'swift', 'm', 'mm', 'r', 'lua', 'pl',
  ];

  const IMAGE_EXT = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'heic', 'heif', 'avif'];

  // 文本渲染上限：一次性把几 MB 文本塞进 Text 组件会卡住 JS 线程，
  // 预览按块追加；超过上限时禁用编辑，避免输入框同样卡顿。
  const PREVIEW_CHUNK = 30000;
  const EDIT_CHAR_LIMIT = 300000;

  const TYPE_LABEL = {
    pdf: 'PDF 文档',
    doc: 'Word 文档', docx: 'Word 文档', rtf: 'RTF 文档', odt: 'ODT 文档',
    xls: 'Excel 表格', xlsx: 'Excel 表格', ods: 'ODS 表格', csv: 'CSV 表格',
    ppt: 'PPT 演示文稿', pptx: 'PPT 演示文稿', odp: 'ODP 演示文稿',
    epub: 'EPUB 电子书', mobi: 'MOBI 电子书',
    zip: '压缩包', rar: '压缩包', '7z': '压缩包', tar: '压缩包', gz: '压缩包',
    apk: '安装包',
    mp3: '音频', m4a: '音频', wav: '音频', flac: '音频', ogg: '音频', aac: '音频', amr: '音频',
    mp4: '视频', mkv: '视频', avi: '视频', mov: '视频', webm: '视频', '3gp': '视频', m4v: '视频',
  };

  function typeLabel(file) {
    if (file && file.isDirectory) return '图片目录（漫画 / 多图）';
    const name = (file && file.name) || '';
    const ext = extOf(name);
    if (TYPE_LABEL[ext]) return TYPE_LABEL[ext];
    if (ext) return ext.toUpperCase() + ' 文件';
    return '未知类型文件';
  }

  function isImageFile(file) {
    if (!file) return false;
    const mime = String(file.mime || '');
    if (mime.indexOf('image/') === 0) return true;
    return IMAGE_EXT.indexOf(extOf(file.name)) >= 0;
  }

  // 文件名自然排序：2.jpg 排在 10.jpg 之前
  function naturalParts(name) {
    return String(name || '').toLowerCase().match(/(\d+|\D+)/g) || [];
  }

  function naturalCompare(a, b) {
    const pa = naturalParts(a && a.name ? a.name : a);
    const pb = naturalParts(b && b.name ? b.name : b);
    const n = Math.min(pa.length, pb.length);
    let i = 0;
    for (i = 0; i < n; i += 1) {
      const x = pa[i];
      const y = pb[i];
      const xNum = /^\d+$/.test(x);
      const yNum = /^\d+$/.test(y);
      if (xNum && yNum) {
        const d = parseInt(x, 10) - parseInt(y, 10);
        if (d !== 0) return d;
      } else if (x !== y) {
        return x < y ? -1 : 1;
      }
    }
    return pa.length - pb.length;
  }

  // ============ 渲染器注册表（扩展点） ============

  const RENDERERS = [];

  /**
   * 注册一个渲染器。新增文件类型时只需要在这里加一项，不需要改主流程。
   * @param {{id:string, label:string, editable:boolean, priority:number,
   *          match:function(Object):boolean, Component:function}} renderer
   */
  function registerRenderer(renderer) {
    RENDERERS.push(renderer);
    RENDERERS.sort(function (a, b) {
      return (b.priority || 0) - (a.priority || 0);
    });
  }

  function resolveRenderer(file) {
    for (let i = 0; i < RENDERERS.length; i += 1) {
      const r = RENDERERS[i];
      try {
        if (r.match(file)) return r;
      } catch (e) {
        // 单个渲染器匹配异常不影响其他类型
      }
    }
    return null;
  }

  function rendererModeLabel(renderer) {
    if (!renderer) return '未匹配渲染器';
    if (renderer.id === 'external') return '交给系统应用';
    return renderer.editable ? '可编辑' : '只读 · 不支持编辑';
  }

  // ============ 通用组件 ============

  function Badge(props) {
    const tone = props.tone || 'dim';
    const bg = tone === 'ok' ? '#153a2b' : tone === 'warn' ? '#3a2f14' : tone === 'accent' ? '#16294d' : COLOR.card2;
    const fg = tone === 'ok' ? COLOR.ok : tone === 'warn' ? COLOR.warn : tone === 'accent' ? '#9dc0ff' : COLOR.dim;
    return h(Text, { style: [styles.badge, { backgroundColor: bg, color: fg }] }, props.text);
  }

  function Banner(props) {
    if (!props.message) return null;
    const tone = props.tone || 'info';
    const bg = tone === 'error' ? '#3a1d1d' : tone === 'ok' ? '#153a2b' : '#1c2433';
    const fg = tone === 'error' ? '#ffb3b3' : tone === 'ok' ? COLOR.ok : '#a9c6ff';
    return h(Text, { style: [styles.banner, { backgroundColor: bg, color: fg }] }, props.message);
  }

  function ErrorPanel(props) {
    const error = props.error || {};
    const actions = props.actions || [];
    return h(
      View,
      { style: styles.center },
      h(Text, { style: styles.errTitle }, props.title || '打不开这个文件'),
      h(Text, { style: styles.errMsg }, errMsg(error)),
      h(
        View,
        { style: styles.errActions },
        actions.map(function (action, index) {
          return h(
            View,
            { key: action.label + index, style: styles.btnRow },
            h(Button, { title: action.label, onPress: action.onPress })
          );
        })
      )
    );
  }

  // ============ 渲染器 1：文本 / 代码 / Markdown（可编辑） ============

  function TextRenderer(props) {
    const file = props.file;
    const registerSave = props.registerSave;
    const onStateChange = props.onStateChange;

    const [status, setStatus] = React.useState('loading');
    const [error, setError] = React.useState(null);
    const [meta, setMeta] = React.useState(null);
    const [text, setText] = React.useState('');
    const [original, setOriginal] = React.useState('');
    const [mode, setMode] = React.useState('read');
    const [saving, setSaving] = React.useState(false);
    const [banner, setBanner] = React.useState(null);
    const [visibleChars, setVisibleChars] = React.useState(PREVIEW_CHUNK);

    const dirty = status === 'ready' && text !== original;
    const canEditNow = status === 'ready' && !!meta && !meta.truncated && text.length <= EDIT_CHAR_LIMIT;
    const stateRef = React.useRef({ text: '', original: '', meta: null });

    stateRef.current = { text: text, original: original, meta: meta };

    function load() {
      setStatus('loading');
      setError(null);
      api.preview
        .readText(file.uri, { maxBytes: 2 * 1024 * 1024 })
        .then(function (result) {
          const content = result.text || '';
          setMeta(result);
          setText(content);
          setOriginal(content);
          setVisibleChars(PREVIEW_CHUNK);
          setStatus('ready');
          if (result.truncated) {
            setBanner({ tone: 'warn', message: '文件较大，仅加载前 2MB。为避免截断写回，已禁用编辑；可另存副本或用系统应用打开。' });
          } else if (content.length > EDIT_CHAR_LIMIT) {
            setBanner({ tone: 'warn', message: '文本较长（共 ' + content.length + ' 字符），为保证流畅已禁用编辑；可用系统应用打开。' });
          } else if (result.hadBom) {
            setBanner({ tone: 'info', message: '文件含 UTF-8 BOM，保存时会保留。换行：' + (result.lineEnding === 'crlf' ? 'CRLF' : 'LF') });
          } else {
            setBanner({ tone: 'info', message: '编码 UTF-8　换行 ' + (result.lineEnding === 'crlf' ? 'CRLF' : 'LF') + '　' + sizeLabel(result.size) });
          }
        })
        .catch(function (e) {
          setError(e);
          setStatus('error');
        });
    }

    React.useEffect(function () {
      load();
    }, [file.uri]);

    React.useEffect(function () {
      onStateChange({ dirty: dirty, mode: mode, editable: canEditNow });
    }, [dirty, mode, canEditNow]);

    function writeTo(targetUri, targetName) {
      const m = stateRef.current.meta || {};
      return api.preview.saveText(targetUri, stateRef.current.text, {
        lineEnding: m.lineEnding || 'lf',
        hadBom: !!m.hadBom,
      });
    }

    function doSave() {
      const m = stateRef.current.meta || {};
      setSaving(true);
      return writeTo(file.uri)
        .then(function (result) {
          setOriginal(stateRef.current.text);
          setSaving(false);
          setBanner({ tone: 'ok', message: '已覆盖保存：' + sizeLabel(result.bytes) + '（' + (m.lineEnding === 'crlf' ? 'CRLF' : 'LF') + '）' });
          return true;
        })
        .catch(function (e) {
          setSaving(false);
          setBanner({ tone: 'error', message: '保存失败：' + errMsg(e) });
          return false;
        });
    }

    React.useEffect(function () {
      if (registerSave) {
        registerSave(function () {
          if (!dirty) return Promise.resolve(true);
          return doSave();
        });
      }
    }, [dirty]);

    function askSave() {
      if (!dirty) return;
      Alert.alert('保存修改？', '将覆盖原文件：' + (file.name || ''), [
        { text: '取消', style: 'cancel' },
        {
          text: '另存为',
          onPress: function () {
            const m = stateRef.current.meta || {};
            api.preview
              .saveTextAs(file.name || '未命名.txt', stateRef.current.text, {
                lineEnding: m.lineEnding || 'lf',
                hadBom: !!m.hadBom,
              })
              .then(function (result) {
                setBanner({ tone: 'ok', message: '已另存为：' + (result.name || '新文件') });
              })
              .catch(function (e) {
                if (errCode(e) !== 'E_CANCELED') setBanner({ tone: 'error', message: '另存失败：' + errMsg(e) });
              });
          },
        },
        { text: '覆盖保存', onPress: doSave },
      ]);
    }

    if (status === 'loading') {
      return h(
        View,
        { style: styles.center },
        h(ActivityIndicator, { color: COLOR.accent }),
        h(View, { style: styles.spacer }),
        h(Text, { style: styles.note }, '正在读取 ' + (file.name || '文件') + '…')
      );
    }

    if (status === 'error') {
      const code = errCode(error);
      const actions = [];
      actions.push({ label: '用系统应用打开', onPress: props.openExternal });
      actions.push({ label: '重新选择文件', onPress: props.pickAgain });
      return h(ErrorPanel, {
        error: error,
        title: code === 'E_NON_UTF8' ? '不是 UTF-8 编码' : code === 'E_BINARY' ? '这不是文本文件' : '读取失败',
        actions: actions,
      });
    }

    const canEdit = canEditNow;
    const visibleText = text.length > visibleChars ? text.slice(0, visibleChars) : text;
    return h(
      View,
      { style: { flex: 1 } },
      h(Banner, { tone: banner && banner.tone, message: banner && banner.message }),
      h(
        View,
        { style: { flexDirection: 'row', paddingHorizontal: 12, paddingVertical: 8, alignItems: 'center' } },
        canEdit
          ? h(
              TouchableOpacity,
              {
                style: [styles.chip, mode === 'read' ? styles.chipActive : null],
                onPress: function () { setMode('read'); },
              },
              h(Text, { style: [styles.chipText, mode === 'read' ? styles.chipTextActive : null] }, '预览')
            )
          : h(TouchableOpacity, { style: [styles.chip, styles.chipActive] }, h(Text, { style: [styles.chipText, styles.chipTextActive] }, '只读')),
        canEdit
          ? h(
              TouchableOpacity,
              {
                style: [styles.chip, mode === 'edit' ? styles.chipActive : null],
                onPress: function () { setMode('edit'); },
              },
              h(Text, { style: [styles.chipText, mode === 'edit' ? styles.chipTextActive : null] }, '编辑')
            )
          : null,
        h(Text, { style: [styles.toolbarInfo, { textAlign: 'right' }] }, dirty ? '未保存' : canEdit ? '' : meta.truncated ? '已截断，只读' : '文本过长，只读'),
        text.length > visibleChars
          ? h(
              TouchableOpacity,
              { style: styles.chip, onPress: function () { setVisibleChars(visibleChars + PREVIEW_CHUNK); } },
              h(Text, { style: styles.chipText }, '加载更多')
            )
          : null,
        h(
          TouchableOpacity,
          { style: styles.chip, onPress: askSave, disabled: !dirty },
          h(Text, { style: [styles.chipText, { color: dirty ? COLOR.accent : COLOR.dim }] }, saving ? '保存中…' : '保存')
        )
      ),
      mode === 'edit' && canEdit
        ? h(TextInput, {
            style: styles.textBox,
            value: text,
            onChangeText: setText,
            multiline: true,
            autoCapitalize: 'none',
            autoCorrect: false,
            spellCheck: false,
            editable: !saving,
            placeholder: '文件为空，开始输入…',
            placeholderTextColor: COLOR.dim,
            textAlignVertical: 'top',
          })
        : h(
            ScrollView,
            { style: { flex: 1 }, contentContainerStyle: styles.readerScroll },
            h(Text, { style: styles.readerText, selectable: true }, visibleText || '（空文件）'),
            text.length > visibleChars
              ? h(
                  TouchableOpacity,
                  {
                    style: { marginTop: 12, paddingVertical: 10, alignItems: 'center', backgroundColor: COLOR.card2, borderRadius: 8 },
                    onPress: function () { setVisibleChars(visibleChars + PREVIEW_CHUNK); },
                  },
                  h(Text, { style: { color: COLOR.accent, fontSize: 13 } }, '继续加载（剩余 ' + (text.length - visibleChars) + ' 字符）')
                )
              : null,
            h(Text, { style: [styles.note, { marginTop: 10 }] }, '共 ' + text.length + ' 字符' + (meta.truncated ? '（文件较大，仅加载前 2MB）' : ''))
          )
    );
  }

  // ============ 渲染器 2：图片（只读） ============

  function ImageViewer(props) {
    const file = props.file;
    const [status, setStatus] = React.useState('loading');
    const [error, setError] = React.useState(null);
    const [meta, setMeta] = React.useState(null);
    const [resetToken, setResetToken] = React.useState(0);

    React.useEffect(function () {
      setStatus('loading');
      setError(null);
      api.preview
        .prepareImage(file.uri)
        .then(function (result) {
          setMeta(result);
          setStatus('ready');
          setResetToken(function (n) { return n + 1; });
        })
        .catch(function (e) {
          setError(e);
          setStatus('error');
        });
    }, [file.uri]);

    if (status === 'loading') {
      return h(
        View,
        { style: styles.center },
        h(ActivityIndicator, { color: COLOR.accent }),
        h(View, { style: styles.spacer }),
        h(Text, { style: styles.note }, '正在加载图片…')
      );
    }

    if (status === 'error') {
      return h(ErrorPanel, {
        error: error,
        title: '图片打不开',
        actions: [
          { label: '用系统应用打开', onPress: props.openExternal },
          { label: '重新选择文件', onPress: props.pickAgain },
        ],
      });
    }

    return h(
      View,
      { style: { flex: 1 } },
      h(
        View,
        { style: styles.imageWrap },
        ZoomableImage
          ? h(ZoomableImage, { style: { flex: 1 }, source: meta.path, resetToken: resetToken })
          : h(Image, { style: { flex: 1 }, source: { uri: meta.uri }, resizeMode: 'contain' })
      ),
      h(
        View,
        { style: styles.toolbar },
        h(Text, { style: styles.toolbarInfo }, meta.width + '×' + meta.height + '　' + sizeLabel(meta.size)),
        props.onPrev ? h(TouchableOpacity, { style: styles.chip, onPress: props.onPrev }, h(Text, { style: styles.chipText }, '上一张')) : null,
        props.onNext ? h(TouchableOpacity, { style: styles.chip, onPress: props.onNext }, h(Text, { style: styles.chipText }, '下一张')) : null,
        h(
          TouchableOpacity,
          { style: styles.chip, onPress: function () { setResetToken(function (n) { return n + 1; }); } },
          h(Text, { style: styles.chipText }, ZoomableImage ? '还原缩放' : '重置')
        )
      )
    );
  }

  // ============ 渲染器 3：漫画 / 多图目录（只读） ============

  function ComicPage(props) {
    const page = props.page;
    const [meta, setMeta] = React.useState(null);
    const [failed, setFailed] = React.useState(false);

    React.useEffect(function () {
      let alive = true;
      setMeta(null);
      setFailed(false);
      api.preview
        .prepareImage(page.uri)
        .then(function (result) {
          if (alive) setMeta(result);
        })
        .catch(function () {
          if (alive) setFailed(true);
        });
      return function () {
        alive = false;
      };
    }, [page.uri]);

    if (failed) {
      return h(
        View,
        { style: [styles.comicPage, { alignItems: 'center', justifyContent: 'center' }] },
        h(Text, { style: styles.note }, '这一页读不了：' + page.name)
      );
    }
    if (!meta) {
      return h(
        View,
        { style: [styles.comicPage, { alignItems: 'center', justifyContent: 'center' }] },
        h(ActivityIndicator, { color: COLOR.accent })
      );
    }
    return h(
      View,
      { style: styles.comicPage },
      ZoomableImage
        ? h(ZoomableImage, { style: { flex: 1 }, source: meta.path })
        : h(Image, { style: { flex: 1 }, source: { uri: meta.uri }, resizeMode: 'contain' })
    );
  }

  function ComicViewer(props) {
    const file = props.file;
    const [status, setStatus] = React.useState('loading');
    const [error, setError] = React.useState(null);
    const [pages, setPages] = React.useState([]);
    const [index, setIndex] = React.useState(0);
    const [continuous, setContinuous] = React.useState(false);

    React.useEffect(function () {
      setStatus('loading');
      api.preview
        .listChildren(file.uri)
        .then(function (children) {
          const images = (children || [])
            .filter(function (item) {
              return !item.isDirectory && isImageFile(item);
            })
            .sort(naturalCompare);
          if (images.length === 0) {
            const e = new Error('该目录里没有可预览的图片（支持 jpg/png/webp/gif/bmp/heic 等）。请选择包含图片的文件夹');
            e.code = 'E_EMPTY';
            throw e;
          }
          setPages(images);
          setIndex(0);
          setStatus('ready');
        })
        .catch(function (e) {
          setError(e);
          setStatus('error');
        });
    }, [file.uri]);

    if (status === 'loading') {
      return h(
        View,
        { style: styles.center },
        h(ActivityIndicator, { color: COLOR.accent }),
        h(View, { style: styles.spacer }),
        h(Text, { style: styles.note }, '正在读取目录：' + (file.name || ''))
      );
    }

    if (status === 'error') {
      return h(ErrorPanel, {
        error: error,
        title: '目录读不了',
        actions: [
          { label: '重新选择文件夹', onPress: props.pickFolder },
          { label: '改选单个文件', onPress: props.pickAgain },
        ],
      });
    }

    if (continuous) {
      return h(
        View,
        { style: { flex: 1 } },
        h(
          View,
          { style: styles.toolbar },
          h(Text, { style: styles.toolbarInfo }, '共 ' + pages.length + ' 页　连续滚动'),
          h(TouchableOpacity, { style: [styles.chip, styles.chipActive], onPress: function () { setContinuous(false); } }, h(Text, { style: [styles.chipText, styles.chipTextActive] }, '翻页')),
          h(TouchableOpacity, { style: styles.chip, onPress: props.pickFolder }, h(Text, { style: styles.chipText }, '换目录'))
        ),
        h(
          ScrollView,
          { style: { flex: 1 } },
          pages.slice(0, 100).map(function (page) {
            return h(ComicPage, { key: page.uri, page: page });
          }),
          pages.length > 100
            ? h(Text, { style: [styles.note, { padding: 12 }] }, '连续滚动最多显示 100 页，剩余 ' + (pages.length - 100) + ' 页请用翻页模式。')
            : null
        )
      );
    }

    const current = pages[index];
    return h(
      View,
      { style: { flex: 1 } },
      h(
        View,
        { style: styles.imageWrap },
        h(ComicPage, { key: current.uri, page: current })
      ),
      h(
        View,
        { style: styles.toolbar },
        h(Text, { style: styles.toolbarInfo }, (index + 1) + ' / ' + pages.length + '　' + current.name),
        h(
          TouchableOpacity,
          { style: styles.chip, onPress: function () { if (index > 0) { setIndex(index - 1); } } },
          h(Text, { style: [styles.chipText, { color: index > 0 ? COLOR.text : COLOR.dim }] }, '上一页')
        ),
        h(
          TouchableOpacity,
          { style: styles.chip, onPress: function () { if (index < pages.length - 1) { setIndex(index + 1); } } },
          h(Text, { style: [styles.chipText, { color: index < pages.length - 1 ? COLOR.text : COLOR.dim }] }, '下一页')
        ),
        h(TouchableOpacity, { style: styles.chip, onPress: function () { setContinuous(true); } }, h(Text, { style: styles.chipText }, '连续'))
      )
    );
  }

  // ============ 渲染器 4：交给系统应用（PDF / Office / 音视频 / 未知） ============

  function ExternalViewer(props) {
    const file = props.file;
    const [status, setStatus] = React.useState('idle');
    const [error, setError] = React.useState(null);
    const label = typeLabel(file);

    function open() {
      setStatus('opening');
      setError(null);
      api.preview
        .openWithSystem(file.uri, file.mime)
        .then(function () {
          setStatus('opened');
        })
        .catch(function (e) {
          setStatus('error');
          setError(e);
        });
    }

    return h(
      View,
      { style: { flex: 1 } },
      h(
        ScrollView,
        { contentContainerStyle: { padding: 16 } },
        h(Text, { style: styles.hero }, label),
        h(Text, { style: styles.heroSub }, 'App 内不内置这类文件的渲染器，不会假装能预览。点下面的按钮交给手机里的系统应用打开。'),
        h(
          View,
          { style: styles.card },
          h(Text, { style: styles.cardTitle }, '文件信息'),
          h(Text, { style: styles.infoLine }, '文件名：' + (file.name || '未知')),
          h(Text, { style: styles.infoLine }, '类型：' + (file.mime || '未知') + '（' + sizeLabel(file.size) + '）'),
          file.isDirectory ? h(Text, { style: styles.infoLine }, '这是一个目录，可退回后选择「文件夹（漫画/多图）」入口') : null
        ),
        h(
          View,
          { style: styles.card },
          h(Text, { style: styles.cardTitle }, '为什么不能内置预览'),
          h(
            Text,
            { style: styles.infoLine },
            props.reason || 'PDF / Office 需要完整的排版与字体引擎，音视频需要解码器，这些能力不在插件沙箱里。为避免显示错版或空白，直接交给系统应用更可靠。'
          )
        ),
        status === 'error'
          ? h(Banner, { tone: 'error', message: errMsg(error) })
          : status === 'opened'
          ? h(Banner, { tone: 'ok', message: '已交给系统应用打开；返回后可以继续在这里选别的文件。' })
          : null,
        h(View, { style: styles.spacer }),
        h(Button, { title: '用系统应用打开', onPress: open }),
        h(View, { style: styles.spacer }),
        h(Button, { title: '重新选择文件', onPress: props.pickAgain })
      )
    );
  }

  // ============ 注册渲染器（按 priority 从高到低匹配） ============

  registerRenderer({
    id: 'comic',
    label: '漫画 / 多图目录',
    editable: false,
    priority: 400,
    match: function (file) {
      return !!file && !!file.isDirectory;
    },
    Component: ComicViewer,
  });

  registerRenderer({
    id: 'image',
    label: '图片',
    editable: false,
    priority: 300,
    match: function (file) {
      return isImageFile(file);
    },
    Component: ImageViewer,
  });

  registerRenderer({
    id: 'text',
    label: '文本 / 代码 / Markdown',
    editable: true,
    priority: 200,
    match: function (file) {
      if (!file) return false;
      if (TEXT_EXT.indexOf(extOf(file.name)) >= 0) return true;
      const mime = String(file.mime || '');
      return mime.indexOf('text/') === 0 || mime === 'application/json' || mime === 'application/xml';
    },
    Component: TextRenderer,
  });

  registerRenderer({
    id: 'external',
    label: '交给系统应用',
    editable: false,
    priority: -1000,
    match: function () {
      return true;
    },
    Component: ExternalViewer,
  });

  // ============ 最近打开 ============
  //
  // 只存 uri + 展示信息，不复制文件内容；uri 权限由宿主在系统选择器里持久化。
  const RECENT_KEY = 'fileviewer.recent.v1';
  const RECENT_MAX = 12;

  function readRecent() {
    return api.storage
      .get(RECENT_KEY)
      .then(function (raw) {
        if (!raw) return [];
        try {
          const list = JSON.parse(raw);
          return Array.isArray(list) ? list : [];
        } catch (e) {
          return [];
        }
      })
      .catch(function () {
        return [];
      });
  }

  function remember(file) {
    return readRecent().then(function (list) {
      const next = [
        { uri: file.uri, name: file.name, size: file.size, mime: file.mime, isDirectory: !!file.isDirectory, at: Date.now() },
      ].concat(
        list.filter(function (item) {
          return item.uri !== file.uri;
        })
      );
      return api.storage
        .set(RECENT_KEY, JSON.stringify(next.slice(0, RECENT_MAX)))
        .then(function () {
          return next.slice(0, RECENT_MAX);
        })
        .catch(function () {
          return next.slice(0, RECENT_MAX);
        });
    });
  }

  // ============ 主界面 ============

  function Home(props) {
    return h(
      ScrollView,
      { style: styles.screen, contentContainerStyle: styles.home },
      h(Text, { style: styles.hero }, '文件预览'),
      h(
        Text,
        { style: styles.heroSub },
        '在本机打开常见文件。文本可编辑保存，图片与漫画可缩放翻页；PDF、Office、音视频交给系统应用。'
      ),
      h(Banner, { tone: props.bannerTone, message: props.banner }),
      h(
        View,
        { style: styles.card },
        h(Text, { style: styles.cardTitle }, '打开文件'),
        h(View, { style: styles.btnRow }, h(Button, { title: '选择文件（支持多选）', onPress: props.onPickFiles })),
        h(View, { style: styles.btnRow }, h(Button, { title: '从下载目录选择', onPress: props.onPickDownload })),
        h(View, { style: styles.btnRow }, h(Button, { title: '选择文件夹（漫画 / 多图）', onPress: props.onPickFolder })),
        h(
          Text,
          { style: styles.note },
          '通过系统文件选择器授权，只读取你选中的文件，不申请存储权限、不扫描相册。大文件按上限读取，不会一次性整块进内存。'
        )
      ),
      h(
        View,
        { style: styles.card },
        h(Text, { style: styles.cardTitle }, '支持范围（写清楚，不糊弄）'),
        h(Text, { style: styles.infoLine }, '● 可编辑：txt、md、代码、json/xml/yml、日志等纯文本（UTF-8）'),
        h(Text, { style: styles.infoLine }, '● 只读预览：jpg/png/webp/gif/bmp/heic 图片，漫画目录按文件名自然排序'),
        h(Text, { style: styles.infoLine }, '● 交给系统应用：PDF、Word、Excel、PPT、音视频、压缩包、其它未知格式'),
        h(Text, { style: styles.infoLine }, '● 非 UTF-8 文本会明确提示，不会显示乱码，也不会在保存时破坏编码')
      ),
      h(
        View,
        { style: styles.card },
        h(Text, { style: styles.cardTitle }, '最近打开'),
        props.recent.length === 0
          ? h(Text, { style: styles.note }, '还没有记录。选一个文件开始。')
          : props.recent.map(function (item, index) {
              return h(
                View,
                { key: item.uri + index, style: styles.listItem },
                h(
                  View,
                  { style: { flex: 1 } },
                  h(Text, { style: styles.itemName }, item.name || '未知文件'),
                  h(Text, { style: styles.itemMeta }, (item.isDirectory ? '目录' : typeLabel(item)) + '　' + sizeLabel(item.size) + '　' + new Date(item.at).toLocaleString())
                ),
                h(TouchableOpacity, { onPress: function () { props.onOpenRecent(item); } }, h(Text, { style: styles.itemAction }, '打开')),
                h(TouchableOpacity, { onPress: function () { props.onRemoveRecent(item); } }, h(Text, { style: styles.itemAction }, '移除'))
              );
            })
      ),
      h(
        Text,
        { style: [styles.note, { textAlign: 'center', marginTop: 4, marginBottom: 20 }] },
        '新增文件类型 = 新增一个渲染器注册项，详见插件文档中的扩展说明'
      )
    );
  }

  function Viewer(props) {
    const file = props.file;
    const renderer = resolveRenderer(file);
    const [state, setState] = React.useState({ dirty: false, mode: 'read' });
    const saveHolder = React.useRef(null);
    const closeRef = React.useRef(function () {});

    function registerSave(fn) {
      saveHolder.current = fn;
    }

    function requestClose() {
      if (!state.dirty) {
        props.onClose();
        return;
      }
      Alert.alert('有未保存的修改', '退出前要先保存吗？不保存的修改会丢失。', [
        { text: '取消', style: 'cancel' },
        { text: '放弃修改', style: 'destructive', onPress: props.onClose },
        {
          text: '保存并退出',
          onPress: function () {
            const save = saveHolder.current;
            if (!save) {
              props.onClose();
              return;
            }
            Promise.resolve()
              .then(save)
              .then(function (ok) {
                if (ok) props.onClose();
              })
              .catch(function () {});
          },
        },
      ]);
    }

    closeRef.current = requestClose;

    React.useEffect(function () {
      const sub = BackHandler.addEventListener('hardwareBackPress', function () {
        closeRef.current();
        return true;
      });
      return function () {
        if (sub && sub.remove) sub.remove();
      };
    }, []);

    const Component = renderer ? renderer.Component : ExternalViewer;

    return h(
      View,
      { style: styles.screen },
      h(
        View,
        { style: styles.header },
        h(TouchableOpacity, { onPress: function () { closeRef.current(); }, style: { paddingRight: 10 } }, h(Text, { style: { color: COLOR.accent, fontSize: 14 } }, '返回')),
        h(
          View,
          { style: { flex: 1 } },
          h(Text, { style: styles.headerTitle, numberOfLines: 1 }, file.name || '未命名'),
          h(Text, { style: styles.headerSub }, typeLabel(file) + (file.isDirectory ? '' : '　' + sizeLabel(file.size)) + (props.position ? '　' + props.position : ''))
        ),
        h(Badge, {
          text:
            renderer && renderer.editable && state.editable === false
              ? '只读 · 不支持编辑'
              : rendererModeLabel(renderer),
          tone: renderer && renderer.editable && state.editable !== false ? 'accent' : renderer && renderer.id === 'external' ? 'warn' : 'dim',
        })
      ),
      h(
        View,
        { style: styles.body },
        h(Component, {
          key: file.uri,
          file: file,
          reason: file.reason,
          registerSave: registerSave,
          onStateChange: setState,
          openExternal: props.openExternal,
          pickAgain: props.onPickFiles,
          pickFolder: props.onPickFolder,
          onPrev: props.onPrev,
          onNext: props.onNext,
        })
      )
    );
  }

  // ============ 插件入口 ============

  return function FileViewerPlugin() {
    const [route, setRoute] = React.useState({ name: 'home' });
    const [recent, setRecent] = React.useState([]);
    const [banner, setBanner] = React.useState({ tone: 'info', message: '' });
    const [queue, setQueue] = React.useState([]);

    React.useEffect(function () {
      readRecent().then(setRecent);
      if (api.preview && api.preview.clearImageCache) {
        api.preview.clearImageCache().catch(function () {});
      }
    }, []);

    function notify(message, tone) {
      setBanner({ tone: tone || 'error', message: message || '' });
    }

    function rememberAndSet(file) {
      remember(file).then(setRecent).catch(function () {});
    }

    function openFiles(files) {
      if (!files || files.length === 0) return;
      const list = files.slice();
      if (list.length > 1 && list.every(isImageFile)) {
        list.sort(naturalCompare);
      }
      const first = list[0];
      if (first.error) {
        notify(errMsg(first.error));
        return;
      }
      setQueue(list);
      setRoute({ name: 'viewer', file: first, index: 0 });
      rememberAndSet(first);
    }

    function pickFiles(kind) {
      const options = { multiple: true, initial: kind === 'download' ? 'download' : 'any' };
      api.preview
        .pickFiles(options)
        .then(function (files) {
          openFiles(files);
        })
        .catch(function (e) {
          if (errCode(e) !== 'E_CANCELED') notify('选择文件失败：' + errMsg(e));
        });
    }

    function pickFolder() {
      api.preview
        .pickFolder()
        .then(function (folder) {
          const dir = {
            uri: folder.uri,
            name: folder.name || '所选文件夹',
            mime: folder.mime || 'vnd.android.document/directory',
            size: 0,
            isDirectory: true,
            reason: '目录浏览只支持图片（漫画 / 多图）。其它文件请单独选择。',
          };
          setQueue([]);
          setRoute({ name: 'viewer', file: dir, index: 0 });
          rememberAndSet(dir);
        })
        .catch(function (e) {
          if (errCode(e) !== 'E_CANCELED') notify('选择文件夹失败：' + errMsg(e));
        });
    }

    function openExternalFor(file) {
      api.preview
        .openWithSystem(file.uri, file.mime)
        .then(function () {})
        .catch(function (e) {
          Alert.alert('无法打开', errMsg(e));
        });
    }

    function openRecent(item) {
      const file = {
        uri: item.uri,
        name: item.name,
        mime: item.mime,
        size: item.size,
        isDirectory: !!item.isDirectory,
        reason: '这是之前打开过的文件或目录。如果已失效，会提示重新选择。',
      };
      setQueue([]);
      setRoute({ name: 'viewer', file: file, index: 0 });
    }

    function removeRecent(item) {
      readRecent()
        .then(function (list) {
          const next = list.filter(function (entry) {
            return entry.uri !== item.uri;
          });
          return api.storage.set(RECENT_KEY, JSON.stringify(next)).then(function () {
            setRecent(next);
          });
        })
        .catch(function (e) {
          notify('移除记录失败：' + errMsg(e));
        });
    }

    if (route.name === 'viewer') {
      const index = route.index || 0;
      const hasQueue = queue.length > 1;
      return h(Viewer, {
        file: route.file,
        position: hasQueue ? index + 1 + ' / ' + queue.length : '',
        onClose: function () {
          setRoute({ name: 'home' });
          setBanner({ tone: 'info', message: '' });
        },
        onPickFiles: function () { pickFiles('any'); },
        onPickFolder: pickFolder,
        openExternal: function () { openExternalFor(route.file); },
        onPrev: hasQueue && index > 0
          ? function () {
              const next = index - 1;
              setRoute({ name: 'viewer', file: queue[next], index: next });
              rememberAndSet(queue[next]);
            }
          : null,
        onNext: hasQueue && index < queue.length - 1
          ? function () {
              const next = index + 1;
              setRoute({ name: 'viewer', file: queue[next], index: next });
              rememberAndSet(queue[next]);
            }
          : null,
      });
    }

    return h(Home, {
      recent: recent,
      banner: banner.message,
      bannerTone: banner.tone,
      onPickFiles: function () { pickFiles('any'); },
      onPickDownload: function () { pickFiles('download'); },
      onPickFolder: pickFolder,
      onOpenRecent: openRecent,
      onRemoveRecent: removeRecent,
    });
  };
};
